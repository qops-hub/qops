# Changelog

What changed in QOps, written for the person using it. Each entry says what is different when you sit
down in front of the product, and carries its ticket so the detail is one click away.

Versions are ordered newest first. A version heading is `## <version> — <date>`, kept in that exact
shape so it can be parsed: the Portal will show a version's notes in-app rather than sending you to
the website.

This page carries the current release and the one before it. Everything earlier is in
[Earlier releases](CHANGELOG-ARCHIVE.md), in the same shape and linked version by version at the
bottom of this page.

---

## 3.1.1 — 2026-10-23

### Version manager: installed versions, switching and the update channel

The version panel in the Portal has a **Version settings** window. It lists the QOps versions installed on
the computer, newest first, with the date each was built, which one is running, and a badge for where it
came from: green **Release**, amber for a staging channel with its name, grey for anything else (another
channel, MSI or PKG, or Unknown). A filter shows All, Release, Staging or Other. **Switch** on any complete
version restarts the Portal on it at the same address, and the Start menu and Desktop shortcuts start that
version from then on; it is greyed out, with the reason, while operations, an update or a restart run. See
[Version settings](USER-GUIDE.md#version-settings-the-installed-versions-and-switching-between-them).

The same window sets the **Update channel**: **Release** (recommended), **Staging**, or **Other** with a
channel name such as `staging-mcp`. A channel other than Release shows a warning that its builds are not
release-tested. After the change the Portal checks what the new channel offers and installs nothing. The
version panel has **Check for updates**, and shows **Update to &lt;version&gt;** only when the channel has a
newer build. See [Version settings: the update channel](USER-GUIDE.md#version-settings-the-update-channel).

Staying on an older version now lasts. After `QOps-SetVersion`, or `QOps-Update -Force` to an older build,
QOps stays on the version you chose until an update installs a newer one or you switch to the newest
installed version, and later updates compare the channel with the version you chose. `QOps-Update -Force`
asks you to close the Portal first when the Portal runs from a version it would replace. See
[Staying on an older version](USER-GUIDE.md#staying-on-an-older-version).

The same is available from PowerShell and the Portal API: `QOps-Update -CheckOnly` checks the channel
without installing and names the cause when the check fails (no network, GitHub's request limit, a rejected
token); `QOps-Version -Installed` lists the installed versions as objects with their origin;
`QOps-SetUpdateChannel -PassThru` returns the change as an object. The Portal API lists installed versions,
switches between them and sets the channel. See [QOps-Update](COMMAND-update.md#what-a-check-returns) and the
[API reference](API-v2-reference.md#installed-versions-and-the-update-channel).

Switching versions, changing the channel, updating, restarting and stopping the Portal are accepted from
the computer the Portal runs on and from the addresses listed in the new `Portal:AdminAllowedAddresses`
setting in `portal.settings.json`. Used at `http://localhost`, nothing changes; from any other address the
request is refused with `403` naming the setting, and the Version settings window is read-only. Behind a
reverse proxy on the same computer every caller looks local, so restrict these actions at the proxy. See
[Who may switch versions, update, restart or stop the Portal](API-v2-reference.md#who-may-switch-versions-update-restart-or-stop-the-portal)
(QOPS-710, QOPS-723, QOPS-745, QOPS-746, QOPS-747, QOPS-748, QOPS-749, QOPS-750, QOPS-756, QOPS-781).

If an installation is broken or removed, the installers for Windows, macOS and Linux are on the
[Installation](https://qops.datalabsua.com/documentation/installation/) page (QOPS-766).

### Smoother start in GitHub Codespaces

Licence activation in a GitHub Codespace works out of the box: it completes in the Codespace's home
folder, and it no longer needs a configured Qlik profile first. Configure your Qlik connection when you
are ready to work with it (QOPS-773, QOPS-783, QOPS-784).

### Git panel: a filterable list for many remote branches

With more than eight remote branches, the Branches card shows one button that opens a filterable list
instead of a chip per branch. Each row has Check out and Merge, and the list works from the keyboard
(QOPS-690).

### Fixes

- **Line endings follow one order in every command and in the Portal.** QOps uses the first that is set:
  `EOLStyle` in the repository's `.qopsconfig`, the global `EolStyle`, `eol=` in `.gitattributes`, Git's
  `core.autocrlf` or `core.eol`, then the system's line ending. With CRLF set, a file with mixed endings is
  written entirely in CRLF. If `EOLStyle` is set in neither configuration file, some files
  may now be written with different endings than before; set it to keep the endings you want
  (QOPS-434, QOPS-504, QOPS-505).

- **The Portal lists the same applications as QOps.** The application list and the screens built on it
  find applications the way Prepare and Build do: a folder with `App.yaml` or `App.json` directly inside
  the repository or inside a folder listed in `AppSubfolders`; the folder name no longer has to end in
  `-prj`. Spaces around `AppSubfolders` entries are ignored. See
  [Keep applications in subfolders](HOWTO-app-subfolders.md) (QOPS-758, QOPS-763).

- **Charts from the assistant get a title only when you ask for one, and combo chart lines get their own
  axis** unless your request puts them on the bars' axis (QOPS-743, QOPS-769).

- **Licence activation works in Docker containers on hosts with cgroup v2**, and the Portal and QOps
  commands in one container can check the licence back to back (QOPS-752, QOPS-753).

- **An expired licence is renewed whenever the licence service can be reached** (QOPS-778).

- **`QOps-Deactivate` says when there is nothing to deactivate** (QOPS-775).

- **Qlik Cloud connection errors say why the connection failed.** `Can't validate server` is followed by
  the HTTP status and, for a rejected API key, the setting that holds the key and the `QOps-SetConfig`
  command that stores a new one (QOPS-774).

- **Three switches stop the command where they do not apply**: `QOps-Release -ReloadBeforePublish` outside
  Qlik Cloud, `QOps-Publish -Placeholders` without `-Reload`, and `QOps-Publish -ServiceUrl`. On Qlik Cloud,
  `QOps-Release -ReloadBeforePublish` carries the reloaded data into an application already published in a
  managed space (QOPS-516).

- **Settings saved in the Portal's environment editor are read back reliably** when several screens read
  the configuration at the same time (QOPS-759).

## 3.1.0 — 2026-10-13

### QOps and your AI assistant: the QOps MCP server

QOps now includes an MCP server, so an AI assistant can work with your QOps repositories and Qlik
applications in plain language. It runs on your own machine, uses the connection profiles and licence
you already have, and never passes your Qlik credentials to the assistant. See
[AI Assistants (MCP)](MCP.md).

- Chat in the Portal. A Chat panel, opened from the Dashboard or docked beside the editor in Studio,
  talks to Claude or Gemini with the QOps tools and nothing to connect. Under **Settings → Global →
  Chat** you pick the provider and model and store your own API token, encrypted on this machine.
  Prompt caching is on by default, so long chats use fewer full-price tokens, and **Show token usage**
  adds a line with the tokens each answer used. The provider and model can also be changed for the
  chat you are in, from the provider's own model list.
- Your own assistant. Claude Desktop, Claude Code, Cursor and other MCP clients connect through a
  launcher that `QOps-StartPortal` writes to a fixed place, so the connection keeps working across
  updates.
- QOps operations. The assistant reads your repositories (apps, objects, lineage, load scripts) and
  runs Prepare, Build, Publish and Reload in a repository folder, exactly as the commands do.
- Qlik objects. It creates and changes sheets, charts, master items, variables and load scripts in a
  live application, with a read-only mode, a preview before a change, and one save for several
  changes. After each write it reads the result back and reports a broken expression, a chart that
  cannot draw, or a change that was not stored as sent. Charts cover bar, line, combo, pie, table,
  KPI, scatter, gauge, treemap and pivot table. A catalogue of chart settings lets it change legends,
  labels, axes, sorting, colours, combo series and donut or area styles exactly as Qlik does when you
  change them yourself. On Qlik Cloud it can make a sheet public with `publish_sheet`.
- The MCP-QOps licence. An MCP-QOps licence includes all of QOps and adds the analytic tools, which
  return the data in an application: values, calculated expressions and selections. With a QOps licence
  every other tool works and data values are left out. **Settings → Global → License** shows the
  licence tier. A tool call takes a licence slot only while it runs, so QOps commands can run while
  the assistant keeps an application open.

### Git panel: remote branches, fetch and a 3-way merge editor

The Branches card lists the branches of every remote. You can merge a remote branch into the current
one without switching, check one out as a tracking branch, and **Fetch** to see how far each branch is
behind. A conflicted file opens in a 3-way merge editor, with Current and Incoming side by side and an
editable Result, a choice to accept either side or both for each conflict, and Save marking the file
resolved and staged once no conflict is left.

### Release notes and updates from the Versions panel

The **Versions** panel, opened from the version badge, opens these notes at your installed version,
runs `QOps-Update` after you confirm, and restarts the Portal on the new version at the same address.
It shows the date and hour each Portal was built. `QOps-Update` can use your own GitHub token to stay
clear of GitHub's shared request limit, set with `QOps-SetConfig -GitHubToken` or in the Portal.
`QOps-SetVersion -RestartPortal` restarts a running Portal on the version you switch to, and the Portal
shortcut starts the version QOps last settled on.

### Building into new and existing applications

A folder with no `Id` is built into a new application, and the folder records it, so the next build
updates that application. `QOps-Build -UpdateOnly` builds only into applications that already exist on
the server you are connected to and never creates one, which is the safe first build after a fresh
clone. In the Portal it is **Update only** on Build.

### How-to guides in Help

The Help panel has **How-to Guides**: pages written around a task, such as connecting a fresh clone
to existing applications or setting the applications up on another environment, each with the commands
in order, how to check the result, and what to do when it did not work.

### QOps-Reload saves the task log to a file

On Qlik Sense, `QOps-Reload -LogPath` writes the full log of each task's last run to a file, and the
Portal's Reload status can download it.

### App files are written with only the Space key by default

A repository without a `StreamSerialization` setting now writes only the `Space` key into its app
files. Set `StreamSerialization: Both` to keep writing the older `Stream` key as well. Reading is
unchanged. See [The publish target in the app file](CONFIGURATION.md#the-publish-target-in-the-app-file).

### Fixes

- QOps-Release on Qlik Cloud publishes every sheet marked `Published: true`.
- QOps-Build on Qlik Sense saves again when the Engine reloads the application during the save.
- Uploads that Qlik Sense refuses because too many arrive at once are sent again.
- Publishing to a Qlik Cloud managed space keeps the application's description, and `-Sort Space` works on Qlik Cloud.
- Setting a new licence key works when a previous key is still activated, and on machines where the
  Windows user name differs from the profile folder name.
- QOps runs under PowerShell 7.4, and installing over an older version completes when the Portal was not stopped cleanly.

Work on the Portal and the MCP server continues, and more will come in the next releases.

---

## Earlier releases

Notes for the releases before the two above, newest first:

- [3.0.23 — 2026-10-08](CHANGELOG-ARCHIVE.md#3-0-23-2026-10-08)
- [3.0.22 — 2026-10-06](CHANGELOG-ARCHIVE.md#3-0-22-2026-10-06)
- [3.0.21 — 2026-09-25](CHANGELOG-ARCHIVE.md#3-0-21-2026-09-25)
- [3.0.20 — 2026-09-22](CHANGELOG-ARCHIVE.md#3-0-20-2026-09-22)
- [3.0.19 — 2026-09-18](CHANGELOG-ARCHIVE.md#3-0-19-2026-09-18)
- [3.0.18 — 2026-09-18](CHANGELOG-ARCHIVE.md#3-0-18-2026-09-18)
- [3.0.17 — 2026-09-17](CHANGELOG-ARCHIVE.md#3-0-17-2026-09-17)
- [3.0.16 — 2026-09-14](CHANGELOG-ARCHIVE.md#3-0-16-2026-09-14)
- [3.0.15 — 2026-09-11](CHANGELOG-ARCHIVE.md#3-0-15-2026-09-11)
- [3.0.14 — 2026-09-04](CHANGELOG-ARCHIVE.md#3-0-14-2026-09-04)
- [3.0.13 — 2026-08-24](CHANGELOG-ARCHIVE.md#3-0-13-2026-08-24)
- [3.0.12 — 2026-08-13](CHANGELOG-ARCHIVE.md#3-0-12-2026-08-13)
- [3.0.11 — 2026-08-07](CHANGELOG-ARCHIVE.md#3-0-11-2026-08-07)
- [3.0.10 — 2026-07-28](CHANGELOG-ARCHIVE.md#3-0-10-2026-07-28)
