# Changelog

What changed in QOps, written for the person using it. Each entry says what is different when you sit
down in front of the product.

Versions are ordered newest first. A version heading is `## <version> — <date>`, kept in that exact
shape so it can be parsed: the Portal will show a version's notes in-app rather than sending you to
the website.

This page carries the current release and the one before it. Everything earlier is in
[Earlier releases](CHANGELOG-ARCHIVE.md), in the same shape and linked version by version at the
bottom of this page.

---

## 3.1.2 — 2026-11-02

### Updates and version switching: the latest build of your channel, in both PowerShell editions

The version panel in the Portal works with the latest build of the update channel you chose. **Check for
updates** says either **You do not have the latest build from the &lt;channel&gt; channel**, with
**Download &lt;version&gt;**, or **You already have the latest build from the &lt;channel&gt; channel**, with
**Switch to &lt;version&gt;**. After a confirmation the Portal installs the build or switches to it, and
offers **Restart on &lt;version&gt;** right away, also when that build is older than the one the Portal runs.
A switch to an older version says that features, bug fixes and settings from newer versions are not
available in it. The panel, the status bar and the What's new link show the QOps version the Portal was
started from.

From PowerShell, `QOps-Update -IgnoreInstalledFromOtherChannels` installs the latest build of the channel
this computer is set to, or of the one given with `-Channel`, even when a newer build from another channel
is installed, for example to go back to the release build after trying a pre-release. `QOps-Update
-CheckOnly` reports whether that build is installed. See
[-IgnoreInstalledFromOtherChannels](COMMAND-update.md#ignoreinstalledfromotherchannels).

Every update goes into a folder of its own named after the version, on Windows as on Linux and macOS,
including `QOps-Update -Force`. No PowerShell window is closed and no other version is removed, and the
new folder is checked to load QOps before QOps switches to it.

`QOps-SetVersion`, `QOps-Update` and `QOps-Version -Installed` work with the module folder of the
PowerShell you run them in, so PowerShell 7 switches to the PowerShell 7 build. A Portal started from
Windows PowerShell 5.1 runs QOps commands in PowerShell 7 when it is installed, so `QOps-Prepare` on
Qlik Cloud works from such a Portal. `QOps-SetVersion` also switches the MCP server that assistants such
as Claude Desktop start; restart the assistant after switching. A Portal started from Windows PowerShell
on an earlier version updates and restarts into this version from the Portal. Leaving an earlier version
from the console still needs one PowerShell restart; every switch after that works.

### The QOps-Setup installer installs for all users

`QOps-setup.msi` installs for all users of the machine and asks for administrator rights when the
installation starts. Its Destination Folder page shows the Windows PowerShell 5.1 and PowerShell 7 module
folders. For a per-user install without administrator rights, use `QOpsModule.msi`. A QOps-Setup installed
earlier with Install just for you is not removed by the upgrade; remove it from Settings > Apps.

### GitHub Codespaces: the repository is ready when the Portal starts

In a GitHub Codespace, `QOps-StartPortal` registers the repository the Codespace was opened on, so the
Portal and the AI assistant list it without Add repository. When your QOps configuration has no `default`
profile yet, an empty one is added for you to fill in with your Qlik connection. Outside a Codespace
nothing changes.

### AI assistant (MCP): more chart settings, safer chart changes, shorter answers

- **More chart settings.** The assistant knows the full list of settings it can change for each chart
  type, explained in plain words: titles, legend, labels, axes, grid lines, colours, sorting, number
  formatting, reference and trend lines, conditions, alternative dimensions and measures, table totals and
  pagination, and the Styling panel. It sorts a chart's dimension and changes each setting the same way
  Qlik does when you set it in the properties panel.
- **Safer chart changes.** A property name, value or Styling setting the chart does not read, or a chart
  setting sent to a sheet, is refused before anything is written, and the answer names the right one.
  Settings behind an Auto switch, such as pie chart labels, are applied in one step.
- **Register a repository from the assistant.** Ask it to register a repository folder and it is added to
  the same list the Portal uses, under the same rules as Add repository in the Portal.
- **Answers that fit the assistant's conversation.** Master item, variable, object, application, lineage
  and data tools answer with a summary or a page first and give the rest on request, and the qops
  operation tools return the end of the command output. A complete answer that is too long for one reply
  is written to the repository's self-ignoring `.mcp-files` folder, where the assistant can search it.
  Prompts or scripts that read full details from these tools need `includeDetails`, `includeProperties`,
  `section` or `full=true`. See [AI Assistants (MCP)](MCP.md).

### Fixes

- **A global configuration that cannot be read is kept when you save.** The Portal refuses the change and
  shows the file's path and the reason, and offers **Back up and start fresh**; on the command line the
  same reset is `QOps-Configure -ResetGlobal`. The file is written to a temporary file first, so an
  interrupted write leaves the previous file intact.

- **`QOps-Release -Sort` sets the build and publish order, and parameters without effect are refused.**
  `-SkipCustomProperties` on `QOps-Build` and `QOps-Release`, and `-Ignore` on `QOps-Release`, stop the
  command before anything is changed. `QOps-Build` has no `-ServiceUrl` parameter, and `QOps-Reload` and
  `QOps-Publish` have no `-Placeholders` parameter.

- **QOps-Publish on Qlik Cloud publishes an app copied or imported a moment earlier**, and names an id
  that matches no app.

- **QOps-Prepare says when no app on the server matches the filter**, and names the server and how many
  apps it returned for the profile.

- **An expired licence key is reported as expired**, and a refused key does not block activating a valid
  one afterwards.

- **The version panel stops showing a failed restart once the Portal has been started again.**

- **Add repository in the Portal refuses a relative path and an id with characters other than letters,
  digits, `-`, `_` and `.`**; repositories already registered under such an id keep working.

## 3.1.1 — 2026-10-23

### Version manager: installed versions, switching and the update channel

The version panel in the Portal has a **Version settings** window. It lists the QOps versions installed on
the computer, newest first, with the date each was built, which one is running, and a badge for where it
came from: green **Release**, amber for a staging channel with its name, grey for anything else (another
channel, MSI or PKG, or Unknown). A filter shows All, Release, Staging or Other. **Switch** on any complete
version restarts the Portal on it at the same address, and the Start menu and Desktop shortcuts start that
version from then on; it is greyed out, with the reason, while operations, an update or a restart run. See
[Version settings](USER-GUIDE.md#version-settings-the-installed-versions-and-switching-between-them).

The same window sets the **Update channel**: **Release** (recommended), **Staging**, or **Other** with a
channel name such as `staging-mcp`. A channel other than Release shows a warning that its builds are not
release-tested. After the change the Portal checks what the new channel offers and installs nothing. The
version panel has **Check for updates**, and shows **Update to &lt;version&gt;** only when the channel has a
newer build. See [Version settings: the update channel](USER-GUIDE.md#version-settings-the-update-channel).

Staying on an older version now lasts. After `QOps-SetVersion`, or `QOps-Update -Force` to an older build,
QOps stays on the version you chose until an update installs a newer one or you switch to the newest
installed version, and later updates compare the channel with the version you chose. `QOps-Update -Force`
asks you to close the Portal first when the Portal runs from a version it would replace. See
[Staying on an older version](USER-GUIDE.md#staying-on-an-older-version).

The same is available from PowerShell and the Portal API: `QOps-Update -CheckOnly` checks the channel
without installing and names the cause when the check fails (no network, GitHub's request limit, a rejected
token); `QOps-Version -Installed` lists the installed versions as objects with their origin;
`QOps-SetUpdateChannel -PassThru` returns the change as an object. The Portal API lists installed versions,
switches between them and sets the channel. See [QOps-Update](COMMAND-update.md#what-a-check-returns) and the
[API reference](API-v2-reference.md#installed-versions-and-the-update-channel).

Switching versions, changing the channel, updating, restarting and stopping the Portal are accepted from
the computer the Portal runs on and from the addresses listed in the new `Portal:AdminAllowedAddresses`
setting in `portal.settings.json`. Used at `http://localhost`, nothing changes; from any other address the
request is refused with `403` naming the setting, and the Version settings window is read-only. Behind a
reverse proxy on the same computer every caller looks local, so restrict these actions at the proxy. See
[Who may switch versions, update, restart or stop the Portal](API-v2-reference.md#who-may-switch-versions-update-restart-or-stop-the-portal)
(QOPS-710, QOPS-723, QOPS-745, QOPS-746, QOPS-747, QOPS-748, QOPS-749, QOPS-750, QOPS-756, QOPS-781).

If an installation is broken or removed, the installers for Windows, macOS and Linux are on the
[Installation](https://qops.datalabsua.com/documentation/installation/) page (QOPS-766).

### Smoother start in GitHub Codespaces

Licence activation in a GitHub Codespace works out of the box: it completes in the Codespace's home
folder, and it no longer needs a configured Qlik profile first. Configure your Qlik connection when you
are ready to work with it (QOPS-773, QOPS-783, QOPS-784).

### Git panel: a filterable list for many remote branches

With more than eight remote branches, the Branches card shows one button that opens a filterable list
instead of a chip per branch. Each row has Check out and Merge, and the list works from the keyboard
(QOPS-690).

### Fixes

- **Line endings follow one order in every command and in the Portal.** QOps uses the first that is set:
  `EOLStyle` in the repository's `.qopsconfig`, the global `EolStyle`, `eol=` in `.gitattributes`, Git's
  `core.autocrlf` or `core.eol`, then the system's line ending. With CRLF set, a file with mixed endings is
  written entirely in CRLF. If `EOLStyle` is set in neither configuration file, some files
  may now be written with different endings than before; set it to keep the endings you want
  (QOPS-434, QOPS-504, QOPS-505).

- **The Portal lists the same applications as QOps.** The application list and the screens built on it
  find applications the way Prepare and Build do: a folder with `App.yaml` or `App.json` directly inside
  the repository or inside a folder listed in `AppSubfolders`; the folder name no longer has to end in
  `-prj`. Spaces around `AppSubfolders` entries are ignored. See
  [Keep applications in subfolders](HOWTO-app-subfolders.md) (QOPS-758, QOPS-763).

- **Charts from the assistant get a title only when you ask for one, and combo chart lines get their own
  axis** unless your request puts them on the bars' axis (QOPS-743, QOPS-769).

- **Licence activation works in Docker containers on hosts with cgroup v2**, and the Portal and QOps
  commands in one container can check the licence back to back (QOPS-752, QOPS-753).

- **An expired licence is renewed whenever the licence service can be reached** (QOPS-778).

- **`QOps-Deactivate` says when there is nothing to deactivate** (QOPS-775).

- **Qlik Cloud connection errors say why the connection failed.** `Can't validate server` is followed by
  the HTTP status and, for a rejected API key, the setting that holds the key and the `QOps-SetConfig`
  command that stores a new one (QOPS-774).

- **Three switches stop the command where they do not apply**: `QOps-Release -ReloadBeforePublish` outside
  Qlik Cloud, `QOps-Publish -Placeholders` without `-Reload`, and `QOps-Publish -ServiceUrl`. On Qlik Cloud,
  `QOps-Release -ReloadBeforePublish` carries the reloaded data into an application already published in a
  managed space (QOPS-516).

- **Settings saved in the Portal's environment editor are read back reliably** when several screens read
  the configuration at the same time (QOPS-759).

---

## Earlier releases

Notes for the releases before the two above, newest first:

- [3.1.0 — 2026-10-13](CHANGELOG-ARCHIVE.md#3-1-0-2026-10-13)
- [3.0.23 — 2026-10-08](CHANGELOG-ARCHIVE.md#3-0-23-2026-10-08)
- [3.0.22 — 2026-10-06](CHANGELOG-ARCHIVE.md#3-0-22-2026-10-06)
- [3.0.21 — 2026-09-25](CHANGELOG-ARCHIVE.md#3-0-21-2026-09-25)
- [3.0.20 — 2026-09-22](CHANGELOG-ARCHIVE.md#3-0-20-2026-09-22)
- [3.0.19 — 2026-09-18](CHANGELOG-ARCHIVE.md#3-0-19-2026-09-18)
- [3.0.18 — 2026-09-18](CHANGELOG-ARCHIVE.md#3-0-18-2026-09-18)
- [3.0.17 — 2026-09-17](CHANGELOG-ARCHIVE.md#3-0-17-2026-09-17)
- [3.0.16 — 2026-09-14](CHANGELOG-ARCHIVE.md#3-0-16-2026-09-14)
- [3.0.15 — 2026-09-11](CHANGELOG-ARCHIVE.md#3-0-15-2026-09-11)
- [3.0.14 — 2026-09-04](CHANGELOG-ARCHIVE.md#3-0-14-2026-09-04)
- [3.0.13 — 2026-08-24](CHANGELOG-ARCHIVE.md#3-0-13-2026-08-24)
- [3.0.12 — 2026-08-13](CHANGELOG-ARCHIVE.md#3-0-12-2026-08-13)
- [3.0.11 — 2026-08-07](CHANGELOG-ARCHIVE.md#3-0-11-2026-08-07)
- [3.0.10 — 2026-07-28](CHANGELOG-ARCHIVE.md#3-0-10-2026-07-28)
