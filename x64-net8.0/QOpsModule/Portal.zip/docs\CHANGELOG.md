# Changelog

What changed in QOps, written for the person using it. Each entry says what is different when you sit
down in front of the product.

Versions are ordered newest first. A version heading is `## <version> — <date>`, kept in that exact
shape so it can be parsed: the Portal will show a version's notes in-app rather than sending you to
the website.

This page carries the current release and the one before it. Everything earlier is in
[Earlier releases](CHANGELOG-ARCHIVE.md), in the same shape and linked version by version at the
bottom of this page.

---

## 3.1.6 — 2026-11-28

### Send a support case from the Portal

**Help → Send support case**, also in the command palette, collects what QOps support needs from the
computer the Portal runs on, the same as `QOps-SendSupportCase`. Before anything is sent, the dialog shows
every file in the case, its size and how many values were masked in it. You can add what happened and an
e-mail address for the answer, then tick the box to agree and press **Send**; the dialog shows the case
number. When the case cannot be sent, the dialog says why and offers the zip as a download and the
technical support form to send it through. It works without a licence and without a Qlik connection.
`QOps-SendSupportCase -CaseFile <zip>` sends a case written earlier with `-OutFile`, unchanged.

### Studio: arrange a sheet's widgets on its grid

Right-click a sheet in the Studio file tree and choose Open layout view to see the sheet's grid with each
widget on it. Drag a widget to move it, drag its edges and corners to resize it, or use the arrow keys
(Shift with an arrow resizes); everything snaps to whole cells, and a widget cannot be dropped over another
one. Save changes only the position and size in the widget files that moved, and Revert discards the
changes. A widget whose file was changed outside Studio in the meantime is not saved and is named in the
message.

### Studio: Qlik expressions in object files get highlighting and a formula editor

In a widget, measure, dimension or master object file, Studio colours each Qlik expression the way it
colours a load script, so functions, field names, strings and `$(variable)` expansions stand out inside the
YAML or JSON. Hover an expression and choose Formula editor, or right-click it and choose Open in Formula
Editor, to edit it in a large panel. Apply (or Ctrl+Enter) puts the expression back into the file's tab
with the file's own quoting, where you save it or undo it like any other edit; Cancel or Esc closes the
panel without changes.

### AI assistant (MCP): charts coloured by dimension, and more of Styling > General

Ask the assistant to colour a line chart by dimension and it colours the lines the way the Qlik Cloud UI
does: with two dimensions, each value of the second dimension gets its own colour; with one dimension,
each of its values does.

The assistant can also set more of Styling > General, the way the Qlik Cloud Styling panel writes it: on
bar, combo, line and scatter charts and on treemaps the title, subtitle and footnote font and font size,
the corner rounding of the object border and the drop shadow, and on bar, combo, line and scatter charts
the border width. Changing one Styling option keeps the others.

### Qlik engine connection: a Qlik Cloud build reconnects after a drop, and a request with no answer fails after 1 minute

When the connection to the Qlik engine drops during a Qlik Cloud `QOps-Build`, `QOps-Release` or
`QOps-Publish`, QOps opens the app again, checks that it still holds the app's write lock, writes the
unsaved parts again and continues with the step that failed. It tries up to 3 times, after 5, 15 and 30
seconds; if the connection does not come back, the command fails with a message that names the step.
On Qlik Cloud and Qlik Sense, a build keeps its engine connection active during long uploads and slow
calls.

An engine request that gets no answer fails the step after 1 minute, with a message naming the request,
the limit and the setting to change. Opening an app, saving it and reloading it keep a 60 minute limit.
Both limits are set with `QOps-SetConfig -EngineRequestTimeoutMinutes` and
`-EngineLongRequestTimeoutMinutes`, or as the same keys in `.qopsconfig`.

### Write locks: set how long a lock lives, and a stopped or refused run leaves the app clean

- In the Portal, stopping a Build, Publish or other writing run frees that app at once: the next QOps run
  removes exactly the stopped run's lock. Locks of other runs, including runs from the console, are left
  alone.
- How long a lock left behind by a stopped run blocks the app is set with
  `QOps-SetConfig -WriteLockStaleMinutes <minutes>` (1 to 1440) or in the Portal under the repository
  settings, Behaviour. The lock messages name both ways.
- `QOps-Build`, `QOps-Release` and an in-place `QOps-Publish` run with `-IgnoreWriteLease` remove on
  success the other locks in the app that are older than their own start, and the log names who held each
  one.
- A `QOps-Build` refused because another run holds the app leaves the app as it was. See
  [When another QOps run is writing the same app](COMMAND-build.md#when-another-qops-run-is-writing-the-same-app).
- On Qlik Sense, a second `QOps-Build` on an unpublished app stops and names the run that holds the app,
  also when both runs use the same account.

### Ctrl+C stops a build after the current app

The first Ctrl+C during `QOps-Build`, `QOps-Publish` or `QOps-Release`, on Qlik Cloud and Qlik Sense,
finishes and saves the current app, releases its write lock, skips the remaining apps and says so at once;
the summary tells how many apps were skipped. A Ctrl+C during a `-WaitAndRewrite` wait ends the wait at
once. A second Ctrl+C exits at once; the write lock of the app being built then stays until
WriteLockStaleMinutes, a run with `-IgnoreWriteLease`, or the next Portal run if the Portal stopped that
run. This works in Windows PowerShell 5.1 too.

### QOps-Pull, QOps-Push, QOps-Commit and QOps-Release keep your work and your repository as they are

When git would lose or change something you did not ask for, these commands stop, change nothing and show
what git said:

- QOps-Pull does not overwrite uncommitted files, does not pull into a local branch that already exists,
  and pulls from the `-URL` you give. `QOps-Release` with `-LocalBranch` and `-RemoteBranch` pulls the same
  way and releases nothing when the pull is refused.
- QOps-Push and QOps-Commit report a rejected push, a failed commit or a failed branch switch as Failed,
  keep the upstream of every branch, and leave `.gitignore` alone unless you pass `-Ignore`.
- In a subfolder of a repository all of them work with that repository, and a `.qopsconfig` in a parent
  folder is only read. See [Where Pull, Push and Commit run](CONFIGURATION.md#where-pull-push-and-commit-run).

### Fixes

#### AI

- **AI assistant (MCP): a chart dimension written as an expression without = is refused with the accepted
  form.** For a dimension such as `Month(OrderDate)`, the message names `=Month(OrderDate)` and nothing is
  written.
- **AI assistant (MCP): an app name passed where the app id belongs comes back with the ids of the apps of
  that name**, up to ten, each with its space or stream, so the next call can use the id.

#### Licence

- **Deactivating one licence keeps your other licences working.** When one user account holds more than
  one QOps licence, `QOps-Deactivate` on one of them leaves the others readable, with no new activation.

#### Operations

- **On Qlik Cloud, `QOps-Build`, `QOps-Release` and `QOps-Publish` apply the app thumbnail from `App.yaml`
  to every app they write.**
- **QOps-Prepare with bookmarks keeps the variable values of the user who runs it.** With
  `-IncludeBookmarks` or `-AllBookmarks`, that user's later sessions of the app, in the Hub or the next QOps
  run, see the variables unchanged.
- **Qlik Sense: QOps-BuildDataConnections updates an existing data connection in place.** The connection
  keeps its id, its stored password, and the custom properties and tags the repository file does not list.
  If Qlik Sense refuses the update, the connection stays as it was and the row says Failed.
- **QOps-ImportFile, QOps-ExportFile and QOps-RemoveFile work on the file you name.** QOps-ImportFile into
  a folder looks for the name in that folder only, and an exact `-File` takes the file of exactly that name
  (or, as Qlik Cloud does, the one in the same folder that differs only in case). Under `-QlikPath`,
  `-File` can be a path relative to that folder, such as `2025/old.qvd`.
- **QOps-SetConfig changes only the settings you pass.** A profile whose name differs only in letter case
  is updated, not added a second time, and the saved `TrustSelfSignedCerts` and the repository's
  `EOLStyle` stay as they are. `-EOLStyle LF` or `-EOLStyle CRLF` can be set with QOps-SetConfig.

#### Other

- **Usages of a master dimension list only the objects that use that dimension.** A master dimension that
  nothing uses is shown as unused, and the Usages window offers "Usages of field <name>" for the uses of
  its field.
- **Each app in the Portal reads only its own folder**, also when one app's id is part of another app's
  name, such as `facts_web` and `facts_webaggr`.
- **Portal git commands work with a typographic apostrophe (’ ‘) or a backtick in a branch name, file
  path or folder**, and Set upstream accepts such a branch name.

## 3.1.5 — 2026-11-18

### Prevent concurrent QOps writes to the same app and show who holds the lock
When another QOps run is already writing to the same app, `QOps-Build`, `QOps-Release`, and in-place `QOps-Publish` runs stop at once without changing it and report the user, machine, and start time of the active run — regardless of which account or machine started it. Pass `-WaitAndRewrite` to wait up to 10 minutes for the other run to finish before writing, or `-IgnoreWriteLease` to write immediately when you are sure the lock was left behind; both flags are also available under **Flags** in the Portal. A lock left behind by a run interrupted mid-write is treated as stale after 60 minutes (configurable via `WriteLockStaleMinutes`), after which the next run removes it and continues. While an app is reloading, QOps skips writing and reports it (or waits if `-WaitAndRewrite` is used).

---

## Earlier releases

Notes for the releases before the two above, newest first:

- [3.1.4 — 2026-11-13](CHANGELOG-ARCHIVE.md#3-1-4-2026-11-13)
- [3.1.3 — 2026-11-04](CHANGELOG-ARCHIVE.md#3-1-3-2026-11-04)
- [3.1.2 — 2026-11-02](CHANGELOG-ARCHIVE.md#3-1-2-2026-11-02)
- [3.1.1 — 2026-10-23](CHANGELOG-ARCHIVE.md#3-1-1-2026-10-23)
- [3.1.0 — 2026-10-13](CHANGELOG-ARCHIVE.md#3-1-0-2026-10-13)
- [3.0.23 — 2026-10-08](CHANGELOG-ARCHIVE.md#3-0-23-2026-10-08)
- [3.0.22 — 2026-10-06](CHANGELOG-ARCHIVE.md#3-0-22-2026-10-06)
- [3.0.21 — 2026-09-25](CHANGELOG-ARCHIVE.md#3-0-21-2026-09-25)
- [3.0.20 — 2026-09-22](CHANGELOG-ARCHIVE.md#3-0-20-2026-09-22)
- [3.0.19 — 2026-09-18](CHANGELOG-ARCHIVE.md#3-0-19-2026-09-18)
- [3.0.18 — 2026-09-18](CHANGELOG-ARCHIVE.md#3-0-18-2026-09-18)
- [3.0.17 — 2026-09-17](CHANGELOG-ARCHIVE.md#3-0-17-2026-09-17)
- [3.0.16 — 2026-09-14](CHANGELOG-ARCHIVE.md#3-0-16-2026-09-14)
- [3.0.15 — 2026-09-11](CHANGELOG-ARCHIVE.md#3-0-15-2026-09-11)
- [3.0.14 — 2026-09-04](CHANGELOG-ARCHIVE.md#3-0-14-2026-09-04)
- [3.0.13 — 2026-08-24](CHANGELOG-ARCHIVE.md#3-0-13-2026-08-24)
- [3.0.12 — 2026-08-13](CHANGELOG-ARCHIVE.md#3-0-12-2026-08-13)
- [3.0.11 — 2026-08-07](CHANGELOG-ARCHIVE.md#3-0-11-2026-08-07)
- [3.0.10 — 2026-07-28](CHANGELOG-ARCHIVE.md#3-0-10-2026-07-28)
