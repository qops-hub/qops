# Reload tasks

**What this group is.** Two commands version-control the reload tasks of a Qlik Sense environment, with
their triggers, so an app built into another environment is reloaded on the same schedule there.
This page is the map; each command has its own page with its own flags.

| Command | What it does | Direction | Page |
|---|---|---|---|
| `QOps-PrepareTasks` | Writes reload tasks into the repository as files | Qlik → disk | [QOps-PrepareTasks](COMMAND-preparetasks.md) |
| `QOps-BuildTasks` | Creates those reload tasks in Qlik from the files | disk → Qlik | [QOps-BuildTasks](COMMAND-buildtasks.md) |

**In the Portal.** Both are on the **Operations** panel. Open **All commands**, find them under
*Reload tasks*, and either run one from the list or pin it so it gets a button of its own, see
[Choosing what the panel shows](COMMANDS.md#choosing-what-the-panel-shows).

**Needs.** **Qlik Sense only**, both of them. Against a Qlik Cloud or QlikView configuration each command says
so and stops. The panel disables them there.

## Flows

**Carry the schedules from one environment to another.**

    QOps-PrepareTasks -Filter "Name=Nightly*"   # from the source environment
    QOps-BuildTasks   -Filter "Name=Nightly*"   # into the target one

A reload task belongs to an app, so build the apps first: a task whose app is not in the target
environment has nothing to reload.

## See also

- [Commands](COMMANDS.md): the whole command map
