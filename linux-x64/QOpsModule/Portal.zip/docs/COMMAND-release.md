# QOps-Release

**What it does.** Builds the applications from the repository and publishes them to their targets, in
one run. It is [Build](COMMAND-build.md) followed by [Publish](COMMAND-publish.md), with the two
halves sharing what they know about each application.

**Direction.** disk → Qlik.

**In the Portal.** Operations → Release.

## Why it is one command and not two

A publish reads the target — stream or space — from the application's properties file in the
repository. Running build and publish separately makes the publish resolve its target from the filter
string instead, which does not carry it. Release keeps both halves on the same information.

## Which sheets are published

Sheets are chosen by their state in the repository (`Published` and `Approved` in each sheet's file), and the rule depends on the platform.

**Qlik Sense.** By default a release publishes the sheets that are both published and approved; they become the base sheets of the published application. `-AllPublishedSheets` adds the published sheets that are not approved, and `-AllSheets` adds every sheet, private ones included.

**Qlik Cloud.** Qlik Cloud has no sheet approval, so `Approved` plays no part. A release publishes every public sheet, that is every sheet with `Published: true`, as a sheet of the published application. Private sheets stay out unless `-AllSheets` is set. `-AllPublishedSheets` changes nothing here, because all public sheets are already included.

## What happens to the application Id

A release builds the application and then puts it in its target, and what matters most about that is the application **Id**: links to the application, schedules, subscriptions, reload tasks and anything else that refers to it by Id keep working only while the Id stays the same. When the target already holds an application under the name you release, that application **keeps its Id** on every platform and every kind of target.

- **Qlik Sense stream, Qlik Cloud managed space.** The built application is published. If the target already holds an application under that name, it is replaced with the new content and keeps its Id; otherwise the published application is new and gets a new Id.
- **Qlik Cloud shared or personal space.** These spaces have no publishing of their own. If the space already holds an application under that name, the release builds **into that application, in place**: it keeps its Id, and nothing is moved or removed. Otherwise the release builds a new application and moves it into the space.

`Published` in the application's properties file applies to managed spaces only. For a shared or personal space it changes none of the above. An update in place carries the content, not the data: add `-Reload` to the same command to refresh it.

The [table at the end of this page](#application-id-after-a-release) lists every case.

## Flags

### -Reload

Reloads the PUBLISHED application after the publish. Order: build, publish, reload.

### -ReloadBeforePublish

Reloads the application BEFORE it is published, so the published copy carries fresh data. Order:
build, reload, publish.

The two are different runs and it is worth being deliberate about which one you want: `-Reload` leaves
the published copy reloaded, `-ReloadBeforePublish` makes the snapshot that gets published a fresh
one. They can both be set.

**Qlik Cloud only.** On Qlik Sense and QlikView the command stops with an error before the release
starts, instead of publishing without the reload. On Qlik Sense the published application is the one that was built, so
`-Reload` gives it fresh data right after the publish. In the Portal the switch is greyed out on those
platforms.

### -Inplace

Starts from a copy of the application that is already there instead of from a new empty one. Without
it, a release creates a new application and builds into that. This is the one place the switch decides
the target; on an ordinary [build](COMMAND-build.md#inplace) it decides only how the writing is done.

On Qlik Cloud this applies to managed spaces. A release to a shared or personal space that already holds the application always builds into that application and keeps its Id, with or without this switch.

On Qlik Cloud it is refused for an application in a managed space: the run says so and continues in
base mode, because a managed space does not allow writing into the published application.

### -NoPull

Skips the pull from the remote repository that a release does before building.

A release only pulls when it was given both a local and a remote branch. The Portal does not pass
branches, so **in the Portal there is no pull to skip** and this switch changes nothing. It is here
because the same flag set is offered for command-line use, where the branches are given.

### -RemoveArtefacts

⚠️ Deletes the application's folder from the repository on disk after a successful run.

This is for a build-and-throw-away workflow, where the repository is a checkout that exists only for
the run. On a working copy it removes files you meant to keep — and the same switch on
[Publish](COMMAND-publish.md#removeartefacts) means something else entirely, so it is worth checking
which command you are setting it on.

### -SkipCustomProperties

Has no effect on a release, so the command stops with an error before the release starts and nothing is changed.
Remove the switch. It applies to [QOps-Prepare](COMMAND-prepare.md), where it skips the custom
properties of extensions. The Portal does not offer it here.

### -Sort

The order in which the applications are built and published, as `Field=asc` or `Field=desc`. The
fields are `Name`, `Id`, `Owner`, `Published` and `Stream` (Qlik Sense) or `Space` (Qlik
Cloud). Without it the applications go in name order. It works as `-Sort` does on [QOps-Build](COMMAND-build.md); on
QlikView the documents keep their order.

    -Sort "Name=desc"

Command line only; the Portal does not offer it.

### -Ignore

Has no effect on a release. Given on the command line, it stops the command with an error before the
release starts, and nothing is changed: remove it. The `Ignore` value in the configuration is used by
QOps-Commit and QOps-Push and does not stop a release.

### -AllSheets

Includes every sheet, including private and community ones. Without it, a published application contributes only its approved sheets on Qlik Sense, and only its public sheets on Qlik Cloud. See [Which sheets are published](#which-sheets-are-published).

### -AllPublishedSheets

Includes every published sheet, whether or not it was approved. `-AllSheets` wins if both are set. On Qlik Cloud this is already the default, so the switch changes nothing there.

### -VerboseLog

Writes a fuller log for this run, with passwords, keys and tokens masked.

### -Force

Skips the confirmation QOps asks before touching more than ten applications.

## When another QOps run is writing the same app

Release takes the same write lease as [QOps-Build](COMMAND-build.md#when-another-qops-run-is-writing-the-same-app):
if another QOps run is writing the app, the release waits for it, and after 10 minutes it stops without
changing the app and asks you to run it again.

## See also

- [QOps-Build](COMMAND-build.md) and [QOps-Publish](COMMAND-publish.md) — the two halves
- [Commands](COMMANDS.md) — the whole command map

## Application Id after a release

Every case, by target. *Target app exists* means the target already holds an application under the name you release.

| Where | Target app exists | What the release does | Application Id |
|---|---|---|---|
| Qlik Sense stream | no | Builds a new application and publishes it | new Id |
| Qlik Sense stream | yes | Builds a new application and replaces the target with it | target keeps its Id |
| Qlik Cloud managed space | no | Builds a new application and publishes a copy of it | new Id |
| Qlik Cloud managed space | yes | Builds a new application and replaces the target with it | target keeps its Id |
| Qlik Cloud shared or personal space | no | Builds a new application and moves it into the space | the new application's Id |
| Qlik Cloud shared or personal space | yes | Builds into the target in place; nothing is moved or removed | target keeps its Id |
