# Custom properties

**What this group is.** Two commands version-control the custom property **definitions** of a Qlik Sense
environment: the name, the allowed values and the object types each one applies to. The values set on
individual apps travel with those apps, not here.
This page is the map; each command has its own page with its own flags.

| Command | What it does | Direction | Page |
|---|---|---|---|
| `QOps-PrepareCustomProperties` | Writes the definitions into the repository as files | Qlik → disk | [QOps-PrepareCustomProperties](COMMAND-preparecustomproperties.md) |
| `QOps-BuildCustomProperties` | Creates those definitions in Qlik from the files | disk → Qlik | [QOps-BuildCustomProperties](COMMAND-buildcustomproperties.md) |

**In the Portal.** Both are on the **Operations** panel. Open **All commands**, find them under
*Custom properties*, and either run one from the list or pin it so it gets a button of its own, see
[Choosing what the panel shows](COMMANDS.md#choosing-what-the-panel-shows).

**Needs.** **Qlik Sense only**, both of them. Qlik Cloud has no custom properties of this kind, and against a
Cloud or QlikView configuration each command says so and stops. The panel disables them there.

## Flows

**Carry the definitions from one environment to another.**

    QOps-PrepareCustomProperties -Filter "Name=Region*"   # from the source environment
    QOps-BuildCustomProperties   -Filter "Name=Region*"   # into the target one

Build custom properties before you build the apps that use them, or the values on those apps have
nothing to attach to.

## See also

- [Commands](COMMANDS.md): the whole command map
