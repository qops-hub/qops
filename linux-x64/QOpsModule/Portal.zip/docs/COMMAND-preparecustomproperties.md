# QOps-PrepareCustomProperties

**What it does.** Writes custom property definitions from the environment into the repository as files.

**Direction.** Qlik → disk.

**In the Portal.** On the **Operations** panel, under **All commands**, as **Prepare custom properties**.

**Needs.** **Qlik Sense only.** Run against a Qlik Cloud or QlikView configuration it says so and
stops without doing anything, and the panel disables it on those environments.

    QOps-PrepareCustomProperties
    QOps-PrepareCustomProperties -Filter "Name=Region*"

## When no filter is given

Given no `-Filter`, it uses the filter the repository has saved under `CustomPropertiesFilter`
(`QOps-AddCustomProperties` writes it). With no filter given and none saved it does nothing and says
so; pass `-Filter *` to include every custom property.

## Flags

### -Filter

Which custom properties to act on. The same filter grammar the rest of QOps uses: `Name=`, `*` and `?` as
wildcards, and `;` between clauses when you want several.

    -Filter "Name=Region*"
    -Filter *

> The `;` is part of the filter, not a separator the Portal invents. Typed into the panel it reaches
> the command intact.

Left out, the filter this repository has saved under `CustomPropertiesFilter` is used.

### -Sort

Which column the result is ordered by, by name. It changes the order of the output only, not what is
found.

### -Profile

Which configured authentication profile to use, when you run the command yourself. The Portal does
not offer it: the command runs in the repository, so it uses the repository profile, like Prepare and
Build do.

### -VerboseLog

Writes a fuller log for this run, with passwords, keys and tokens masked. Turn it on when you are going to send a log to somebody.

## See also

- [Custom properties](COMMAND-customproperties.md): the group this command belongs to
- [Commands](COMMANDS.md): the whole command map
