# Extensions

**What they are.** Visualisation extensions and mashups — the front-end bundles a Qlik environment
serves to applications. QOps version-controls them the same way it version-controls applications:
one folder per extension in the repository, with the extension's own files inside it.

**Where it runs.** Listing extensions (`QOps-ShowExtensions`) works on Qlik Sense and Qlik Cloud.
Prepare, Build, Release and Remove are **Qlik Sense only**: on any other configuration they say so and
stop. `QOps-AddExtensions`, `QOps-RenameExtension` and `QOps-SetLocalExtension` work on the
repository only.

**In the Portal.** Show, Add, Prepare, Build, Release and Set local extension are on the
**Operations** panel. Open **All commands** and find them under *Extensions*. On a Qlik Cloud
environment the panel disables the Sense-only ones and says why. Rename and Remove are not on the
panel; run them from PowerShell.

**Needs.** A configured profile. Creating and replacing extensions needs an identity the Qlik
environment allows to manage them; listing them does not.

## The commands

| Command | Direction | What it does |
|---|---|---|
| [`QOps-ShowExtensions`](COMMAND-showextensions.md) | Qlik only | Lists what the environment has. Changes nothing. |
| [`QOps-AddExtensions`](COMMAND-addextensions.md) | repository | Saves a filter in the repository so later commands reuse it. |
| [`QOps-PrepareExtensions`](COMMAND-prepareextensions.md) | Qlik → repository | Writes extensions from the environment into the repository. |
| [`QOps-BuildExtensions`](COMMAND-buildextensions.md) | repository → Qlik | Puts repository extensions into the environment as work in progress. |
| [`QOps-ReleaseExtensions`](COMMAND-releaseextensions.md) | repository → Qlik | Publishes them under their real names. |
| `QOps-RenameExtension` | repository | Renames one extension and every reference to it. |
| `QOps-RemoveExtensions` | Qlik | Deletes extensions from the environment. |
| [`QOps-SetLocalExtension`](COMMAND-setlocalextension.md) | repository | Keeps a local variant of an extension's properties. |

## Leaving the filter out

**This is the one thing worth reading before anything else, because reading and writing behave
differently on purpose.**

`QOps-ShowExtensions` with no filter lists **everything** the environment has:

    QOps-ShowExtensions

That is the way to tell "my filter matched nothing" apart from "this environment has no extensions",
and it matches `QOps-Apps` and `QOps-ShowDataConnections`.

The commands that **write** — `QOps-PrepareExtensions`, `QOps-BuildExtensions`,
`QOps-ReleaseExtensions` — do **not** act on everything by default. With no filter given and none
saved in the repository they do nothing, and they say so:

    QOps-BuildExtensions: no filter was given and none is saved in this repository, so no extensions
    were touched. Write commands do not act on everything by default - pass -Filter * to include
    every one of them, or a name or pattern to narrow it.

Everything stays reachable — it just has to be asked for:

    QOps-BuildExtensions -Filter *

**Why the two sides differ.** Listing costs nothing and undoes nothing, so the helpful default is to
show you what is there. Writing does change the environment: a build replaces the environment's copy
of every extension it covers. A command that silently expanded "no filter" into "all of them" would
make an unattended script rewrite far more than its author meant.

A filter saved by `QOps-AddExtensions` counts as a filter for both sides. Once one is saved, the
write commands use it without you repeating it, and `QOps-ShowExtensions` uses it too.

## -Filter

The same filter grammar the rest of QOps uses: `Name=`, `*` and `?` as wildcards, and `;` between
clauses when you want several.

    -Filter "Name=sales-*"
    -Filter "Name=sales-*;Name=hr-*"
    -Filter *

**`QOps-RemoveExtensions` is the exception: it matches the name exactly.** Wildcards are not expanded
there, so `-Filter "Name=sales-*"` looks for an extension literally called `sales-*` — which normally
means it finds nothing, removes nothing, and says so. List what a pattern covers first, then remove
each by its own name:

    QOps-ShowExtensions -Filter "Name=sales-*"
    QOps-RemoveExtensions -Filter "Name=sales-report;Name=sales-forecast" -Force

The exactness is deliberate. Removal is the one operation here that cannot be undone, and a mistyped
pattern that quietly widens is a worse failure than one that matches nothing. `QOps-RemoveExtensions`
also runs on Qlik Sense only.

## Work in progress and published names

`QOps-BuildExtensions` puts an extension into the environment as **work in progress**: it appears
under a name prefixed with `_WIP_` and your account, so it cannot collide with the published one your
users see. `QOps-ReleaseExtensions` publishes it under its real name.

That is why an extension you have just built appears in `QOps-ShowExtensions` under the prefixed
name, and why a build never disturbs the version already in use until you release it.

## If a run does nothing

- **Nothing is listed.** The filter matched nothing, or the environment genuinely has no extensions.
  Run `QOps-ShowExtensions` with no filter to tell those apart.
- **A write command reports that no filter was given.** Exactly that: nothing was attempted. Give it
  a filter, or `-Filter *` for all of them.
- **Build reports that it cannot create an extension.** The environment refused the upload. Managing
  extensions is a separate permission from listing them, so an identity that can list may still not
  be allowed to create — ask whoever administers the environment.
- **Remove appears to succeed but the extension is still there.** `QOps-RemoveExtensions` needs
  `-Force`; without it nothing is deleted.
- **Remove says it cannot find an extension you can see in the list.** It matches names exactly — a
  pattern is not expanded, so `-Filter "Name=sales-*"` finds nothing however many `sales-` extensions
  exist. See [-Filter](#filter).

## See also

- [Commands](COMMANDS.md) — the whole command map
- [Data connections](COMMAND-dataconnections.md) — the same read/write split for `lib://` connections
- [Configuration](CONFIGURATION.md#the-repository-file) — where a saved filter is kept
