# Tags

**What this group is.** Two commands version-control the tags of a Qlik Sense environment, so the same tags
exist wherever the apps that carry them are built.
This page is the map; each command has its own page with its own flags.

| Command | What it does | Direction | Page |
|---|---|---|---|
| `QOps-PrepareTags` | Writes tags into the repository as files | Qlik → disk | [QOps-PrepareTags](COMMAND-preparetags.md) |
| `QOps-BuildTags` | Creates those tags in Qlik from the files | disk → Qlik | [QOps-BuildTags](COMMAND-buildtags.md) |

**In the Portal.** Both are on the **Operations** panel. Open **All commands**, find them under
*Tags*, and either run one from the list or pin it so it gets a button of its own, see
[Choosing what the panel shows](COMMANDS.md#choosing-what-the-panel-shows).

**Needs.** **Qlik Sense only**, both of them. Against a Qlik Cloud or QlikView configuration each command says
so and stops. The panel disables them there.

## Flows

**Carry the tags from one environment to another.**

    QOps-PrepareTags -Filter "Name=Finance*"   # from the source environment
    QOps-BuildTags   -Filter "Name=Finance*"   # into the target one

**The two treat an empty filter differently.** `QOps-PrepareTags` with no filter uses the one the
repository has saved under `TagsFilter`. `QOps-BuildTags` with no filter creates **every** tag the
repository holds.

## See also

- [Commands](COMMANDS.md): the whole command map
