# QOps-PrepareDataConnections

**What it does.** Writes the connections this repository tracks into the repository as files, so they
can be version-controlled alongside the applications. This is what
[`QOps-Prepare`](COMMAND-prepare.md) does for applications.

**Direction.** Qlik → disk.

**In the Portal.** On the **Operations** panel as **Prepare connections**.

**Needs.** Qlik Sense **or** Qlik Cloud. Against a Qlik Cloud tenant the connection each space
carries for its own data files is left out — Qlik owns those, Build cannot recreate them, and a
repository holding one per space says nothing you can act on. The run reports how many it left out.

    QOps-PrepareDataConnections
    QOps-PrepareDataConnections -Filter "Name=lib_sales*"

## Which connections it writes

Given no `-Filter`, it uses the filter the repository has saved — the one
[`QOps-AddDataConnections`](COMMAND-adddataconnections.md) put there. That is what makes running it
with no arguments the normal case.

Given a `-Filter`, that filter wins for this run and the saved one is left alone.

With no filter given and none saved, it writes nothing and says so:

    QOps-PrepareDataConnections: no filter was given and none is saved in this repository, so no data
    connections were touched. Write commands do not act on everything by default - pass -Filter * to
    include every one of them, or a name or pattern to narrow it.

If it finds nothing after an Add, check the saved filter in
[Configuration](CONFIGURATION.md#the-repository-file).

## Flags

### -Filter

Which connections to act on. The same filter grammar the rest of QOps uses: `Name=`, `Id=`, `*` and
`?` as wildcards, and `;` between clauses when you want several.

    -Filter "Name=lib_sales*"
    -Filter "Name=lib_sales*;Name=lib_hr*"

> The `;` is part of the filter, not a separator the Portal invents. Typed into the panel it reaches
> the command intact, so a two-clause filter from the panel is the two-clause filter you wrote.

Left out, the repository's saved connection filter is used.

### -Sort

Which column the result is ordered by, by name. It changes the order of the output only, not which
connections are found.

### -Profile

Which configured authentication profile to use, when the repository has more than one. The same
switch as on every other command.

### -VerboseLog

Writes a fuller log for this run. Turn it on when you are going to send a log to somebody.

## See also

- [Data connections](COMMAND-dataconnections.md) — the group this command belongs to, and the flows it takes part in
- [QOps-BuildDataConnections](COMMAND-builddataconnections.md) — the other direction
- [Commands](COMMANDS.md) — the whole command map
