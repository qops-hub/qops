﻿# Configuration — the `.qopsconfig` files

QOps reads two configuration files. This page lists what is in each of them, and which command
writes each field.

| File | Where | What it holds |
|---|---|---|
| Global | `%USERPROFILE%\qopsconfig\.qopsconfig` | Connection profiles, and the defaults a repository inherits when it does not set its own. |
| Repository | `.qopsconfig` in the repository | Everything about one repository: which objects are processed, how files are written, and which profile it uses. |

The repository file is found by **walking up from the current directory** — the first `.qopsconfig`
at or above where you are. Running a cmdlet from a subfolder therefore uses that repository's
configuration, not a new one.

When no `.qopsconfig` is found, `QOps-Prepare` creates one in the current directory once it completes,
naming the profile it used; if it fails, nothing is written. Commands that only read, such as
`QOps-Apps`, use the profile from the global file outside a repository and create no `.qopsconfig`.

There is no third, per-user override file. A value is either in the global file or in the
repository's own.

## The repository file

These are the fields written into `.qopsconfig`. Credentials and server addresses are **not** among
them — they live in the profile, in the global file.

| Field | What it is | Set with |
|---|---|---|
| `Profile` | Which connection profile this repository uses. Naming a profile that does not exist creates it. | `QOps-SetConfig -Profile`, `QOps-Configure` |
| `Filter` | Which Qlik applications are processed. Wildcards allowed, masks separated by `;`. | `QOps-SetConfig -Filter`, `QOps-SetFilter`, `QOps-Configure` |
| `ExtensionsFilter` | Which extensions are processed. `*` by default. | `QOps-SetConfig -ExtensionsFilter`, `QOps-Configure` |
| `TagsFilter` | Which tags are processed. | `QOps-SetConfig -TagsFilter` |
| `TasksFilter` | Which reload tasks are processed. | `QOps-SetConfig -TasksFilter` |
| `CustomPropertiesFilter` | Which custom properties are processed. | `QOps-SetConfig -CustomPropertiesFilter` |
| `DataConnectionsFilter` | Which data connections are processed. | `QOps-SetConfig -DataConnectionsFilter` |
| `AppSubfolders` | Extra folders, relative to the repository root and separated by `;`, in which QOps looks for application folders, one level deep. The root itself is always scanned. No wildcards. Empty means the root only. See [Keep applications in subfolders](HOWTO-app-subfolders.md). | `QOps-SetConfig -AppSubfolders`, `QOps-Configure` |
| `Ignore` | Masks written into `.gitignore`, one line each, separated by `;`. | `QOps-SetConfig -Ignore`, `QOps-SetIgnore`, `QOps-Configure` |
| `Reduce` | Which files are saved with a reduced copy alongside the full one. Wildcards allowed, separated by `;`. Empty by default. | `QOps-SetConfig -Reduce`, `QOps-SetReduce`, `QOps-Configure` |
| `UseBuildDiffs` | `true` builds only the files that changed. `false` by default. | `QOps-SetConfig -UseBuildDiffs`, `QOps-Configure` |
| `SkipExtensions` | Whether extensions are skipped. `true` by default. | `QOps-SetConfig -SkipExtensions`, `QOps-Configure` |
| `IncludeBookmarks` | Whether bookmarks are included. `false` by default. | `QOps-Prepare`, `QOps-Build` |
| `AllBookmarks` | Whether every bookmark is included rather than only the published ones. `false` by default. | `QOps-Prepare`, `QOps-Build` |
| `SerializationType` | The FILE FORMAT QOps writes: `Yaml` or `Json`. Inherited from the global default when unset. | `QOps-SetConfig -SerializationType`, `QOps-Configure` |
| `StreamSerialization` | Which publish-target KEYS go into App files: `Space` or `Both`. `Space` when unset. See [The publish target in the app file](#the-publish-target-in-the-app-file). | `QOps-SetConfig -StreamSerialization`, `QOps-Configure` |
| `EOLStyle` | Line endings for text files, `LF` or `CRLF`. Inherited from the global default when unset. | `QOps-Configure` |
| `Placeholders` | Name/value pairs substituted when files are written. | Hand-edited |
| `ReloadTimeoutSeconds` | How long a Qlik Cloud reload is waited for, in seconds. `600` when unset. | Hand-edited |
| `UploadAttempts` | How many times one file upload is sent before QOps gives up on it, the first send included. `2` when unset, which is one retry; `1` turns retries off. | Hand-edited |
| `UploadRetryWaitSeconds` | How long QOps waits before sending a refused upload again, in seconds. `30` when unset. | Hand-edited |

`SerializationType` and `StreamSerialization` are easy to confuse: the first picks the **format** of
the file, the second picks **which keys go inside it**, in either format.

**`ReloadTimeoutSeconds` is how long QOps WAITS, not how long the reload may take.** When it runs out
QOps stops watching and reports the reload as **Unfinished** — not failed, because nothing failed and
nothing was cancelled: the reload carries on in Qlik Cloud and usually finishes. The run says so on the
console and names the reload id, so a reload you stopped waiting for is never confused with one the
tenant actually rejected. Ten minutes suits
most applications; raise it for the few that legitimately take longer. A single run can override it
without touching the file: `QOps-Reload -Timeout <seconds>`.

**`UploadAttempts` and `UploadRetryWaitSeconds` apply to every file QOps uploads** — application
content files, extensions and application files, on Qlik Sense and on Qlik Cloud. A Qlik Sense server
accepts a limited number of uploads in a short time and refuses the rest for a while; when that
happens, QOps waits and sends the file again. When the server says how long to wait, QOps waits exactly
that long instead of `UploadRetryWaitSeconds`. Each wait is written to the console with the file name,
the attempt and the number of seconds. A file that is still refused after the last attempt is reported
by name, and after the content files of an application QOps lists every file that was not uploaded. If
your server needs a longer pause, raise the wait or the number of attempts, for example:

```yaml
UploadAttempts: 3
UploadRetryWaitSeconds: 60
```

## The global file

The global file holds one or more **profiles** — a profile is a Qlik connection — plus the defaults
a repository inherits.

| Field | What it is | Set with |
|---|---|---|
| `SerializationType` | The default file format for repositories that do not set their own. | `QOps-SetConfig -GlobalSerializationType` |
| `EolStyle` | The default line-ending style for repositories that do not set their own. See [Line endings](#line-endings) for what applies when neither is set. | `QOps-SetConfig -GlobalEOLStyle`, `QOps-Configure` |
| `GitHubToken` | Your own GitHub token, sent by `QOps-Update` to the GitHub API. Optional. Stored encrypted. See [Your own GitHub token for updates](#your-own-github-token-for-updates). | `QOps-SetConfig -GitHubToken`, Portal: Environment settings → Global |
| `Profiles` | The connection profiles. | `QOps-Configure`, `QOps-SetConfig` |

Each profile holds:

| Field | What it is | Set with |
|---|---|---|
| `Mode` | `QlikSense`, `QlikSaaS` (Qlik Cloud) or `QlikView`. | `QOps-SetConfig -Mode`, `QOps-Configure` |
| `SenseUrl` | The Qlik Sense server. Port `4747` is assumed when none is given. | `QOps-SetConfig -SenseURL`, `QOps-Configure` |
| `SenseUser` | The Qlik Sense user, as `domain\user`. | `QOps-SetConfig -SenseUser`, `QOps-Configure` |
| `QlikSenseAuthMode` | `Certificate`, `QopsProxyViaAzureAD`, `JWT` or `QlikCloudOrg`. | `QOps-SetConfig -SenseAuthMode`, `QOps-Configure` |
| `SenseCertificate` | Path to the exported `.pfx` certificate. | `QOps-SetConfig -SenseCertificate`, `QOps-Configure` |
| `SensePassword` | The certificate password. Stored encrypted. | `QOps-SetConfig -SenseCertificatePassword`, `QOps-Configure` |
| `QopsProxyOauthUrl` | The proxy URL, for the Azure AD mode. | `QOps-SetConfig -QopsProxyOauthUrl`, `QOps-Configure` |
| `JwtToken` | The JWT, for the JWT mode. Stored encrypted. | `QOps-SetConfig -JwtToken`, `QOps-Configure` |
| `Prefix` | The virtual proxy prefix. | `QOps-SetConfig -Prefix`, `QOps-Configure` |
| `ApiKey` | The Qlik Cloud API key. Stored encrypted. | `QOps-SetConfig -ApiKey`, `QOps-Configure` |
| `OrgOAuthClientId` | The OAuth client id, for the `QlikCloudOrg` mode. An identifier, stored as it is. | `QOps-SetConfig -OrgOAuthClientId`, `QOps-Configure` |
| `OrgOAuthClientSecret` | The OAuth client secret. Stored encrypted. | `QOps-SetConfig -OrgOAuthClientSecret`, `QOps-Configure` |
| `TrustSelfSignedCerts` | Whether a self-signed server certificate is accepted. `true` by default. | `QOps-Configure` |

**How "stored encrypted" works.** On Windows, secrets are protected with Windows Data Protection for
your Windows account. On Linux and macOS, the cmdlets and the Portal store them the same way, so a secret
saved in the Portal is used by the cmdlets. Either way, the saved secrets work for the same user on the same
machine. Values saved earlier are converted automatically the next time QOps reads them inside a
repository. If you copy the file to another machine or use it as another user, QOps asks you to enter
the secrets again with `QOps-SetConfig`.

**Several users and service accounts on one machine.** Where the module is installed makes no
difference: the secrets are in each user's own `qopsconfig` folder, so every person and every service
account sets up its own with `QOps-SetConfig`, run as that account. For a service account (CI runner,
scheduled job) run it as the account itself, for example on Linux
`sudo -u svc-qops pwsh -c "QOps-SetConfig ..."`, rather than setting it up as yourself and copying the
file: a copied file asks for the secrets again. On Linux and macOS, do not run QOps with `sudo -E` or
any other `sudo` that keeps your home folder: QOps then runs as root on your file, cannot decrypt it with
root's key, and if you enter the secrets at that prompt it saves them for root, so your own next run
asks for them again. A `sudo` that switches to root's own home folder, the default on most Linux
distributions, is not affected; check `sudo pwsh -c '$HOME'` if unsure.

## When the global file cannot be read

If `%USERPROFILE%\qopsconfig\.qopsconfig` exists but QOps cannot read it (a typing mistake made by
hand, a file cut short, a file you have no permission to read), QOps changes nothing in it:

- The cmdlets stop with an error that names the file. This is also what `QOps-Configure` does.
- In the Portal, **Environment settings** shows a red banner with the file's path and the reason.
  The profile list is empty because nothing could be read, not because the profiles are gone.
  **Save changes**, adding a profile and removing one are all refused with the same text, and the
  file stays exactly as it is.

There are two ways out:

1. **Fix the file by hand.** The banner's **Copy path** button copies its location. Open it in a text
   editor, correct it, and reopen Environment settings.
2. **Back up and start fresh.** The file is renamed to `.qopsconfig.broken-<date>-<time>` in the same
   folder, and a new, empty global file is created. Your profiles stay in the backup and are no longer
   used: set them up again, or copy what you need from the backup. In the Portal this is the banner's
   **Back up and start fresh** button. On the command line it is `QOps-Configure -ResetGlobal`, which
   then runs the usual walk-through. `-ResetGlobal` refuses a file that reads fine; add `-Force` to
   back up and replace a readable file too.

A file that does not exist yet is not an error: the first save creates it.

QOps writes the global file to a temporary file in the same folder first and then puts it in place,
so a write that is interrupted leaves the previous file whole.

## Your own GitHub token for updates

`QOps-Update`, and the daily update check, download the published builds from GitHub. Without a
token GitHub allows 60 of these requests per hour, counted per public IP address. Everyone behind the
same company network address shares those 60, so an update can find them used up before it starts:

    Could not retrieve update file list for 'QOpsModule': GitHub API rate limit exceeded (60 requests per hour for unauthenticated clients). ...

With your own token the requests are counted for your GitHub account instead, 5000 per hour. The
token is optional; without one QOps calls GitHub anonymously, as before.

**What kind of token.** `qops-hub/qops` is a public repository, so the token needs no permissions at
all. Any GitHub account works, including a personal one.

1. On GitHub, open **Settings → Developer settings → Personal access tokens → Fine-grained tokens →
   Generate new token** (or go to `https://github.com/settings/personal-access-tokens/new`).
2. Give it a name, for example `QOps updates`, and pick an expiration.
3. Under **Repository access**, choose **Public repositories**. Every fine-grained token can read
   public repositories; this choice gives it nothing more.
4. Leave every permission at **No access**, and generate the token. Copy it: GitHub shows it once.

A classic personal access token with no scopes selected works as well.

**Setting it.** On the command line:

```powershell
QOps-SetConfig -GitHubToken
```

It asks for the token without showing what you type. In a script, pass a `SecureString` instead:
`QOps-SetConfig -GitHubTokenValue $secureToken`. In the Portal: **Environment settings → Global →
GitHub access for updates**. Either way the token is written to the global file, encrypted like the
other secrets there, and applies to every repository on the machine. It is not needed inside a
repository: the command works from any folder.

To remove it: `QOps-SetConfig -ClearGitHubToken`, or **Clear** in the same Portal section.

**Where QOps looks, in order.**

1. The token in the global file.
2. The `QOPS_GITHUB_TOKEN` environment variable, for build agents that should not keep a
   configuration file. QOps does not read the generic `GITHUB_TOKEN`: other tools set that one for
   their own purposes, and QOps should not send a token you never gave it.
3. Neither: the requests are anonymous.

**Where it is sent.** Only to `api.github.com`, in an `Authorization: Bearer` header. The file
downloads from `raw.githubusercontent.com` stay anonymous. QOps never writes the token to its log
files, its console output or its usage reports.

**When GitHub refuses it.** An expired, revoked or mistyped token is reported as such, and the update
stops there:

    GitHub rejected the GitHub token stored in the global QOps config (HTTP 401 Bad credentials): the token is invalid, expired or revoked. Replace it with QOps-SetConfig -GitHubToken, or remove it with QOps-SetConfig -ClearGitHubToken to update without a token

QOps does not quietly retry without the token, because that would hide a dead token until the shared
limit runs out again. Replace it, or clear it. A stored token that cannot be decrypted, for example
in a configuration copied from another machine or user, is reported as a warning and skipped; set it
again on this machine.

## Qlik Cloud with an OAuth client

`QlikCloudOrg` authenticates with an OAuth client instead of a per-tenant API key. QOps exchanges the
client id and secret for an access token against the tenant itself and renews it before it expires;
the token is held in memory for the length of the run and never written to disk.

Create the client in the Qlik Cloud management console under **OAuth**, and give it the **trusted**
consent method. A client left on the default consent method is refused at the token endpoint — the
refusal names the consent method, not the credential, so it is worth setting before anything else.
Any client type that issues a secret will do; a machine-to-machine client is not required.

The client is a subject of its own. It sees what it has been granted access to, so a client with no
access to the spaces holding your apps connects successfully and lists nothing.

Point a profile at it:

```powershell
$secret = Read-Host -AsSecureString "client secret"
QOps-SetConfig -Profile cloud -Mode QlikSaaS -SenseURL https://your-tenant.eu.qlikcloud.com `
               -SenseAuthMode QlikCloudOrg -OrgOAuthClientId <client id> -OrgOAuthClientSecretValue $secret
```

`-OrgOAuthClientSecret` is the same setting in switch form: pass it with no value and QOps asks for the
secret without echoing it. Use one or the other — together they are rejected.

`QOps-ShowDefault` prints the profile back, with the secret masked.

## The publish target in the app file

The app file (`App.yaml`, or `App.json` when that is your serialization format) carries the publish
target under two names — `Stream`, the Qlik Sense word for it, and `Space`, the Qlik Cloud word. They
are one value: set either and both carry it, `-Filter "stream=..."` and `-Filter "space=..."` both
select on it, and sorting accepts either spelling.

**Reading never changes.** An app file written by any version of QOps is read as it stands, whichever
of the two names it carries, with no end date.

**Which keys are written is `StreamSerialization`:**

| Value | What goes in the app file |
|---|---|
| `Both` | `Space` and `Stream`, with the same value. In YAML the `Stream` line is marked deprecated in a comment; JSON has no comments, so it gets both keys without one. |
| `Space` | Only `Space`. |

Choose `Both` while anyone on your team still runs an older QOps: those versions read only `Stream` on Qlik Sense and only `Space` on Qlik Cloud, so both keys have to be present for them to publish. Choose `Space` once everyone is on a version that understands both.

**The default is `Space`.** A repository whose `.qopsconfig` does not set `StreamSerialization` writes only `Space`, and a newly configured repository gets `StreamSerialization: Space` written into its `.qopsconfig`. Before QOps 3.1, a repository without the setting wrote both keys; to keep that, set `StreamSerialization: Both`, which is still honoured. Reading is not affected: app files that carry only the older `Stream` key are read as before.

The Portal follows the same setting. When you choose a target space for a Release in the Portal, it writes that space into the app file with the keys `StreamSerialization` asks for: only `Space` when the setting is `Space` or not set, in which case an older `Stream` key in that file is removed, and both keys, with the same comment on `Stream` in YAML, when it is `Both`.

If the two keys hold different values — which can only come from a hand edit — `Space` is the one
that counts, whichever key comes first in the file. QOps names the file and both values rather than
picking one quietly.

## Line endings

A text file written by QOps gets the line endings the repository asks for:

1. `EOLStyle` in the repository's `.qopsconfig` — `LF` or `CRLF`.
2. `EolStyle` in the global file, when the repository does not set one.

The style applies to the whole file: a file with mixed endings comes out with every line in that style.

The cmdlets go one step further when neither is set: they follow Git's own settings — `core.autocrlf`,
`core.eol` and `.gitattributes` — and finally the system's, in this order:

3. An `eol=lf` or `eol=crlf` attribute in the repository's `.gitattributes`, on `*`, `*.json` or
   `*.yaml`. `* text=auto` without `eol=` does not choose an ending, so QOps moves on to step 4.
4. Git's `core.autocrlf` and `core.eol`, read together: `core.autocrlf=true` means CRLF and
   `core.autocrlf=input` means LF; otherwise `core.eol=lf` or `core.eol=crlf` decides.
5. The system's own line ending: CRLF on Windows, LF on Linux and macOS.

The first step that gives an answer wins, and every cmdlet that writes files follows this same order.

The Portal stops after step 2 and leaves the file's endings as they are, so a bulk edit never
converts a repository that never asked for a style.

Editing inside the Portal's Diff panel keeps each line's own ending, because it writes only the block
you pointed at.

## The commands

| Command | What it does |
|---|---|
| `QOps-Configure` | Walks through the settings one at a time, showing the current value of each. `-ResetGlobal` first backs up a global file that cannot be read and starts a new one; see [When the global file cannot be read](#when-the-global-file-cannot-be-read). |
| `QOps-SetConfig` | Sets named fields without the walk-through. `-Global...` parameters and `-GitHubToken` write the global file; the rest write the repository's. |
| `QOps-SetFilter` | Sets the application filter for this repository. |
| `QOps-ClearFilters` | Clears the filters. |
| `QOps-SetIgnore` | Sets the ignore masks and writes them into `.gitignore`. |
| `QOps-SetReduce` | Sets the reduce masks. |
| `QOps-RemoveConfig` | Removes the configuration. |

Passing `-Profile` alone to `QOps-SetConfig`, with no other parameter, switches this repository to
that profile and changes nothing else.

## See also

- [User Guide](USER-GUIDE.md) — the Portal, end to end.
- [Getting Started](GETTING-STARTED.md) — a guided first run.
