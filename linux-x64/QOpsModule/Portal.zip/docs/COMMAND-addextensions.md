# QOps-AddExtensions

**What it does.** Records which extensions this repository tracks. It writes the set you chose into
the repository's own configuration, under `ExtensionsFilter`, and
[Prepare](COMMAND-prepareextensions.md), [Build](COMMAND-buildextensions.md) and
[Release](COMMAND-releaseextensions.md) read it from there when you give them no `-Filter` of their
own.

**Direction.** Configuration only. Nothing in Qlik changes, nothing is downloaded and no extension
files are written. This is not what **Add App** does: Add App downloads the app into the repository.
To get the extensions themselves into the repository, run [Prepare extensions](COMMAND-prepareextensions.md)
afterwards; [Build extensions](COMMAND-buildextensions.md) then uploads them to Qlik.

**In the Portal.** On the **Operations** panel, under **All commands**, as **Add extensions to config**.
The panel offers it on Qlik Sense and Qlik Cloud environments, where extensions can be listed.

    QOps-AddExtensions -Filter "Name=sales-*"

## Where the set comes from when you give no filter

Given no `-Filter`, this command uses what the last `QOps-ShowExtensions` found **in the same
PowerShell session**:

    QOps-ShowExtensions -Filter "Name=sales-*"
    QOps-AddExtensions

Given a `-Filter`, it uses what you typed and never consults what Show found.

The Portal runs each panel action in its own PowerShell process, so a Show run as one action and an
Add run as another share nothing. The panel therefore runs the pair in one go **when the filter box
is empty**:

    QOps-ShowExtensions; QOps-AddExtensions

and runs this command **on its own** when you have typed a filter:

    QOps-AddExtensions -Filter "Name=sales-*"

The command preview in the dialog shows whichever of the two it is about to run.

## Appending, and how to stop it

This command **adds to** the repository's saved extension filter; it does not replace it. Use
[`-NoAppend`](#noappend) when you want the new set to be the whole set.

## Flags

### -Filter

Which extensions to record. `Name=`, `*` and `?` as wildcards, and `;` between clauses.

    -Filter "Name=sales-*"
    -Filter "Name=sales-*;Name=hr-*"

Left out, the set comes from the preceding `QOps-ShowExtensions` in the same session, as above.

### -NoAppend

Replaces the repository's saved extension filter instead of adding to it.

### -Profile

Which configured authentication profile to use, when you run the command yourself. The Portal does
not offer it: the command runs in the repository, so it uses the repository profile, like Prepare and
Build do.

### -VerboseLog

Writes a fuller log for this run, with passwords, keys and tokens masked. Turn it on when you are going to send a log to somebody.

## See also

- [Extensions](COMMAND-extensions.md): the group this command belongs to, and how the commands fit together
- [Commands](COMMANDS.md): the whole command map
