# QOps-ShowExtensions

**What it does.** Lists the visualisation extensions and mashups the environment has. It changes
nothing, in Qlik or in the repository.

**Direction.** Qlik only.

**In the Portal.** On the **Operations** panel, under **All commands**, as **Show extensions**.

**Needs.** Qlik Sense or Qlik Cloud. On a QlikView environment the panel disables it.

    QOps-ShowExtensions
    QOps-ShowExtensions -Filter "Name=sales-*"

## What it lists with no filter

With no `-Filter` it uses the filter the repository has saved, if there is one, and otherwise lists
**everything** the environment has. That is the way to tell "my filter matched nothing" apart from
"this environment has no extensions".

## Flags

### -Filter

Which extensions to list. `Name=`, `*` and `?` as wildcards, and `;` between clauses.

    -Filter "Name=sales-*"
    -Filter "Name=sales-*;Name=hr-*"

Left out, the saved filter is used, or every extension when none is saved.

### -Sort

Which column the result is ordered by, by name. It changes the order of the output only, not what is
found.

### -Profile

Which configured authentication profile to use, when you run the command yourself. The Portal does
not offer it: the command runs in the repository, so it uses the repository profile, like Prepare and
Build do.

### -VerboseLog

Writes a fuller log for this run, with passwords, keys and tokens masked. Turn it on when you are going to send a log to somebody.

## See also

- [Extensions](COMMAND-extensions.md): the group this command belongs to, and how the commands fit together
- [Commands](COMMANDS.md): the whole command map
