# QOps-RemoveFile

**What it does.** Deletes a data file from a Qlik Cloud space.

**Direction.** Qlik only. Nothing arrives on your disk, and nothing local is read.

⚠️ **This is the one people reach for by mistake.** It deletes the file in Qlik, immediately and
without a confirmation prompt. If what you wanted was a copy of the file, that is
[`QOps-ExportFile`](COMMAND-exportfile.md).

**In the Portal.** On the **Operations** panel as **Remove file**. Open **All commands**, find it
under *Data files*, and either run it from the list or pin it so it gets a button of its own — see
[Choosing what the panel shows](COMMANDS.md#choosing-what-the-panel-shows).

**Needs.** Qlik Cloud. Run against a Qlik Sense or QlikView configuration it reports that data files
are supported only in Qlik Cloud mode and stops without doing anything.

    QOps-RemoveFile -Space Sales -File old-customers.qvd
    QOps-RemoveFile -Space Sales -File old-*.qvd

## What comes back

One object per file, carrying the file's `Name`, its `Id` in the space, and a `Status` of `Done` or
`Failed`. A run over a pattern returns as many objects as it matched, so

    (QOps-RemoveFile -Space Sales -File old-*.qvd).Count

is the number of files, not one.

One file failing does not stop the run. The others are still attempted, and the failures are in the
output with their reason in the log.

## Naming the files

`-File` takes either an exact name or a wildcard, so a set of files is one command rather than a
loop. It matches the names **in the space**.

A space can hold folders, and `-File` looks through all of them: `old-*.qvd` finds a matching file
inside a folder as well as one at the top. **`-QlikPath` confines it to one folder** — with
`-QlikPath archive/2025` the command only ever touches what is in there, and `-File` may then be
the plain file name, because you have said where to look.

    QOps-RemoveFile -Space Sales -QlikPath archive/2025 -File old-*.qvd

The path is relative to the space, written with `/` or `\`, and it is the same `-QlikPath` that
`QOps-ImportFile` puts a file into.

Nothing matching is not an error. The command says what it searched for and how many data files the
space holds, and returns nothing — so "wrong space" and "no such file" do not read identically. Given
that this command deletes, that distinction is worth reading before you widen the pattern.

## Flags

### -Space

The Qlik Cloud space holding the data files. Required. The space is found by name, and the API key
you are configured with has to be a member of it; if it is not, the command says so rather than
reporting an empty space.

### -File

The data file **in the space** to delete: an exact name or a wildcard. Required.

### -QlikPath

The folder **inside the space** to delete in. Optional. Omitted, `-File` is matched against the name
each data file has in the space, folders included; named, nothing outside that folder is touched, so
a file of the same name elsewhere in the space is left alone.

    QOps-RemoveFile -Space Sales -QlikPath archive/2025 -File old-*.qvd

Written with `/` or `\`, relative to the space.

**The folder you name includes everything under it.** `-QlikPath archive` covers `archive/old-1.qvd`
and `archive/2025/old-2.qvd` alike: it bounds the search from above, it does not pick out one level.
A plain `-File` name is matched against the file name on its own, so `-QlikPath archive -File
sales.qvd` selects `archive/sales.qvd` **and** `archive/2025/sales.qvd`. Name the deepest folder you
mean when you want only that one.

Given that this command deletes, this is the flag that decides how far a wildcard reaches: it is the
difference between "the old files in that folder and below it" and "every file in the space whose
name looks like that".

### -Profile

Which configured authentication profile to use, when you run the command yourself. The Portal does
not offer it: the command runs in the repository, so it uses the repository profile, like Prepare and
Build do.

### -VerboseLog

Writes a fuller log for this run, with passwords, keys and tokens masked. Turn it on when you are going to send a log to somebody.

## See also

- [Data files](COMMAND-datafiles.md) — the group this command belongs to, and the flows it takes part in
- [QOps-ExportFile](COMMAND-exportfile.md) — taking a copy before you delete
- [QOps-ImportFile](COMMAND-importfile.md) — putting a file into the space
- [Commands](COMMANDS.md) — the whole command map
