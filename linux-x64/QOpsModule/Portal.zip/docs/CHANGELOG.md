# Changelog

What changed in QOps, written for the person using it. Each entry says what is different when you sit
down in front of the product.

Versions are ordered newest first. A version heading is `## <version> — <date>`, kept in that exact
shape so it can be parsed: the Portal will show a version's notes in-app rather than sending you to
the website.

This page carries the current release and the one before it. Everything earlier is in
[Earlier releases](CHANGELOG-ARCHIVE.md), in the same shape and linked version by version at the
bottom of this page.

---

## 3.1.4 — 2026-11-13

### Studio: .qvs files get proper syntax highlighting and breadcrumbs

A `.qvs` file opens in the Studio editor as a Qlik load script, with load-script syntax highlighting, `Ctrl+/` comments
and folding by `///$tab` section and block. As you type, Studio suggests load-script statements and
functions (`Ctrl+Space` to ask); a suggestion fills in the whole statement with placeholders, and `Tab`
moves between them. `Ctrl+Shift+O` lists the script's tabs with the subroutines and tables in each; pick one to
jump to it. A bar above the script shows where the cursor is, such as `Main › SUB LoadCalendar ›
Calendar`; click a part of it to jump to another tab, subroutine or table at that level.

### Studio: master item ids get inlay hints and link to the item's file

In an object file opened in Studio, an id such as `qLibraryId` shows the title of the object it points to,
for example `master measure: Total Sales`. Hover it for the description and file, Ctrl+Click to open that
file. A reference to a deleted master item shows `Object not found by ID`.

### Studio: rename an object or change its id from the file tree

Right-click a sheet, chart or master item in the Studio file tree and choose Rename or Change id. Change id
rewrites every reference to the object in the app, after a preview of every line that will change, and
writes all of it or nothing. The result stays in the working tree for you to review and commit.

### Operations panel: extensions, custom properties, tags and reload tasks

**All commands** on the Operations panel has groups for extensions, custom properties, tags and reload
tasks, so you can run Prepare and Build for them from the Portal without typing a command. **Dry Run** applies
to every command on the panel, including those that open a dialog, and every command uses the repository
profile.

### Lineage panel: master items, fields and variables, a compact layout and Isolate

The Lineage panel now draws lines from charts and master objects to the master items they use, and the
**Fields** toggle adds the app's fields and variables. **Compact** lays the graph out left to right, from
tables and fields to sheets, with no overlapping labels, and **Isolate** shows only one node's lineage. For
example, isolate a sheet of a large app to see just its charts, the master items they use and the fields
behind them, at full size.

### AI assistant (MCP): what uses a field or a master item, and where a field comes from

Ask the assistant "what uses the field `Target`?" or "where does `Region` come from?" and `get_lineage`
answers from a repository or from the live app in the engine. It lists the master items, charts and sheets
that read the field, through variables and master objects, and says the path to each chart in words. For
where a field comes from it gives the tables that load it and their data connection, from the load script
or the engine's lineage of the last reload, and names what in the script it could not follow instead of
guessing. When nothing is found to use a field, the answer says this does not prove the field is unused,
so the assistant does not advise removing it on that basis.

### AI assistant (MCP): labels for chart dimensions and measures

When the assistant creates a chart, it can give each dimension and measure its own label, so the table
header reads `Paywall shown` instead of `Count({<Event={paywall_shown}>} Event)`.

### Use the chat through a company LLM gateway

When the chat provider is Claude, **Settings → Global → Chat → Advanced settings** has an optional
**Base URL**. Enter the address of your company's gateway, and the chat goes through it instead of
`api.anthropic.com`. The gateway must accept Anthropic API requests; gateways that only offer the OpenAI
format are not supported, and the Gemini provider has no Base URL. Left empty, the chat works as before.

If Claude Code is already set up for the gateway, **Settings → Global → Chat → Advanced settings → Import
from Claude Code settings…** takes the same settings: the gateway address, the token, the default model and the model
list with its labels. It shows what will be set, with the token masked, before anything is saved.

### Send a support case from QOps in one command

[`QOps-SendSupportCase`](COMMAND-sendsupportcase.md) collects the logs and system details support needs,
masks passwords, tokens, connection strings and your licence serial, shows what it will send and asks
first, then prints the case number. It works without a licence and when the Portal is down; `-OutFile`
only writes the zip.

### Two QOps runs on the same app take turns

Before a Build or Release changes an app (on Qlik Cloud, also a Publish that updates an app in place), it places a small marker object in the app; the marker
is removed before the app is saved and never ends up in the repository. A second run on the same app, for
example a pipeline started while a colleague's Release is still going, waits for the first to finish and
names the run it waits for. After 10 minutes it stops with an error and changes nothing, so you can run it
again later. A running QOps renews its marker every 20 seconds; a marker that has not been renewed for 2
minutes, because its run crashed or lost the connection, is taken over.

### Fixes

- **On Qlik Cloud, commands work with an app right after it is created, copied or moved.**
  `QOps-Release`, `QOps-Publish` into a managed space and `QOps-Prepare` skip an app deleted a moment
  earlier that Qlik Cloud still lists, with a line in the log.
- **A Qlik Cloud Build or Publish that loses its engine connection stops at once** and names the app that
  may be partly updated, so it can be run again.
- **Concurrent `QOps-Prepare` runs on the same app from different repositories don't lose files.** If a
  project folder has lost `App.yaml` or `Script.qvs`, the next Prepare of that app writes the folder
  again from the app in Qlik and says in the log which files were missing.
- **A Build or Release keeps every object on its sheet and needs fewer calls to the Qlik engine**, which is
  most noticeable on Qlik Cloud and slow networks.
- **The Portal keeps logs for a support request**: earlier sessions as `portal.log.1` to `portal.log.5`, a
  log for every operation from the moment it starts, and the logs of failed command runs for 30 days.
- **The Portal closes operations it did not finish as interrupted**, and `QOps-StopPortal` shuts the
  Portal down the same way **Dashboard → Shut down Portal** does.
- **AI assistant (MCP):** reading master measures, master dimensions and variables is faster and does not
  hold up the next call; a call the engine does not answer in time closes its session, and the next call
  opens a new one.
- **AI assistant (MCP):** a refused chart write names the property path to send; replacing a chart's sort
  replaces it completely; a tool that works on repository files but was given a Qlik profile, or a
  live-app tool given a repository, says which kind of input it takes and names the tool to use instead.
- **Lineage links fields with an apostrophe in their name to their table.**

## 3.1.3 — 2026-11-04

### Commands and the Portal store saved credentials the same way on Linux and macOS; your licence serial is restricted to your account

Passwords, API keys, tokens and client secrets saved with [QOps-SetConfig](COMMAND-setconfig.md#which-of-the-two-configuration-commands-you-want), `QOps-Configure` or
`QOps-SetSensePassword`, or in the Portal's Environment settings, are encrypted the same way. Commands
such as `QOps-Apps` read the credentials saved in the Portal both inside a repository and from a folder
without a `.qopsconfig`, for example right after `QOps-StartPortal` in a GitHub Codespace. Values saved
with an earlier version are converted the next time QOps reads them inside a repository.

Your licence serial is readable only by your own account and the system account. QOps restricts the
`qopsconfig` folder, the `license.key` file, the `IPManager` activation folder and the activation files
in it to these two accounts: mode 600 for the file and 700 for the folders on Linux and macOS, and on
Windows an access list with inheritance disabled that holds only your account and the system account.
The restriction is applied when these are created and again on every write, so existing files and
folders are restricted the next time QOps writes them. If the permissions cannot be changed, QOps
carries on and the licence check is not affected.

### AI assistant (MCP): a shorter tool list, and smaller answers for chart settings, sheet lists and dry runs

The list of tools the assistant receives gives each tool a short description of what it does and when
to use it, so the list takes about a third of the room it took in the assistant's conversation. The
details of a tool (what each argument means, the accepted values, examples) come from the new
`describe_tool`, which the assistant calls for one tool when it needs them.

`list_chart_customisations` needs a chart type; without one, or with an unknown one, it answers with
the list of valid types. By default it returns the names of the settings for that type. Ask for up to
10 settings by name (`settings`) to get their description, current value and a ready patch. This keeps
each answer small enough for the assistant's conversation.

`list_sheets` answers with the id, title and object count of each sheet, 100 sheets to a page, and a
page stays under about 27,600 characters. The assistant finds a sheet by part of its title
(`titleContains`), or names sheets by id (`sheetIds`) to get only those, each with the id and type of
every object on it. When the full list is too large for one answer, it is also written once to a file
in the `.mcp-files` folder, and the answer gives its path.

`set_object_properties` and `apply_object_patches` with `dryRun` return the changed paths, each with its
old and new value, instead of the whole object before and after. Long values are shortened, and more
than 50 changed paths are cut with a note saying how many there are in total.

When such a dry run would change more than fits in one reply, the reply gives the counts per kind of
change and lists as many changed paths as fit, the paths that would be removed first. The full before
and after of every changed path is written once to a result file named in `fullResultPath`.

### AI assistant (MCP): chart sorting that Qlik applies

Ask the assistant to sort the dimension of a pie chart alphabetically, numerically or by an expression,
or to sort its measure numerically or alphabetically, and the chart is changed the same way Qlik stores
it when you choose that sorting yourself: the Sorting is switched from Auto to Custom in the same
change.

When `apply_object_patches` or `set_object_properties` writes the sort of a chart dimension or measure
while its Sorting stays on Auto, the change is refused before anything is written, a preview included,
and the answer says to switch that Sorting to Custom in the same change or to use the sort settings of
`list_chart_customisations`, which do both.

### Fixes

- **Activation and deactivation work when your Windows profile folder has a different name from your account.** For example, the account `jsmith` with the profile folder `C:\Users\John`. QOps keeps the activation files in your own roaming AppData folder (`IPManager`) and the file it reads them with in your `qopsconfig` folder, next to `license.key`. Files that an earlier version put in a folder named after the account are copied there once, on first use, and the existing activation keeps working. The originals stay where they were, so an earlier QOps version still finds them, and a later deactivation is not undone by copying them again. If a file exists in both places, the one in your profile is used and the other is left as it is. When QOps-Deactivate releases the licence but cannot remove a local file, it says so and names each file it left behind.

- **QOps-Push commits and pushes with the message, branch name, remote URL and folder exactly as written.** A commit message with spaces, quotes, semicolons, brackets, `$` or backticks is recorded word for word, and such characters in a branch name, URL or folder path are passed to git as plain text.

- **QOps-CleanSessions outside Qlik Sense says it works only with Qlik Sense.** In a Qlik Cloud profile, or in any mode other than Qlik Sense, the command says that cleaning sessions works only with Qlik Sense and does nothing.

---

## Earlier releases

Notes for the releases before the two above, newest first:

- [3.1.2 — 2026-11-02](CHANGELOG-ARCHIVE.md#3-1-2-2026-11-02)
- [3.1.1 — 2026-10-23](CHANGELOG-ARCHIVE.md#3-1-1-2026-10-23)
- [3.1.0 — 2026-10-13](CHANGELOG-ARCHIVE.md#3-1-0-2026-10-13)
- [3.0.23 — 2026-10-08](CHANGELOG-ARCHIVE.md#3-0-23-2026-10-08)
- [3.0.22 — 2026-10-06](CHANGELOG-ARCHIVE.md#3-0-22-2026-10-06)
- [3.0.21 — 2026-09-25](CHANGELOG-ARCHIVE.md#3-0-21-2026-09-25)
- [3.0.20 — 2026-09-22](CHANGELOG-ARCHIVE.md#3-0-20-2026-09-22)
- [3.0.19 — 2026-09-18](CHANGELOG-ARCHIVE.md#3-0-19-2026-09-18)
- [3.0.18 — 2026-09-18](CHANGELOG-ARCHIVE.md#3-0-18-2026-09-18)
- [3.0.17 — 2026-09-17](CHANGELOG-ARCHIVE.md#3-0-17-2026-09-17)
- [3.0.16 — 2026-09-14](CHANGELOG-ARCHIVE.md#3-0-16-2026-09-14)
- [3.0.15 — 2026-09-11](CHANGELOG-ARCHIVE.md#3-0-15-2026-09-11)
- [3.0.14 — 2026-09-04](CHANGELOG-ARCHIVE.md#3-0-14-2026-09-04)
- [3.0.13 — 2026-08-24](CHANGELOG-ARCHIVE.md#3-0-13-2026-08-24)
- [3.0.12 — 2026-08-13](CHANGELOG-ARCHIVE.md#3-0-12-2026-08-13)
- [3.0.11 — 2026-08-07](CHANGELOG-ARCHIVE.md#3-0-11-2026-08-07)
- [3.0.10 — 2026-07-28](CHANGELOG-ARCHIVE.md#3-0-10-2026-07-28)
