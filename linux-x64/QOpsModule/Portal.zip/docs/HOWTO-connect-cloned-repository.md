# Connect a freshly cloned repository to your Qlik environment

**Goal:** after cloning a QOps repository, bind each application folder to the application that already
exists on your Qlik environment, so that builds update those applications instead of creating new ones.

This page applies to Qlik Sense and Qlik Cloud.

## When you need this

- You cloned a repository onto a new machine, or into a new folder.
- The applications it holds already exist on the environment you connect to, usually under different
  Qlik ids than the ones the repository was prepared from.

Right after a clone no folder knows its application on your environment. The binding lives in
`App.local.yaml`, which is never committed, so a clone never has it. The committed `Id` in `App.yaml`
names the folder, and on your environment it usually matches nothing. (When the repository was
prepared from this same environment, a committed `Id` can be the application's own Qlik id; such a
folder already resolves and needs no binding.) The model is explained in
[How does QOps know which Qlik application a repository folder belongs to?](HOWTO-app-identity.md)

Binding the folders with `QOps-SetLocalApp` is the intended way to set up a clone. If the applications
do not exist on your environment yet, you want
[Set up a repository's applications on another Qlik environment](HOWTO-set-up-another-environment.md)
instead.

## Before you start

QOps is installed, licensed and has a connection profile for the environment. See
[Before you start](GETTING-STARTED.md#before-you-start). Run the commands below from the root of the
cloned repository.

## Steps

### 1. List the folders and their committed Ids

Each folder is addressed by the `Id` in its `App.yaml`, not by its name and not by a Qlik id:

```powershell
Get-ChildItem -Recurse -Depth 1 -Filter App.yaml | Select-String -Pattern '^Id:'
```

For a JSON repository, search `App.json` for `"Id"` instead. A folder whose `Id` is empty cannot be
bound yet; see [Common mistakes](#common-mistakes).

### 2. Find the id of each application on your environment

Open the application in the Qlik Sense hub or in Qlik Cloud. Its id is the part of the address after
`/app/`, for example `https://qlik.example.com/sense/app/6f1c2a90-3d40-4a1e-9f77-0c0be8b5f1d2`.

In the Portal you do not need to look it up: the **Set local App** dialog lists the applications on the
environment you are connected to, and you pick one.

### 3. Bind each folder

```powershell
QOps-SetLocalApp -OriginAppId 'Sales Overview-prj' -TargetAppId 6f1c2a90-3d40-4a1e-9f77-0c0be8b5f1d2
```

`-OriginAppId` is the committed `Id` from step 1. `-TargetAppId` is the Qlik id from step 2. Repeat for
every folder. The command writes `App.local.yaml` beside the folder's `App.yaml` and does not contact
Qlik.

In the Portal: right-click the application's `-prj` folder in the Studio file tree and choose
**Set local App…**, or open **Operations → All commands → Set local App**. The dialog lists the
applications on the environment you are connected to, so you pick the target instead of typing its id.

### 4. Decide which side is current, then run the first operation

- If the **environment** holds the latest version of the applications, bring it into the files with
  [QOps-Prepare](COMMAND-prepare.md) and review the difference in Git before you commit. In the Portal:
  **Operations → Prepare**.
- If the **repository** holds the latest version, build with `-UpdateOnly`:

  ```powershell
  QOps-Build -UpdateOnly
  ```

  `-UpdateOnly` builds only the folders that resolve to an application on this environment and never
  creates one. Any folder you missed in step 3 is skipped with a line that prints the exact
  `QOps-SetLocalApp` command it needs. See [-UpdateOnly](COMMAND-build.md#updateonly).

  In the Portal: **Operations → Flags / Options**, set **Operation** to Build, switch on
  **Update only (skip apps not on the server)**, then press **Build**.

`QOps-Build -UpdateOnly` is also a safe first build when you are not sure every folder is bound. It
writes the repository into the applications that resolve, so use it only when the repository is the
version you want on the environment.

## How to check it worked

- Every application folder now has an `App.local.yaml` whose `Id` is the application on your
  environment.
- `git status` shows no change: `App.local` files are ignored, and `App.yaml` is untouched.
- `QOps-Build -UpdateOnly` reports no line starting with `[Warning] '<name>' (folder '...') was skipped`
  for these folders, and the build log says `Found existing app:` for each of them rather than
  `Created new app:`.

## If it did not work

These are the lines QOps prints when this task goes wrong, as they appear in the output.

**A folder you did not bind, or bound to an id that is not on this server.** `QOps-Build -UpdateOnly`
skips it and prints:

```text
[Warning] '<name>' (folder '<folder>') was skipped: -UpdateOnly builds only apps that resolve on the server, and its Id '<id>' (from App.yaml) is not an app on this server. If it belongs to an app that already exists, map it: QOps-SetLocalApp -OriginAppId '<committed id>' -TargetAppId <server app id>. Nothing was created. To build it into a new app instead, run the build without -UpdateOnly.
```

`(from App.yaml)` means the folder has no binding yet: run the printed command with the application's
id from step 2. `(from App.local.yaml)` means the folder is bound, but to an id this server does not
have, usually a mistyped one: run `QOps-SetLocalApp` again with the right id. In a JSON repository the
line says `App.json` and `App.local.json`.

**`QOps-SetLocalApp` did not find the folder.** It prints the id it looked for and writes nothing:

```text
Can`t find app with id <id>
```

No folder's `App.yaml` has that `Id`. Take the `-OriginAppId` from step 1, exactly as it is written
there, not the folder name or a Qlik id.

## Common mistakes

- **Running a plain `QOps-Build` before binding.** A folder whose `Id` matches nothing on this server is
  built into a new application, which is a second copy next to the one already there. If it happened,
  delete the extra application in Qlik, run `QOps-SetLocalApp` for that folder (it replaces the binding)
  and build again.
- **Passing the wrong id as `-OriginAppId`.** It is the committed `Id` in `App.yaml`, not the folder
  name (unless the two are the same) and not the Qlik id. A wrong one fails with
  ``Can`t find app with id <id>`` and writes nothing.
- **A folder with no `Id`.** `QOps-SetLocalApp` finds folders by their committed `Id`, so an empty one
  cannot be bound. Give it one first, for example the folder name (`Id: Sales Overview-prj`), commit that
  change, then bind it.
- **A mistyped target.** `QOps-SetLocalApp` does not check that the target exists. The next
  `QOps-Build -UpdateOnly` reports the folder as not on this server; run `QOps-SetLocalApp` again with the
  right id.
- **Binding to an application a build does not write in place.** On Qlik Sense that is a published
  application or one owned by somebody else; on Qlik Cloud also one in a shared or managed space.
  `QOps-Build -UpdateOnly` skips such a folder and says why. A plain `QOps-Build` creates a copy in your
  own area and binds `App.local` to the copy. Bind the folder to your own development copy, and reach the
  published application with [QOps-Publish](COMMAND-publish.md) or [QOps-Release](COMMAND-release.md).
  The skip line reads, for an application in a space on Qlik Cloud:

  ```text
  [Warning] '<name>' was skipped: -UpdateOnly never creates an app, and it lives in the space '<space>', so a build would create a copy of it instead of updating it. Nothing was created. Run the build without -UpdateOnly to let it make that copy.
  ```

  In place of `it lives in the space '<space>'` it can say `it is published` or that the application
  is owned by somebody else.
- **Undoing a binding.** Delete the folder's `App.local.yaml`. There is no command that clears it.

**Next:** once `QOps-Build -UpdateOnly` has written the repository into your applications, put the
result in front of other people with [QOps-Publish](COMMAND-publish.md), which moves an application to
its stream or space, or build and publish in one run with [QOps-Release](COMMAND-release.md).

## See also

- [How does QOps know which Qlik application a repository folder belongs to?](HOWTO-app-identity.md)
- [QOps-SetLocalApp](COMMAND-setlocalapp.md)
- [QOps-Build: -UpdateOnly](COMMAND-build.md#updateonly)
- [How-to guides](HOWTO.md)
