# QOps-SendSupportCase

**What it does.** Collects what QOps support needs to look into a problem on this computer, masks every
secret in it, shows you the list of files, and sends them to QOps support as one zip. With `-OutFile` it
only writes the zip to disk and sends nothing.

**Direction.** This computer to QOps support. Nothing is sent to Qlik.

**When you need it.** When a run fails, hangs or stays "running" in the Portal, and support asks for the
details. It works without a licence and does not update QOps, so it also works when the licence or the
Portal is the problem.

    QOps-SendSupportCase -Description "Release to production stays running since 16:24"
    QOps-SendSupportCase -Since (Get-Date).AddDays(-7) -Email me@example.com
    QOps-SendSupportCase -OutFile C:\Temp\
    QOps-SendSupportCase -CaseFile C:\Temp\qops-case-20261118-101500.zip -Email me@example.com

In the Portal, the same is **Help → Send support case**: it shows the files first and sends them after you
agree (see [From the Portal](#from-the-portal)).

Run it as the same Windows user that runs QOps and the Portal: the logs it reads are that user's.

## What goes into the case

| File | What it holds |
|---|---|
| `manifest.txt` | Every file in the zip with its size and how many values were masked in it, and everything that could not be collected and why |
| `module-logs/` | The QOps command logs written since `-Since` |
| `portal-logs/` | The Portal's own log, `portal.log`, and the previous ones kept beside it, with their content |
| `portal-data/` | The Portal's operation history and the logs of the operations run since `-Since` |
| `pending-runs/` | The markers of QOps runs that started and did not finish |
| `processes.txt` | The QOps, Portal and PowerShell processes running now: id, start time and command line |
| `events-application.txt`, `events-system.txt` | Windows errors and warnings since `-Since`, and the start, stop, crash and sleep events of the computer. Windows only |
| `listing-*.txt` | The names, sizes and dates of the files in the QOps log folder and in `qopsconfig`. No content |
| `config-keys.txt` | The setting names in your `.qopsconfig` files and your profile names. No values |
| `module-versions.txt`, `system.txt` | The QOps versions installed for both PowerShell editions, and the Windows, PowerShell and .NET versions |
| `description.txt` | What you wrote in `-Description` |

What is missing on your computer is not an error: the command collects what is there and says in
`manifest.txt` what it did not find.

The zip is kept under 25 MB. When the logs make it larger, the oldest logs are left out first, and
`manifest.txt` names them.

## What is masked

Before anything is written into the zip, these are replaced by `***`: passwords, tokens, API keys,
OAuth and Bearer credentials, JWTs, GitHub tokens, client secrets, passwords in connection strings,
certificate passwords, credentials in URLs, private keys, the encrypted credentials QOps stores, and
your licence serial, also where it is part of a file name. The licence code that goes with the case
shows only its first and last four characters, for example `C4A1***DC27`, so support can tell whose
case it is.

## Before it sends

The command prints every file and the total size, then asks whether to send them. Answer **No** and
nothing is sent and nothing is written. `-WhatIf` shows the list and stops.

## What comes back

One object:

| Field | What it holds |
|---|---|
| `CaseId` | The support case number, when the case was received |
| `Uploaded` | `True` when support received the case |
| `CaseFile` | The zip on this computer. It is kept whether the case was sent or not |
| `FailureReason` | Why the case was not sent; empty when it was |
| `Files` | The names of the files in the zip |
| `Size` | Their size in bytes |
| `MaskedCount` | How many values were masked |

When the case is received the command prints `Support case <number> received`. Quote that number
when you write to support.

## When sending fails

The zip is written to your temporary folder before it is sent, so a failed upload loses nothing. The
command then prints the reason and where the zip is:

    Upload failed (<reason>). The case was saved to <path>; send it through https://qops.datalabsua.com/technical-support/

Send that file through the [technical support form](https://qops.datalabsua.com/technical-support/).
Sometimes a case is opened but the zip cannot be attached to it. The reason then names the case number:
quote it in the form, and do not run the command again, which would open a second case.

## From the Portal

**Help → Send support case** (also in the command palette) runs this command for you. It first writes the
case with `-OutFile` into a folder of the Portal's own and shows every file in it, its size and how many
values were masked. You can add a description and an e-mail address, both optional. Nothing is sent until
you tick the box to agree and press **Send**; then the Portal sends that same zip with `-CaseFile`, and
shows the case number. When it cannot be sent, the Portal shows the reason, offers the zip as a download
and links the [technical support form](https://qops.datalabsua.com/technical-support/). It needs no licence
and no Qlik connection.
It can be used only on the computer that runs the Portal and from the addresses listed in
`Portal:AdminAllowedAddresses`; opened from any other computer, the dialog says *Sending a support case is not available from this computer. Contact
your administrator.* and links the support form instead.

From the Portal, the description goes with the case as its description, and is not added to the zip as
`description.txt`: the zip is sent exactly as it was shown.

## Flags

### -Description

What happened, in your own words: what you ran, what you expected, what you saw. It is masked like
everything else and goes into the zip as `description.txt`.

### -Since

How far back the logs, the Portal's operations and the Windows events go. Default: the last three days.

    QOps-SendSupportCase -Since "2026-11-08 16:00"

### -Email

An address support can answer on. It is sent with the case and is not written into the zip.

### -OutFile

Write the zip here and send nothing. A folder gets a file named `qops-case-<date>-<time>.zip` inside
it. Send the file through the [technical support form](https://qops.datalabsua.com/technical-support/).

### -CaseFile

Send a zip written earlier with `-OutFile`, unchanged, instead of collecting a new case. What the zip held
when you wrote it is what is sent. `-Description` and `-Email` go with it; the zip itself is not changed,
so the description is not added to it as `description.txt`. `-Since` has no effect. A file that is not a
case written by this command is refused. It cannot be used together with `-OutFile`.

    QOps-SendSupportCase -OutFile C:\Temp\
    QOps-SendSupportCase -CaseFile C:\Temp\qops-case-20261118-101500.zip -Description "Release hangs"

### -Force

Send without asking. Use it in a script, where there is nobody to answer the question.

### -WhatIf

Collect and show the list of files, write nothing and send nothing.

## See also

- [Commands](COMMANDS.md)
