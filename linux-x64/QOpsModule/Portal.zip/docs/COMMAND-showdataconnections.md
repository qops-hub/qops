# QOps-ShowDataConnections

**What it does.** Lists the data connections a Qlik environment has — the `lib://` connections a
load script reads through. It only looks; nothing in Qlik and nothing in the repository changes.

**Direction.** Qlik only.

**In the Portal.** On the **Operations** panel as **Show connections**. Open **All commands**, find
it under *Data connections*, and either run it from the list or pin it — see
[Choosing what the panel shows](COMMANDS.md#choosing-what-the-panel-shows).

**Needs.** Works against both Qlik Sense and Qlik Cloud.

    QOps-ShowDataConnections
    QOps-ShowDataConnections -Filter "Name=lib_*"

## What comes back

One object per connection. Left with no filter it lists everything the environment has, which is the
way to tell "the filter matched nothing" apart from "this environment has no connections".

## Flags

### -Filter

Which connections to act on. The same filter grammar the rest of QOps uses: `Name=`, `Id=`, `*` and
`?` as wildcards, and `;` between clauses when you want several.

    -Filter "Name=lib_sales*"
    -Filter "Name=lib_sales*;Name=lib_hr*"

> The `;` is part of the filter, not a separator the Portal invents. Typed into the panel it reaches
> the command intact, so a two-clause filter from the panel is the two-clause filter you wrote.

Left out, everything is listed.

### -Sort

Which column the result is ordered by, by name. It changes the order of the output only, not which
connections are found.

### -Profile

Which configured authentication profile to use, when the repository has more than one. The same
switch as on every other command.

### -VerboseLog

Writes a fuller log for this run, with passwords, keys and tokens masked. Turn it on when you are going to send a log to somebody.

## See also

- [Data connections](COMMAND-dataconnections.md) — the group this command belongs to, and the flows it takes part in
- [QOps-AddDataConnections](COMMAND-adddataconnections.md) — recording the set you just listed
- [Commands](COMMANDS.md) — the whole command map
