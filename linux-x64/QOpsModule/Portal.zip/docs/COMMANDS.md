# Commands

Every operation the Portal runs is a QOps command, and every command has switches that change what it
does. This page is the map: what each command is for, which command to reach for when two of them
sound alike, and where the reference for each one lives.

The per-command pages are not listed in the Help menu on the left — there are enough of them to bury
the manuals they sit beside. They are reached from here, from the ⓘ next to **Flags / Options** in the
Operations panel, from the link inside the flags that the ⓘ beside a command opens in place, and from
the release notes, which link to the exact section that changed.

## The application operations

These five work on applications. The panel builds the command for you and shows it before it runs; the
pages below say what each switch in that command does.

| Command | What it does | Direction |
|---|---|---|
| [QOps-Prepare](COMMAND-prepare.md) | Writes an application from Qlik into the repository as files | Qlik → disk |
| [QOps-Build](COMMAND-build.md) | Writes the files in the repository back into a Qlik application | disk → Qlik |
| [QOps-Reload](COMMAND-reload.md) | Reloads an application's data in Qlik | Qlik only |
| [QOps-Reload -Status](COMMAND-reload-status.md) | Reports what an application's last reload did, and starts nothing | Qlik only |
| [QOps-Publish](COMMAND-publish.md) | Moves an application to its target stream or space | Qlik only |
| [QOps-Release](COMMAND-release.md) | Build and publish in one run | disk → Qlik |

## Working on data files and data connections

These do not work on applications, so they take no application selector: each one names its own
subject. They are on the Operations panel under **All commands**.

| Command | What it does | Direction |
|---|---|---|
| [QOps-ImportFile](COMMAND-importfile.md) | Uploads a file into a Qlik Cloud space's data files | disk → Qlik |
| [QOps-ExportFile](COMMAND-exportfile.md) | Brings a data file down into a local folder | Qlik → disk |
| [QOps-RemoveFile](COMMAND-removefile.md) | Deletes a data file from the space | Qlik only |
| [QOps-ShowDataConnections](COMMAND-showdataconnections.md) | Lists the data connections the environment has | Qlik only |
| [QOps-AddDataConnections](COMMAND-adddataconnections.md) | Records which connections the repository tracks | configuration |
| [QOps-PrepareDataConnections](COMMAND-preparedataconnections.md) | Writes the tracked connections into the repository | Qlik → disk |
| [QOps-BuildDataConnections](COMMAND-builddataconnections.md) | Creates those connections in Qlik from the files | disk → Qlik |

The three data-file commands are **Qlik Cloud only**. `QOps-PrepareDataConnections` and
`QOps-BuildDataConnections` are **Qlik Sense only**. Each of them says so and stops rather than doing
half a job, and the panel says so on the command before you run it.

## Extensions, custom properties, tags and reload tasks

The other objects a Qlik environment holds besides applications. Like the commands above they name
their own subject, and they are on the Operations panel under **All commands**, one group each.

| Command | What it does | Direction |
|---|---|---|
| [QOps-ShowExtensions](COMMAND-showextensions.md) | Lists the extensions the environment has | Qlik only |
| [QOps-AddExtensions](COMMAND-addextensions.md) | Records the extension filter in `.qopsconfig`; downloads nothing | configuration |
| [QOps-PrepareExtensions](COMMAND-prepareextensions.md) | Writes extensions into the repository | Qlik → disk |
| [QOps-BuildExtensions](COMMAND-buildextensions.md) | Uploads them as work in progress | disk → Qlik |
| [QOps-ReleaseExtensions](COMMAND-releaseextensions.md) | Publishes them under their real names | disk → Qlik |
| [QOps-SetLocalExtension](COMMAND-setlocalextension.md) | Gives an extension folder another name on this environment | repository |
| [QOps-PrepareCustomProperties](COMMAND-preparecustomproperties.md) | Writes custom property definitions into the repository | Qlik → disk |
| [QOps-BuildCustomProperties](COMMAND-buildcustomproperties.md) | Creates them in Qlik | disk → Qlik |
| [QOps-PrepareTags](COMMAND-preparetags.md) | Writes tags into the repository | Qlik → disk |
| [QOps-BuildTags](COMMAND-buildtags.md) | Creates them in Qlik | disk → Qlik |
| [QOps-PrepareTasks](COMMAND-preparetasks.md) | Writes reload tasks and their triggers into the repository | Qlik → disk |
| [QOps-BuildTasks](COMMAND-buildtasks.md) | Creates them in Qlik | disk → Qlik |

Each group has a page with the flows it takes part in: [Extensions](COMMAND-extensions.md),
[Custom properties](COMMAND-customproperties.md), [Tags](COMMAND-tags.md) and
[Reload tasks](COMMAND-reloadtasks.md).

`QOps-ShowExtensions` and `QOps-AddExtensions` work on Qlik Sense and Qlik Cloud. Everything else in
this table that talks to Qlik is **Qlik Sense only**. The panel disables those commands on a Qlik
Cloud or QlikView environment and says why on the Run button, instead of running them to a log line
that says they did nothing.

## Choosing what the panel shows

The Operations panel does not have room for every command, so it shows the ones **you** pin — up to
nine, in two rows of five — and keeps the rest one click away.

- **All commands** opens the full list, grouped by what the commands work on. Anything there can be
  run straight from the list, pinned or not. Nothing is hidden by not being pinned.
- **Pin** gives a command a button on the panel. **Unpin** takes it back off. This
  includes **Add App**, which is Prepare against one app Id you type rather than a command of its own.
  New installations start with Add App, Prepare, Build and Release pinned, which is one full row of the panel
  as it was.
- **Bookmarks** save a command together with a set of flags, under a name you choose — see
  [Saving a command with its flags](#saving-a-command-with-its-flags) below. A bookmark pins like
  anything else and counts against the same nine slots.
- The choice is **per account, not per repository**: your pinned commands follow you across every
  repository the Portal knows, and somebody else on the same machine has their own.
- It is kept in `%USERPROFILE%\qopsconfig\portal.settings.json`
  (`~/qopsconfig/portal.settings.json` on Linux and macOS) under `Portal:PinnedCommands`, so it
  survives a Portal restart **and** a `QOps-Update`. It is not in the Portal's own folder, which an
  update rebuilds. You can edit the file by hand; an entry it cannot read is skipped and the rest are
  kept.
- A pinned command that this Portal version does not have (for example one pinned in a newer version,
  before you went back to an older one) has no button. It is removed from your pinned list the next time
  you pin or unpin a command. A bookmark of such a command is kept as it is.

## Saving a command with its flags

The same command is often run two or three settled ways — a prepare with `-NoData`, a prepare with
everything. A **bookmark** is one of those ways, saved: a command, the flags you had set on it, and a
name. Pin the bookmark and the button runs that command with those flags.

**Making one.** Set the flags you want under **Flags / Options**, then open **Bookmarks** beside that
heading, type a name and save. The dialog lists everything you have saved, so it is also where you
**pin**, unpin and **delete** them.

**Running one.** A pinned bookmark is a button like any other. For one of the five application
operations it runs straight away, on the applications you have selected, and the flags it saved are
**applied to the panel first** — so the Flags / Options disclosure and the command preview show
exactly what is about to run rather than it happening invisibly. That does replace whatever flags you
had set on that operation at the time. For a command that asks for its own subject, the bookmark
fills the dialog in and you press Run, which is the same dialog that command always uses.

**What can be saved.** Any command on the panel except **Add App**: that one asks for an application
id every time it runs, so there is no flag set to keep.

**A flag the command does not take is refused when you save**, and the message names it. This is
deliberate. When a command runs, a flag the Portal does not recognise for it is dropped without
comment — which is right for a single run you are watching, and wrong for something saved, because a
saved entry is run later, repeatedly, and often by somebody who did not make it. Saving is the moment
the person who typed it is still there to be told.

Bookmarks live beside your pinned commands in
`%USERPROFILE%\qopsconfig\portal.settings.json` (`~/qopsconfig/portal.settings.json` on Linux and
macOS), so they survive a Portal restart **and** a `QOps-Update`. A profile holds up to 50 of them.
The [API reference](API-v2-reference.md#saved-commands-with-their-flags) has the file format.

## Setting a repository up

| Command | What it does |
|---|---|
| [QOps-SetConfig](COMMAND-setconfig.md) | Writes one setting into the configuration of the repository you are standing in |
| [Which apps a repository tracks](COMMAND-addapps.md) | The saved app filter, and how a repository's app list is changed |
| [QOps-SetLocalApp](COMMAND-setlocalapp.md) | Points a folder at the application it means on THIS environment, for this machine only |

## Keeping QOps up to date

| Command | What it does |
|---|---|
| [QOps-Update](COMMAND-update.md) | Installs the newest build in this computer's update channel; with `-CheckOnly`, only says whether there is one; with `-IgnoreInstalledFromOtherChannels`, installs the channel's latest build even when a newer one from another channel is installed |
| [QOps-Version -Installed](COMMAND-update.md#which-versions-are-installed) | Lists the QOps versions installed on this computer, which one runs, which one the shortcuts start, and where each came from |
| [QOps-SetUpdateChannel](COMMAND-update.md#changing-the-channel-for-good) | Sets the channel every later update reads; with `-PassThru`, also returns the change |

## When something goes wrong

| Command | What it does |
|---|---|
| [QOps-SendSupportCase](COMMAND-sendsupportcase.md) | Collects the logs and details support needs, masks every secret, and sends them to QOps support; with `-OutFile`, only writes the zip. Works without a licence |

## Data files in a space

Qlik Cloud only. These work on the files an application's script loads, not on applications.

| Command | What it does | Direction |
|---|---|---|
| [QOps-ImportFile](COMMAND-importfile.md) | Uploads a file from disk into a Qlik Cloud space's data files | disk → Qlik |
| [QOps-ExportFile](COMMAND-exportfile.md) | Brings a data file down from the space into a local folder | Qlik → disk |
| [QOps-RemoveFile](COMMAND-removefile.md) | Deletes a data file from the space | Qlik only |

## If you are looking for

Some of these are the questions people actually arrive with, and the answer is not the command whose
name matches the question.

| I want to | Where it is |
|---|---|
| get an existing Qlik app into the repository | [QOps-Prepare](COMMAND-prepare.md) |
| create a NEW app in Qlik from files | [Creating a new application](COMMAND-build.md#creating-a-new-application) — there is no create command |
| change which apps this repository works on | [Which apps a repository tracks](COMMAND-addapps.md) |
| set something in this repository's configuration | [QOps-SetConfig](COMMAND-setconfig.md) |
| work on a cloned repository whose apps already exist here under different ids | [QOps-SetLocalApp](COMMAND-setlocalapp.md) |
| know why a run found nothing | [Where an application has to live](COMMAND-build.md#where-an-application-has-to-live) |
| send an app to a stream or a space | [QOps-Publish](COMMAND-publish.md) |
| get a copy of a data file out of a Qlik Cloud space | [QOps-ExportFile](COMMAND-datafiles.md#which-of-the-three-you-want) — `QOps-RemoveFile` deletes it instead |
| put a CSV or a QVD into a Qlik Cloud space | [QOps-ImportFile](COMMAND-importfile.md) |
| version-control the `lib://` connections | [Data connections](COMMAND-dataconnections.md) |
| version-control visualisation extensions and mashups | [Extensions](COMMAND-extensions.md) |
| carry custom property definitions to another environment | [Custom properties](COMMAND-customproperties.md) |
| carry tags to another environment | [Tags](COMMAND-tags.md) |
| carry reload schedules to another environment | [Reload tasks](COMMAND-reloadtasks.md) |
| change which commands the Operations panel shows | [Choosing what the panel shows](#choosing-what-the-panel-shows) |
| know whether a newer QOps exists without installing it | [QOps-Update -CheckOnly](COMMAND-update.md#checkonly) |
| go back to the release build after trying a pre-release | [QOps-Update -IgnoreInstalledFromOtherChannels](COMMAND-update.md#ignoreinstalledfromotherchannels) |
| see which QOps versions are installed and where each came from | [QOps-Version -Installed](COMMAND-update.md#which-versions-are-installed) |
| send support the logs of a run that failed or hangs | [QOps-SendSupportCase](COMMAND-sendsupportcase.md) |

## How to read the flag sections

Each command page has a **Flags** section with one entry per switch, named exactly as it is typed. The
Operations panel offers a subset of them: the ones that are safe to set per run. Everything the panel
does not offer is either owned by the environment (which Qlik you are talking to, which profile) or
belongs in the repository's configuration, where it is set once — see
[Configuration](CONFIGURATION.md#the-repository-file).

Two switches are on every operation:

- `-VerboseLog` writes a fuller log for the run. Turn it on when you are going to send a log to
  somebody; leave it off otherwise.
- `-Force` means "go ahead without asking", and what it stops asking about depends on the command. On
  the operations above it skips the confirmation QOps asks for when a run would touch more than ten
  applications — in a script, or in the Portal, there is nobody to answer that question, so a large run
  needs it. On [`QOps-ExportFile`](COMMAND-exportfile.md#force) it is what allows the export to replace
  a file that is already on disk. Read it on the page for the command you are running.

## Local paths

Two commands on this page take a path to something on **your disk**: `QOps-ImportFile`
([`-Path`](COMMAND-importfile.md#path), [`-Root`](COMMAND-importfile.md#root)) and `QOps-ExportFile`
([`-Path`](COMMAND-exportfile.md#path)). Both read one the same way, and so does `QOps-ExportQVF`,
which the Portal does not run and so has no page here.

### An absolute path is used as written

    QOps-ImportFile -Space Sales -Path C:\data\Customers.csv
    QOps-ExportFile -Space Sales -File Customers.qvd -Path D:\out\extracts

On Linux and macOS that is a path from `/` — `-Path /home/you/data/Customers.csv`.

### A relative path is counted from the folder you are standing in

The folder `Get-Location` reports, in other words: the one you last `cd`-ed to. Standing in
`C:\repo\loaders`,

| You type | The file QOps reads or writes |
|---|---|
| `-Path .\data\Customers.csv` | `C:\repo\loaders\data\Customers.csv` |
| `-Path data\Customers.csv` | the same file — the `.\` is optional |
| `-Path Customers.csv` | `C:\repo\loaders\Customers.csv` |
| `-Path ..\shared\Customers.csv` | `C:\repo\shared\Customers.csv` |

**Being inside a repository does not change this.** QOps finds the repository by looking *upwards* from
where you are standing for the folder that holds `.qopsconfig`, and it reads the configuration from
there — but your path is still counted from where you are standing. So the same command in
`C:\repo\loaders` and in `C:\repo\extracts` names two different files, which is what makes a relative
path worth typing.

**In the Portal there is no folder you are standing in, so it is the repository's.** A command started
from a panel runs in the folder of the repository it belongs to, and the path you type is passed to it
untouched — so `-Path .\data\*.csv` on the panel means the `data` folder at the top of that repository,
whatever the file tree happens to be showing at the time.

**Leaving `-Path` out is not the same as writing `.`** The switch is optional on `QOps-ExportFile`, and
left out the files are written into the folder QOps takes as the repository's — the one holding
`.qopsconfig` — which is not necessarily the folder you are standing in. So the same command run from
the root of a repository and from a folder inside it writes to one place, while `-Path .` writes to two.
Write `-Path .` when you mean here.

### A wildcard matches names in one folder

`*` and `?` belong in the last part of the path, and one folder is read:

    QOps-ImportFile -Space Sales -Path .\data\*.csv      # the .csv files in data,
                                                         # NOT the ones in data\2026
    QOps-ImportFile -Space Sales -Path .\data\Q?.csv     # Q1.csv, Q2.csv, Q3.csv, Q4.csv

Matching nothing is not an error. The command says what it searched for and returns nothing, so
"wrong folder" and "no such file" do not read alike.

On `QOps-ExportFile` the pattern goes in [`-File`](COMMAND-exportfile.md#file), which matches names **in
the space**; its `-Path` is the local folder to write into and takes no wildcard.

**With [`QOps-ImportFile -Root`](COMMAND-importfile.md#root) a `*` crosses folders**, and that is what a
root is for. It turns `-Path` from a path into a pattern matched against each file's path *relative to
the root*, so `-Root .\data -Path *.csv` is every `.csv` in the tree under `data`, each keeping its own
folder on the way into the space. The root itself is a local path and follows the rules above.

### `-Path` on an application command is not a local path

On [`QOps-Prepare`](COMMAND-prepare.md#path) and [`QOps-Build`](COMMAND-build.md#path), `-Path` names
part of an application **inside the repository** — `Dimensions`, `Sheets/**/widget.json` — to scope the
run to. It has its own rules: it is always relative, it is refused if it is rooted, and `**` crosses
folders. Nothing in this section applies to it.

`-QlikPath`, on the data-file commands, is a folder inside the Qlik space rather than on your disk, so
a wildcard does not belong there either — that is what `-Path` and `-File` are for.

## See also

- [Panels](PANELS.md#operations) — the Operations panel itself: what it shows and how a run is started
- [User Guide](USER-GUIDE.md#4-how-operations-behave) — how a run behaves once it is going
- [Configuration](CONFIGURATION.md) — every setting a repository has, and the command that writes it
