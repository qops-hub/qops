# Create a new Qlik application from the repository

**Goal:** turn an application folder in the repository into a new application in Qlik, and have every
later build update that application instead of creating another one.

This page applies to Qlik Sense and Qlik Cloud.

## When you need this

- You are starting a new application in the repository, often from a copy of an existing one.
- The application does not exist in Qlik yet.

There is no separate create command. A build creates the application.

## Before you start

QOps is installed, licensed and connected to the environment where the application should appear. See
[Before you start](GETTING-STARTED.md#before-you-start).

## Steps

### 1. Prepare the folder

The folder must sit directly under the repository root, or directly under a folder listed in
[`AppSubfolders`](HOWTO-app-subfolders.md), and hold an `App.yaml` (or `App.json`). A build does not look deeper than that.

The quickest start is a copy of an existing application folder:

1. Copy the folder under a new name, for example `Sales Overview-prj`.
2. In the copy's `App.yaml`, set `Name` to the name the new application should have, and leave `Id`
   empty:

   ```yaml
   Id:
   Name: Sales Overview
   ```

   Edit the top-level `Name`, at the start of the line. The `name:` inside the owner block further down
   does nothing.
3. **Delete the copy's `App.local.yaml`** if it has one. While it exists, its `Id` decides where the
   build writes, and it still names the original application.

You can also give the folder an `Id` of your own instead of leaving it empty, for example
`Id: sales-overview`. Choose a readable name rather than something shaped like a Qlik id; the build
then creates the application and keeps your `Id` as it is.

### 2. Build it

```powershell
QOps-Build -Filter "Name=Sales Overview"
```

A folder with no `Id` is built into a new application with or without any switch. When several folders
have no `Id`, each one gets its own application.

To create every application that does not exist yet and leave all the others alone, use `-New`:

```powershell
QOps-Build -New
```

In the Portal: select the application in **Operations** and press **Build**. For the `-New` selection,
first open **Flags / Options**, set **Operation** to Build and switch on
**New (only apps not created yet)**. See
[Creating a new application](COMMAND-build.md#creating-a-new-application) and
[-New](COMMAND-build.md#new).

### 3. Commit the recorded Id

If the `Id` was empty, the build writes the **folder name** into it, for example
`Id: Sales Overview-prj`, and touches nothing else in the file. The Qlik id of the new application goes
into `App.local.yaml`, which is not committed. Commit the `App.yaml` change so every checkout addresses
the folder the same way.

An `Id` that was already there, including one you chose in step 1, is never rewritten.

### 4. Publish when it is ready

The new application is created unpublished in the personal area of the account QOps connects as: on
Qlik Sense in no stream, on Qlik Cloud in your personal space. Move it with
[QOps-Publish](COMMAND-publish.md), or build and publish in one run with
[QOps-Release](COMMAND-release.md).

In the Portal: **Operations → All commands → Publish**, or **Operations → Release**. Both ask for
confirmation and name the target first.

## How to check it worked

- The build log shows, in this order:

  ```text
  'Sales Overview' has no Id in its App.yaml, so it is built into a new app: the folder name is then written as its Id, and the Qlik id to App.local.yaml, so later builds update that app.
  Created new app: Sales Overview(<qlik id>)
  Written app info: Id Sales Overview-prj recorded in App.yaml
  ```
- `App.yaml` now says `Id: Sales Overview-prj`, and `App.local.yaml` holds the Qlik id.
- The next `QOps-Build` for the folder logs `Found existing app:` instead of `Created new app:`.
- `QOps-Build -Filter "Id=Sales Overview-prj"` finds the folder.

## If it did not work

These are the lines QOps prints when this task goes wrong, as they appear in the output.

**The build found no application folder at all.** The folder is not where a build looks:

```text
No app projects found. Scanned <n> location(s) starting at '<repository root>', one level deep: a folder holding App.json/App.yaml must be a DIRECT child of the repository root or of an AppSubfolders entry. Move it up, or add its parent to AppSubfolders (QOps-SetConfig -AppSubfolders).
```

Move the folder up to the repository root, or add the folder that contains it to `AppSubfolders`
(see [Keep applications in subfolders](HOWTO-app-subfolders.md)), and build again.

**The folder was skipped instead of created.** The build ran with `-UpdateOnly`, which never creates
an application:

```text
[Warning] '<name>' (folder '<folder>') was skipped: -UpdateOnly builds only apps that resolve on the server, and this folder has no Id in its App.yaml. If it belongs to an app that already exists, give the folder an Id first (set Id: <folder> in App.yaml), then map it: QOps-SetLocalApp -OriginAppId '<folder>' -TargetAppId <server app id>. Nothing was created. To build it into a new app instead, run the build without -UpdateOnly.
```

For a new application, ignore the `QOps-SetLocalApp` part: run the build again without `-UpdateOnly`.
In the Portal, switch off **Update only (skip apps not on the server)** under **Flags / Options**.

## Common mistakes

- **Keeping the copied `App.local.yaml` or the copied `Id`.** The build then writes into the
  application you copied from, because that is the application the folder names. Clear the `Id` and
  delete `App.local.yaml` before the first build.
- **Using `-Path` for the first build.** A build limited with `-Path` only acts on an application that
  already exists, so it skips a folder with no `Id` and creates nothing. Run a full build first.
- **Using `-UpdateOnly`.** It never creates an application, so a folder with no `Id` is skipped.
- **Putting the folder too deep.** A folder two levels below the root is not found, and the run reports
  `No app projects found` (see [If it did not work](#if-it-did-not-work)). See
  [Where an application has to live](COMMAND-build.md#where-an-application-has-to-live).
- **Not committing the recorded `Id`.** Another checkout then still sees an empty `Id`, and its first
  build creates one more application.
- **Choosing an `Id` that is a Qlik id on this server.** The build then writes into that application
  instead of creating one. A readable name cannot collide with a Qlik id.
- **Expecting `QOps-AddApps` to create an application.** It changes which applications the repository's
  saved filter selects. See [Which apps a repository tracks](COMMAND-addapps.md).

**Next:** to bring the new application to another environment, such as a test server or another
Qlik Cloud tenant, see
[Set up a repository's applications on another Qlik environment](HOWTO-set-up-another-environment.md).

## See also

- [How does QOps know which Qlik application a repository folder belongs to?](HOWTO-app-identity.md)
- [QOps-Build: Creating a new application](COMMAND-build.md#creating-a-new-application)
- [How-to guides](HOWTO.md)
