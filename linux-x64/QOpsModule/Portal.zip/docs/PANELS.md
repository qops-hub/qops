# Panels — what each one is for

> The map of the Portal. Each panel below answers the same three questions: **what it lets you do**,
> **what it needs first**, and **how to get into it**. For the step-by-step first run see
> [Getting Started](GETTING-STARTED.md); for the reference material — architecture, security, what is
> stored where, troubleshooting — see the [User Guide](USER-GUIDE.md).

Most panels act on **one selected repository**. That is not a limitation to work around: it is what
makes a panel's content unambiguous, and it is why the repository list in the left sidebar is the
first thing to use. Panels that need a repository say so.

Eight panels are in the left navigation. Three more — **Search**, **Settings** and the single-file
**Editor** — have no navigation entry because they only make sense once you have chosen what they
should act on; each says below how it is reached.

On a machine with **no active licence** the Portal still opens, and **Dashboard**, **Settings** and
**Help** work normally. Every other panel shows a licence screen instead of its contents, with the
reason and a button that opens the licence settings; its navigation entry carries a padlock and still
takes you there. Once the machine is licensed they all open, and the panels below then need only what
each one lists.

---

## Dashboard

**What it gives you.** The entry point, and the only panel that works with nothing selected. It lists
every registered repository with its branch, recent activity and app count, lets you register a new
folder, and — via right-click — takes you into any repository-scoped panel with that repository
already chosen.

**Needs.** Nothing.

**Getting there.** First entry in the navigation; also where you land on startup.

Removing a repository here detaches it from the Portal only. The folder and its Git history stay on
disk untouched, which is why the confirmation says so explicitly.

---

## Studio

**What it gives you.** The panel you work in. Edit the app's source files, read the generated
documentation beside them, search both, and watch the operation log — in one window, without losing
your place.

- **A multi-tab editor.** Files opened from the left tree, from a Lineage node, or from a search result
  all land in the same tab strip, so you never end up with two views of one file. Arriving from a
  search result reveals the exact line. Unsaved tabs are marked, and `Ctrl+S` saves.
- **Generated documentation** for the selected app — sheets, widgets, master measures and dimensions,
  variables, master objects — built by scanning the decomposed source files on disk, not by querying
  the live Qlik app. It is therefore as current as your working tree, and it needs no Qlik connection.
  Regenerate it after an edit, and export the result to Markdown, CSV or JSON.
- **Search over that documentation**, which is not the same as searching files: it runs over the
  documentation model, across every object type or one you pick, with scopes that restrict a query to
  names, descriptions, expressions or ids, plus whole-word and regular-expression matching and
  *unused only* / *duplicates only* audits.
- **Where-used**, from any master item, lists what consumes it: the widgets that reference it
  structurally, and — the case a text search misses — the ones that only mention it inside an
  expression typed directly into a chart. Note that such inline expression text is reachable *through
  where-used*; a plain documentation query does not match it.
- **File search and replace** — the project-wide Search described below, docked beside the editor
  rather than replacing it.
- **The operation log, docked**: the run in progress streamed live (with a Stop button), any saved log
  from a past run, and a search across the content of every saved log in the repository. Search and
  Logs share the bottom row — side by side when it is wide enough, tabs when it is not.

In Studio the left sidebar also gains a file tree for the repository, with create, rename and delete.

Right-clicking in that tree also **aims a QOps operation at what you clicked**. On an application's
folder (one level under the repository folder, or under a folder listed in `AppSubfolders`) the menu offers Prepare, Build and Set local App for that application. On anything inside
it — a folder such as `Sheets`, or a single object file — it offers **Prepare on path** and **Build on
path**, which run scoped to exactly that folder or file.

You stay in Studio. The confirmation opens over the document you are reading, names the application and
echoes the full command, and the run starts from there; the output streams into the log panel below, and
while that panel is collapsed its strip shows a yellow **running** marker. Set local App is the
exception — it opens the Operations panel, because mapping this folder onto a *different* application
needs a second application that one tree row cannot name.

The `-Path` box on the Operations panel stays where it is: the tree is a faster way to hit one object,
not a replacement for typing a pattern such as `Variables/Sales*`.

### Diff editing

Edit a changed file **beside the version git has**, instead of guessing what you changed from memory.
The file opens as two panes: the base pane on the left, read-only, and your working file on the
right, where you type. 
By default it opens as Unstaged (worktree vs index), so base pane is the index (staged version).
Both panes scroll together and unchanged code stays opposite itself, so the
lines you changed are the only ones that move. Save with `Ctrl+S` as usual.

**Opening it.** Either the **Edit** button on a file in the Diff panel, or the status letter beside a changed file in the Studio file tree. The **Editor / Diff editing** toggle above the editor switches the open tab between the two views; your unsaved edits carry across the switch.

**A file with merge conflicts** opens in the [merge editor](#resolving-merge-conflicts) instead, from the same **Edit** button or from its red **!** letter in the Studio file tree. Once you save the Result with no conflict left, the file is marked resolved and staged, and the same tab switches to the usual Diff editing view. Inside the tab the merge editor has no title bar of its own, because the tab already shows the file: the tab's **Save** saves the Result, exactly as the merge editor's own Save does, and **Revert** puts the Result back to the file as it is on disk. A slim bar above the panes shows how many conflicts are left and **Conflict N of M** while any are. To leave the merge editor, switch the tab to **Editor**.

**Beside each changed block** sit two buttons, in the gap between the panes:

- **Revert block** puts that block back to the version on the left. It changes the buffer only —
  nothing on disk and nothing in git moves, and `Ctrl+Z` undoes it like any other edit.
- **Save and Stage block** writes *that block* to the file and stages it, in one action. Other unsaved
  edits in the same file stay in the buffer and the tab stays marked unsaved, so staging one block
  never quietly commits you to the rest.

**Compare** chooses which two things you are looking at, and only one of them can be edited:

| Compare | Shows | Editable |
|---|---|---|
| **Unstaged (worktree vs index)** | your file against what is staged | **yes** — the default |
| Staged (index vs HEAD) | what is staged against the last commit | no |
| Working tree (all uncommitted) | your file against the last commit | no |

Unstaged is the editable one because it is exactly the set of changes you have not staged yet. Stage a
block and it leaves the comparison, which is how you can see what is left to do. The other two are for
reading. Staged has your working file on neither side, so there is nothing there to type into; and in
the all-uncommitted view a block may be partly staged already, which makes *stage this block* mean two
different things. Switching Compare never touches your unsaved edits.

Diff editing needs the file to exist in git. A brand-new file that has never been committed has
nothing to compare against, so it opens in the normal editor.


**Needs.** An active licence, and a selected repository containing at least one decomposed app.

**Getting there.** Second entry in the navigation.

---

## Operations

**What it gives you.** Runs the QOps cmdlets against the selected repository and shows progress as it
happens. These are the same operations you would run from PowerShell, so the results match; the panel
exists so you can drive and watch them without leaving the browser.

| Operation | What it does |
|---|---|
| **Add App** | Pulls a Qlik app into the repository by its app id — the way a *new* app joins a repo. |
| **Prepare** | Decomposes a Qlik app into source files under `<app>-prj/`. |
| **Build** | Recomposes the app in Qlik from those source files. |
| **Reload** | Reloads the app's data in Qlik, without rebuilding it. |
| **Publish** | Builds and publishes to the target space or stream. |
| **Release** | Builds, publishes, and records a versioned snapshot. |

A new installation pins Add App, Prepare, Build and Release, which fills one row alongside **All
commands**; Reload and Publish are in the list. There are more, and which ones
get a button is your choice — see *The buttons are yours* below.

Things worth knowing before you rely on it:

- **Choose the target apps.** Run against one app, a subset you tick, or every app in the repository.
  The panel says which, so an all-apps Build is never a surprise.
- **You can aim a run from the Studio file tree** instead of choosing the app and typing a path —
  right-click an application folder or any object inside it. A run started that way always shows the
  confirmation with its full command first, including runs that go straight through when you press the
  button here, and it runs without leaving Studio.
- **Dry Run** shows the exact command that *would* run, including flags, and calls nothing. Use it
  when you want to check a filter or a flag rather than to make something happen.
- **Publish and Release ask for confirmation**, and the dialog names the target set in words.
- **Choosing which app Id a Publish or Reload addresses.** When an application folder holds two
  different app Ids, one in `App.local` (the app your last build on this machine wrote to) and another
  in `App` (the Id committed to the repository), the Publish and Reload confirmation shows an **App Id**
  choice: **Local Id (App.local)** or **Id (App)**. The command preview in the same dialog follows your
  choice, and the run uses exactly the Id the preview shows. The choice is offered only when both are
  real Qlik app Ids and they differ; otherwise there is nothing to choose and the dialog does not show
  it. Publish starts on Local Id, Reload starts on Id (App). With several applications selected, the
  choice applies to the ones that hold two Ids and the rest keep the default.
- **Flags are remembered per repository and per operation**, so switching repositories and coming back
  restores what you had set.
- **A running operation can be stopped** — see *Long operations* in the [User Guide](USER-GUIDE.md).
- **Operation history is kept on disk**, not just for the session: filter by operation or by outcome,
  and click any entry to read that run's saved log.
- **What each operation and each flag actually does** is written up one command at a time in
  [Commands](COMMANDS.md) — what the command is for, how it differs from the one next to it, and a
  section per switch. The ⓘ beside **Flags / Options** opens the page for the operation you are
  configuring, at its flags.

### The buttons are yours

**All commands** opens the full list of everything the panel can run, grouped by what the commands
work on: the five application operations, the Qlik Cloud data-file commands, and the data-connection
commands. Anything in that list runs from the list. Pinning only decides what gets a button.

- Up to **nine** commands are pinned at a time, in two rows of five. **Pin** adds one; **Unpin**
  takes it back off. The tenth place in that block is **All commands** itself, which is why it is
  still there to click when the panel is full.
- The choice is kept **per account**, not per repository, and it survives a Portal restart and a
  `QOps-Update`. It lives in `%USERPROFILE%\qopsconfig\portal.settings.json`, which an update does
  not touch.
- Unpinning does not remove anything. A command with no button is still one click away in the list,
  and the keyboard shortcuts above keep working either way.

The commands that do not work on applications — importing, exporting and removing data files in a
Qlik Cloud space, and the data-connection commands — ask for what they need in a small dialog and
show you the exact command before running it. Two of them carry a warning worth reading before you
press Run: **Remove file** deletes in Qlik immediately and puts nothing on your disk, and
**Add connections** is two commands in one run. Both are explained in
[Commands](COMMANDS.md#working-on-data-files-and-data-connections).

**Needs.** An active licence, a selected repository, and a configured environment profile for anything
that talks to Qlik. The data-file and data-connection commands need a repository but not a selected
application, so they stay available while you are still setting one up.

**Getting there.** Navigation, or right-click a repository on the Dashboard.

---

## Git

**What it gives you.** The working state of the repository: what changed, what is staged, and the
history behind it. Stage and unstage files, commit, push, pull, create and switch branches, stash and
stash-pop. Clicking a changed file opens its diff.

- **Commit templates** (Prepare / Build / Feature / Fix / Refactor) keep a readable history without
  typing the same prefix every time.
- The branch indicator shows **ahead/behind** counts, so you know whether you are about to push or
  need to pull first.
- **Fetch** (next to Pull and Push) runs `git fetch --all --prune`: it updates what the Portal knows
  about every remote without changing any local branch or file. Next to it the card shows when the last
  fetch ran (`Fetched 3 h ago`, or `Never fetched`). Remote branches and behind counts are exactly as
  fresh as that.
- **Remote branches.** Under the local branches, a **Remote** group lists the branches of every remote
  as `<remote>/<name>`. A remote branch with a local branch of the same name is not listed again; the
  local branch shows `N behind <upstream>` instead when its remote has commits it does not.
  - **Click** a remote branch to create a local branch of the same name that tracks it and switch to it
    (`git checkout --track <remote>/<name>`).
  - **Merge** (the hover button) merges it into the current branch **without switching to it**. The
    Portal first runs `git fetch <remote> <name>`; if that fails, the merge is not run and the message
    says why, so an old copy is never merged by accident. Conflicts are resolved in the Diff panel and a
    merge can be aborted, the same as for a local branch.
  - A branch that exists on the remote but has never been fetched is not listed. Press **Fetch** first.
  - **More than eight remote branches** are not shown as chips. The group shows one button with the
    count instead; it opens a list whose first row is a filter (any part of `<remote>/<name>`, case does
    not matter). Each row has the same **Check out** and **Merge** as a chip, with the same
    confirmation for Merge. Keyboard: the filter has focus when the list opens, **Up**/**Down** move the
    highlight, **Enter** checks out the highlighted branch (it never merges), **Tab** reaches that
    row's Check out and Merge buttons, and **Esc** closes the list. The card's own filter box narrows
    the list too; the button then says how many of the branches match.
- A folder that is not yet a repository gets a **git init** button here, which runs `git init` in place.

**Needs.** An active licence, and a selected repository that is a Git work tree.

**Getting there.** Navigation, or right-click a repository on the Dashboard.

---

## Diff

**What it gives you.** A full-window reading view for changes — unified or side-by-side, grouped by
app, with keyboard navigation between files and hunks. Use Git for *deciding* what to commit and Diff
for *reading* what changed; they show the same data with different priorities.

To change what you are reading, the **Edit** button on a file opens it in Studio's
[Diff editing](#diff-editing) view, which keeps the two panes and makes the right one editable.

### Resolving merge conflicts

When a merge stops with conflicts, each conflicted file is listed in the Diff panel. In unified view every conflict in the file has its own bar with **Keep current**, **Keep incoming** and **Keep both**, which rewrite that one conflict in the file straight away.

For a closer look, the **Merge editor** button on a conflicted file opens it in three panes. The same editor opens in Studio when you open a conflicted file in [Diff editing](#diff-editing). **Current** (your branch) and **Incoming** (the branch being merged in) sit side by side at the top and are read-only. **Result** below them is the file that will be written, and you can type in it.

Each open conflict has its own row inside the Result, directly above the conflict, with **Accept Current**, **Accept Incoming** and **Accept Both**. The row moves with its conflict as you edit, and disappears once that conflict is resolved (an undo brings it back). Accept Both keeps the current version followed by the incoming one. A choice changes the Result only: nothing is written until you save, and `Ctrl+Z` in the Result undoes it.

The bar at the top shows how many conflicts are left and **Conflict N of M** with previous and next arrows, which step through the conflicts that are still unresolved and bring each one into view in all three panes, so a file with many conflicts is as easy to work through as one with two. Once every conflict is resolved, the counter and the arrows are hidden. The merge editor opens with the first unresolved conflict already in view, and clicking **Conflict N of M** in the bar brings the current conflict back into view, which is the way back to it after scrolling away when a file has only one conflict and both arrows are disabled. Clicking the **Conflict N of M** label on a row does the same for that conflict. **Reset result** puts the Result back to the file as it is on disk.

**Save** (or `Ctrl+S` in the Result) writes the Result to the file:

- When no conflict is left, the file is also marked resolved, which stages it. The button then reads **Save and mark resolved**.
- When some conflicts are left, the file is written and stays conflicted, so you can come back to it later.
- A conflict marker line left over from editing by hand, one that is not part of a complete conflict, is removed before the file is written. A complete conflict you have not decided yet is never changed.
- If the file changed on disk after the merge editor opened it, nothing is written. Close and reopen the merge editor to start from the current file (in a Studio tab, switch to **Editor** and back to **Diff editing**).

A conflicted file is staged as a whole, once all of its conflicts are resolved. Staging single blocks is for files without conflicts, in [Diff editing](#diff-editing). When every file is resolved, commit the merge from the Git panel.

**Needs.** An active licence, and a selected repository with changes to show.

**Getting there.** Navigation, or click a file in the Git panel.

---

## Lineage

**What it gives you.** The structure of a decomposed app drawn as a graph: the app, its sheets, the
visualization objects on each sheet — including objects nested inside a container — and, attached to
the app itself, its master measures, master dimensions, master objects, and the data connections named
in the load script.

Be exact about what that answers. The nesting it draws is real containment, so *what is on this sheet*
and *what is inside this container* are questions it answers well. Master items sit under the app, and a
faint dashed line joins each object to the master measures, master dimensions and master objects it
references, and each master object to the master items it references, including through the objects
inside it. Hovering a master item shows what uses it directly; double-clicking it follows the whole chain,
through a master object to the charts that reuse it. The panel has no field level. The
field a master dimension is built on appears in the inspector as a property of that one item, not as
something the graph is arranged by. To ask what uses a field, in a repository or on a live app, use `get_lineage` from an AI assistant
([MCP.md](MCP.md)).

- **Click a node** for an inspector with the detail behind it — a measure's expression, a dimension's
  field and grouping, a sheet's object count, a widget's visualization type.
- **Double-click** to isolate one node's chain and dim the rest.
- **Lint** marks structural problems: a sheet with no objects, a data connection attached to nothing, a
  duplicate name within one app, a node whose parent is missing.
- **Merge shared data connections**, in the repository-wide view, collapses one connection used by
  several apps into a single node linked to each of them.
- **Right-click → Open in Editor / Open in Studio** opens the source file behind a node. A node with no
  single file of its own says so rather than doing nothing.

For *what uses this*, use Studio's where-used and its documentation search, described above. The graph
does not carry that relationship.

**Needs.** An active licence, and a selected repository with a decomposed app.

**Getting there.** Navigation, or right-click a repository on the Dashboard.

---

## Logs

**What it gives you.** The output of operations: the one currently running, streamed live, and every
saved log from past runs.

Search inside the displayed log, or tick **all logs** to search the *content* of every saved log in
the repository at once — that is how you find "the run where that error appeared" without remembering
which run it was.

**Needs.** An active licence, and a selected repository.

**Getting there.** Navigation, or right-click a repository on the Dashboard.

---

## Help

**What it gives you.** The Portal's own manuals — this page, Getting Started, the User Guide and the
API reference — rendered in-app, with a table of contents, copyable code blocks, and print/export.
Cross-references between these pages are clickable and take you to the page named.

**Needs.** Nothing.

**Getting there.** Navigation.

Help and Studio sound similar and are not: **Help** is the Portal's manuals (this text), **Studio** is
where you work on *your* app — its source files, and the documentation generated from them.

---

## Search

**What it gives you.** Project-wide find and replace across the repository's files.

- **Include and exclude globs** — for example include `*-prj/Measures/**`, exclude `**/Sheets/**`.
- **Case-sensitive** and **whole-word** matching, and **regular expressions** when you need them.
- **Replace all**, applied directly to the working tree — which is exactly why the Git and Diff panels
  are the next stop: review a mass replacement before committing it.

**Needs.** An active licence, and a selected repository.

**Getting there.** `Ctrl+Shift+F` to search, `Ctrl+Shift+H` to open with the replace row revealed, the
clickable hint in the header, or right-click a repository on the Dashboard. Inside Studio it opens as a
dock beside the editor — on the right, or along the bottom next to the log — instead of replacing the
view. It stays open while you click through matches, and each side remembers its own size.

---

## Settings

**What it gives you.** Repository-scoped configuration:

- **Placeholders** — values substituted during Build, so one set of source files can target different
  environments without editing the sources.
- **Hook scripts** — scripts that run around operations, for the steps that are specific to your
  project rather than to QOps.

**Needs.** A selected repository.

**Getting there.** The repository tree in the left panel, or right-click a repository on the Dashboard.

---

## Editor

**What it gives you.** A Monaco editor for a single source file, with syntax highlighting, save, and
awareness of the file's Git state. Studio's tabbed editor is the usual way to edit; this panel is the
one-file view you get when you arrive from somewhere that had exactly one file in mind.

**Needs.** An active licence, and a specific file — which is why it is *not* in the navigation. Opening it with nothing
chosen would land you on an empty panel.

**Getting there.** Contextually: a node in Lineage, an Edit action in Studio, a search result, or a
file in the left tree.

---

## Keyboard shortcuts

The complete set. Anything not listed here is not bound.

### Anywhere

| Shortcut | Does |
|---|---|
| `Ctrl+Shift+P` | Command palette — operations and navigation by name |
| `Ctrl+Shift+F` | Project-wide search |
| `Ctrl+Shift+H` | Project-wide search with the replace row revealed |
| `Ctrl+B` | Collapse / expand the left panel |

### Operations panel

| Shortcut | Does |
|---|---|
| `Ctrl+P` | Prepare |
| `Ctrl+Shift+B` | Build |
| `Ctrl+Shift+L` | Reload |
| `Ctrl+Shift+U` | Publish |
| `Ctrl+Shift+R` | Release |

### While editing and committing

| Shortcut | Does |
|---|---|
| `Ctrl+S` | Save the file in the editor |
| `Ctrl+Enter` | Commit, from the commit message box |

### Left file tree

`Ctrl+C` / `Ctrl+X` copy or cut a file, `Ctrl+V` pastes into the focused folder, `F2` renames, `Del`
deletes. Each acts on the row that has focus, and only where the matching context-menu item would be
offered — so a key never does something the menu would not let you do.
