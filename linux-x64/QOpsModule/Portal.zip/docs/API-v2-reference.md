﻿# QOps Portal — API v2 Reference (calling guide)

The Portal backend is an ASP.NET Core minimal API + SignalR. **The authoritative endpoint list is
Swagger UI:** `http://localhost:<port>/swagger` (OpenAPI: `/swagger/v2/swagger.json`), live and
generated from the running Portal.

This document is the **calling guide**: the things the route table doesn't spell out — base URL,
conventions, the error model, pagination, realtime usage, and worked request/response examples.

## Base URL & versioning

| Context | Base URL |
|---------|----------|
| Launched via `QOps-StartPortal` | `http://localhost:5555`, or the port you [persisted](#changing-the-port-for-good), or your `-Port` |

All endpoints are under **`/api/v2`** except the SignalR hub `/hubs/logs` and the SSE stream.
`/api/v1` is no longer available. The unversioned `GET /health` and `GET /api/v2/health/detailed`
were removed on 2026-09-17 — see [Health](#health).

## Authentication

**None.** The Portal runs locally as you and shells out as that user; there is no token, cookie, or
header to send. Do not expose the port to a network — anyone who can reach it can run operations as you.
Secrets read from QOps config are masked (`***encrypted***`) before they ever leave the API.

### Changing the port for good

`QOps-StartPortal -Port 8080` changes the port for **that one start**. To make a port stick, put it in
`%USERPROFILE%\qopsconfig\portal.settings.json` (`~/qopsconfig/portal.settings.json` on Linux/macOS):

```json
{
  "Portal": {
    "Port": 8080
  }
}
```

`QOps-StartPortal` with no `-Port` now starts on 8080, prints `http://localhost:8080`, and opens that.
So do the Start menu and Desktop shortcuts, which pass no port at all.

Precedence, highest first:

| | Where | Scope |
|---|-------|-------|
| 1 | `QOps-StartPortal -Port 9000` | this start only — **always wins**, including `-Port 5555` |
| 2 | `Portal:Port` in `portal.settings.json` | every start on this account |
| 3 | built-in default `5555` | when neither is set |

`-Port` wins even when the number you type is 5555: what counts is that you typed it, not what it says.

If the file has a port that cannot be used — not a number, or outside 1–65535 — `QOps-StartPortal`
says so and starts on 5555. It does not fail silently.

> The Portal's own `appsettings.json` has **no port setting**, and its `Urls` key was removed in
> v3.0.12 (QOPS-437). It never worked: `QOps-StartPortal` launches the Portal with
> `--urls http://localhost:<port>`, and a command line outranks every configuration file. Setting a
> port there changed nothing, and the Portal directory is rebuilt by `QOps-Update` anyway. Use
> `portal.settings.json`.

### The commands pinned to the Operations panel

The same file carries which commands the Operations panel shows, under `Portal:PinnedCommands`. It is
written by the panel — **Pin** and **Unpin** in *All commands* — so there is nothing to edit by hand
unless you want to.

```json
{
  "Portal": {
    "PinnedCommands": [
      { "kind": "command", "id": "prepare" },
      { "kind": "command", "id": "build" },
      { "kind": "command", "id": "import-file" }
    ]
  }
}
```

Precedence, highest first:

| | Where | Scope |
|---|-------|-------|
| 1 | `Portal:PinnedCommands` in `portal.settings.json` | this account, every repository |
| 2 | Add App, Prepare, Build, Release | when the key is absent |

An entry is a **reference**, not a bare name: `kind` says what is being pointed at, and `id` says
which one. `command` points at a command in the catalogue; `bookmark` points at a saved
command-plus-flags entry in [the section below](#saved-commands-with-their-flags).

Three things are worth knowing if you edit the file yourself:

- An **empty list is a choice**, not an absence. `"PinnedCommands": []` means "no buttons", and the
  panel shows only *All commands*. Remove the key to go back to the four defaults.
- At most **nine** entries are kept; a longer list is read down to the first nine.
- An entry that cannot be read — an unknown `kind`, a missing `id` — is **skipped, and the rest are
  kept**. A bare string is accepted as a command id, so `["build", "reload"]` works.

If the whole file is not valid JSON, the panel falls back to the four defaults and says nothing more
about it, but **a pin change is then refused** rather than written: the file also holds the webhook
secret's salted hash and the allowed origins, and a document that cannot be read is a document that
must not be overwritten.

### Saved commands with their flags

The same file carries **bookmarks** under `Portal:CommandBookmarks`: a command, a set of flag values,
and a name you chose. A bookmark is a saved way of running a command that already exists, not a new
command, and it is pinned like any other entry — with `kind: "bookmark"` and the bookmark's `id`.

```json
{
  "Portal": {
    "CommandBookmarks": [
      {
        "id": "b7f3c1",
        "name": "Nightly prepare",
        "commandId": "prepare",
        "flags": { "NoData": true, "Path": "Sheets/*" }
      }
    ],
    "PinnedCommands": [ { "kind": "bookmark", "id": "b7f3c1" } ]
  }
}
```

- `id` is what a pin points at, and it never changes when you rename the bookmark — a rename would
  otherwise leave the pin pointing at nothing.
- `commandId` is a command from the catalogue. `add-app` cannot be bookmarked: it asks for the
  application id every time it runs, so it has no flag set to save.
- `flags` are named exactly as the cmdlet's own parameters, without the leading dash.

**A flag the command does not take is refused when the bookmark is saved**, and the refusal names it.
That is deliberate and it is the one place the check can do any good: when a command runs, a flag the
server does not recognise is dropped without a word, which for a saved entry would mean a button
whose name promises one command and whose run is another — every time, for anyone who uses it.

An entry that cannot be read — no `id`, no `name`, no `commandId` — is skipped and the rest are kept,
as with the pins. At most **50** bookmarks are kept, and a name is at most **60** characters.

### Opening the Portal at an address other than localhost

Used the normal way — `QOps-StartPortal` on your own machine, opened at `http://localhost:5555` — there
is nothing to configure here.

If you have decided to run the Portal at a different address inside a protected network, **add that
address to the settings below or it will be refused.**

1. Create or edit this file:

   ```
   %USERPROFILE%\qopsconfig\portal.settings.json
   ```

   It is not created for you, and it is read only if the account running the Portal is the one whose
   profile it sits under.

2. Add the host name people type in the address bar to `AllowedHosts` — semicolon-separated,
   **no scheme and no port**:

   ```json
   {
     "AllowedHosts": "localhost;127.0.0.1;[::1];qops.example.com"
   }
   ```

   An address that is not on this list is answered `400 Bad Request`. This one applies to every
   caller, `curl` and CI jobs included.

   > ⚠️ **`localhost` and `127.0.0.1` are separate entries — listing one does not cover the other.**
   > `"AllowedHosts": "localhost"` answers `400` to `http://127.0.0.1:5555`, which looks exactly like
   > the Portal being down. **What you write here REPLACES the shipped list**, so keep the loopback
   > names: copy the line above and append your own address to it. The machine's own name is always
   > accepted and never needs listing.

3. Only if a browser loads the Portal **page** from a different address than the one it calls — a
   separate web server, or the dev vite server — also add that origin, this time **with scheme and
   port**:

   ```json
   {
     "AllowedHosts": "localhost;127.0.0.1;[::1];qops.example.com",
     "Cors": {
       "AllowedOrigins": [ "https://qops.example.com" ]
     }
   }
   ```

   List every origin people will use. `*` is not accepted and the Portal will not start with it.
   Scripted callers (`curl`, a CI job, `Invoke-RestMethod`) never need an entry here.

4. Restart the Portal.

This is the same file as **Changing the port for good** above — one file, several sections:

```json
{
  "Portal":       { "Port": 8080 },
  "AllowedHosts": "localhost;127.0.0.1;[::1];qops.example.com",
  "Cors":         { "AllowedOrigins": [ "https://qops.example.com" ] }
}
```

This file survives `QOps-Update`. The Portal's own `appsettings.json` does not: the Portal directory is
re-created from scratch on every update, so anything edited there is back to default afterwards - and
the symptom is a refused browser, or a port that reverts, with no other sign that a setting was lost.
That is why the port, the allowed hosts and the allowed origins all live here and not there. Settings
placed here override `appsettings.json`. An environment variable of the same name (`AllowedHosts`,
`Cors__AllowedOrigins__0`) beats this file, and anything passed on the command line, such as
`QOps-StartPortal -Port`, wins over all three.

### Who may switch versions, update, restart or stop the Portal

Five actions change which QOps runs, or whether the Portal runs at all: switching the version
(`POST /api/v2/portal/versions/switch`), changing the update channel (`POST /api/v2/portal/channel`),
updating (`POST /api/v2/portal/update`), restarting (`POST /api/v2/portal/restart`) and shutting down
(`POST /api/v2/portal/shutdown`). The Portal has no login, so it decides by the address the request
comes from:

- **This computer is always allowed** - `127.0.0.1` (anything in `127.0.0.0/8`), `::1`, and the same
  addresses as a dual-stack connection reports them (`::ffff:127.0.0.1`). Used the normal way, at
  `http://localhost:5555`, there is nothing to configure.
- **Other computers are allowed only when listed in `Portal:AdminAllowedAddresses`**, in the same
  `portal.settings.json`. Each entry is one IPv4 or IPv6 address, or a CIDR range written by its first
  address:

  ```json
  {
    "Portal": {
      "AdminAllowedAddresses": [ "10.20.0.15", "10.20.30.0/24", "fd00:20::/64" ]
    }
  }
  ```

  Empty or missing means this computer only. An IPv4 address is matched whether the connection reports
  it as IPv4 or as IPv4-mapped IPv6 (`::ffff:10.20.0.15`), so write it as plain IPv4.
- **Everyone else gets `403`**, and the body names the setting and the address the Portal saw, so you
  know what to add:

  ```json
  HTTP/1.1 403 Forbidden
  { "title":   "Not allowed from this address",
    "detail":  "Not allowed from 10.20.31.7: only this computer and the addresses listed in Portal:AdminAllowedAddresses in portal.settings.json may switch the QOps version, change the update channel, update, restart or shut down the Portal.",
    "setting": "Portal:AdminAllowedAddresses",
    "remoteAddress": "10.20.31.7" }
  ```

- **Everything else is open as before.** Reading the update status and the installed versions
  (`GET /api/v2/portal/update`, `GET /api/v2/portal/versions`), the update check
  (`POST /api/v2/portal/check`, which installs nothing), and the rest of the API are not under this rule.

An entry that is not an address or a CIDR range - a host name, `10.1`, `*`, or a range with host bits
set such as `10.20.30.5/24` - **grants nothing**: it is ignored, and the `403` lists it under
`ignoredEntries` (and in `detail`) so a typo does not pass for a setting in force. The Portal still
starts, so a mistake here never locks out this computer. A change to the list applies to the next
request; no restart is needed. As an environment variable it is
`Portal__AdminAllowedAddresses=10.20.0.15;10.20.30.0/24`.

> ⚠️ **A reverse proxy on the same computer makes every caller look like this computer.** The
> Portal reads the address of the connection, never `X-Forwarded-For` or any other header: a header is
> written by the caller, so trusting it would let anyone claim an allowed address, and the Portal has no
> trusted-proxy setting. When IIS, nginx or another proxy on the Portal's own machine forwards requests
> to it, the Portal sees `127.0.0.1` for all of them and allows the five actions to everyone the proxy
> serves. **Enforce the rule at the proxy:** allow `POST` to `/api/v2/portal/versions/switch`,
> `/api/v2/portal/channel`, `/api/v2/portal/update`, `/api/v2/portal/restart` and
> `/api/v2/portal/shutdown` only from the addresses you want (or block them at the proxy altogether and
> use them at the Portal's own computer). A proxy on another computer is seen by its own address: leave
> it out of `Portal:AdminAllowedAddresses`, or every caller through it is allowed.

## Conventions

- **Content type:** `application/json` for requests and responses, except file-content and
  docs-as-markdown endpoints which return `text/*`.
- **IDs:** `{repo}`/`{id}`/`{repoId}` is a repository id from `GET /api/v2/repositories`; `{appId}` is a
  Qlik app id (matched against `App.json` in a `*-prj` directory).
- **Long-running operations** return immediately with an `OperationResult`; the work continues and its
  log lines stream over SignalR (see [Realtime](#realtime)). The `success` flag reflects the cmdlet's
  final exit, the `operationId` is the SignalR group to subscribe to.
- **Registering a repository does not clone or modify it** — it records an existing on-disk path.

## Error model (RFC 7807)

Errors come back as `application/problem+json` (via `ErrorHandlingMiddleware`):

```json
{
  "type": "https://httpstatuses.io/409",
  "title": "Operation already running",
  "status": 409,
  "detail": "A 'build' operation is already running for repository 'sales-analytics'.",
  "instance": "/api/v2/operations/build"
}
```

| Status | Meaning in the Portal |
|--------|-----------------------|
| `400 Bad Request` | Validation failure — an empty required field (`appId`, `message`, `branch`, `directoryPath`…) or a rejected path (traversal guard). |
| `403 Forbidden` | A state-changing request from a page on another site (cross-origin guard), or a version switch, channel change, update, restart or shutdown from an address that is neither this computer nor in `Portal:AdminAllowedAddresses`. |
| `404 Not Found` | Unknown repository id, app id, or profile name. |
| `409 Conflict` | The same operation type is already running for that repository (per-repo+type lock), or the repository is already registered / its directory is missing on register. |
| `500 Internal Server Error` | Unexpected server fault — the `detail` carries the message; the full stack is in the Portal log. |

A failed **operation** (e.g. a build that the cmdlet rejected) is still an HTTP `200` with
`OperationResult.success = false` and the reason in `message` — distinguish "the API call was invalid"
(4xx) from "the operation ran and failed" (200 + `success:false`).

## Pagination

`GET /api/v2/git/{repo}/log` takes `?skip=` and `?take=` (default `take=20`, capped at `100`).
`GET /api/v2/repositories/{id}/recent-activity` takes `?count=` (default 10, capped at 50). There is no
cursor; page by increasing `skip`.

## Worked examples

### Register a repository, then list its apps

```http
POST /api/v2/repositories
Content-Type: application/json

{ "directoryPath": "C:\\Projects\\sales-analytics" }
```
```http
201 Created
Location: /api/v2/repositories/sales-analytics
{ "id": "sales-analytics", "name": "sales-analytics",
  "directoryPath": "C:\\Projects\\sales-analytics",
  "branches": ["main","feature/q3"], "currentBranch": "main",
  "lastActivity": "2026-06-17T09:14:02Z" }
```
```http
GET /api/v2/repositories/sales-analytics/apps
→ 200 [ { "id": "a1b2…", "name": "Sales Dashboard", "stream": "Finance",
          "repositoryId": "sales-analytics", "isLocal": true } ]
```

### List the applications on the connected Qlik

A different set from the one above, and the difference matters: `/repositories/{id}/apps` lists what the
REPOSITORY holds on disk, while this one lists what the connected Qlik ENVIRONMENT holds. Use it to
offer a picker wherever the caller would otherwise type a Qlik application id by hand — `QOps-SetLocalApp
-TargetAppId` is never checked against Qlik, so a typo there writes a mapping that points at nothing and
only surfaces later, mid-run.

```http
GET /api/v2/operations/sales-analytics/apps
→ 200 { "apps": [ { "id": "a1b2…", "name": "Sales Dashboard", "stream": "Finance",
                    "published": true, "owner": "Andrii Bosyi" } ] }
```

It runs `QOps-Apps` against the repository's active profile, so unlike the offline-safe
`/operations/{repoId}/spaces` it reaches the live environment. Three things to expect:

- **`"apps": []` is a result, not an error.** It means the environment answered and holds nothing.
- **A run that could not produce a list is a `500`**, and the `detail` is the tail of what the run
  ITSELF said (several lines, `\n`-separated) — not a list of causes the Portal guessed at. That is
  where "No default profile is configured", a licence message or a connection error will be.
- **It can take a while and it is bounded at three minutes.** Past that the run is stopped and you get
  the `500` with `[CANCELLED] Operation was cancelled.` in the detail.

On a QlikView environment the rows carry a name and little else — QOps yields `ViewAppInfo` there,
which has no id, stream, owner or published flag.

### Run a Build and follow the logs

```http
POST /api/v2/operations/build
{ "repositoryId": "sales-analytics", "appId": "a1b2…" }
→ 200 { "success": true, "message": "build started",
        "operationId": "op-7f3c…", "timestamp": "2026-06-17T09:20:00Z" }
```
Then open a SignalR connection to `/hubs/logs`, join group `op-7f3c…`, and receive `LogLine`
messages until the operation ends. (If a build is already running for this repo you get `409`.)

### Inspect Git status

```http
GET /api/v2/git/sales-analytics/status
→ 200 {
  "branch": "feature/q3", "isDetachedHead": false,
  "staged": ["Sales Dashboard-prj/App.json"],
  "modified": ["Sales Dashboard-prj/Sheets/Overview.json"],
  "added": [], "deleted": [], "renamed": [], "untracked": [],
  "hasConflicts": false, "ahead": 2, "behind": 0
}
```

### Commit

```http
POST /api/v2/git/sales-analytics/commit
{ "message": "Prepare: decompose Sales Dashboard" }
→ 200 { "success": true, "message": "…", "operationId": "…", "timestamp": "…" }
```

## Realtime

| Transport | Endpoint | Use it for |
|-----------|----------|-----------|
| **SignalR** | `/hubs/logs` (`LogHub`) | Join the group named after an `operationId`; receive `LogLine` messages (stdout/stderr, errors prefixed `[ERROR]`) live as the cmdlet runs. This is what the **Logs** panel uses. |
| **SSE** | `GET /api/v2/operations/{opId}/stream` | `text/event-stream` alternative: a `connected` event then a `heartbeat` every 5 s. Use when a SignalR client isn't convenient. |

A JavaScript SignalR client (the UI uses `@microsoft/signalr`):

```js
const conn = new signalR.HubConnectionBuilder().withUrl("/hubs/logs").build();
conn.on("LogLine", line => append(line));     // { text, isError, timestamp }
await conn.start();
await conn.invoke("JoinGroup", operationId);   // operationId from the POST response
```

## Automation / CI hook

`POST /api/v2/webhooks` is the unattended entry point. The `event` names **what happened in your CI**,
not what the Portal should do to your repository — so `push` means "a push has landed, take it", and
the Portal runs a **pull**:

| `event` | What the Portal runs | Reads it as |
|---|---|---|
| `push` | `git pull origin` | someone pushed — bring the commits here |
| `merge` | `git checkout <branch>` then `git pull origin <branch>` | switch to that branch and take it |
| `build` | `qops-build` | rebuild the apps (optional `metadata.appId`) |
| `deploy` | `qops-build -Publish` | publish the apps to Qlik |
| `release` | `qops-release` | cut a release |

**No event pushes anything to your git remote.** Nothing here writes to GitHub or GitLab; `deploy` and
`release` publish towards *Qlik*, not towards git. If you are looking for "the Portal pushes my local
commit", there is no such event — that would need a decision about whose credentials it goes out under.

```http
POST /api/v2/webhooks
X-Webhook-Secret: <your secret>
{ "event": "deploy", "repositoryId": "sales-analytics",
  "branch": "main", "metadata": { "appId": "a1b2…" } }
```

Unknown events are acknowledged with no action. `400` if `event`/`repositoryId` are missing, `404` if
the repo is unknown, `400` if `merge` is given a `branch` that starts with `-` or contains a control
character. For `merge`, a failed checkout stops the event there and the pull does not run.

### The webhook secret

This endpoint requires a shared secret in the `X-Webhook-Secret` header. Every request without it, or
with the wrong value, gets `401` — including on a Portal where nobody has set a secret yet, where the
endpoint accepts nothing at all. Only this endpoint is affected; the rest of the API is unchanged.

**What the Portal does for you**

- **You get one by running a command.** On the machine running the Portal:

  ```powershell
  QOps-SetWebhookSecret
  ```

  It generates a 256-bit secret and prints it. Put that value in your CI system's secret store.
- **In a LAN, that is enough.** The Portal listens on localhost by default; a runner on your own
  network with the secret can drive it, and nothing else can.
- **It is stored outside the Portal directory**, in `%USERPROFILE%\qopsconfig\portal.settings.json`,
  and only as a salted hash — the file cannot be turned back into a working secret. The file is
  restricted to your account (`0600` on Linux, an explicit ACL on Windows).
- **It survives `QOps-Update`.** The `Portal\` directory is replaced on every update; this file is not
  in it. You do not have to set the secret again after updating.
- **It applies immediately.** The Portal re-reads the file, so setting or rotating a secret needs no
  restart.

**What you must do yourself, to reach the Portal from outside your network**

The secret authenticates the caller. It does nothing about the connection, and the Portal serves plain
`http` out of the box — over the internet the header travels in clear and one captured request hands
your secret to whoever captured it. If a hosted runner (GitHub-hosted, GitLab.com) has to reach this
Portal, do all three of these first:

1. **Give the machine a public DNS name** that resolves from outside your network.
2. **Install a publicly trusted TLS certificate** for that name and serve the Portal over `https`
   (`Urls` plus `Kestrel:Certificates:Default:Path`/`Password` in
   `%USERPROFILE%\qopsconfig\portal.settings.json`, or a reverse proxy in front). It must be from a
   public CA — Let's Encrypt, DigiCert and so on. **A certificate from your internal corporate CA will
   not work**: hosted runners do not carry your CA, and `curl` fails the request before it is sent.
3. **Get inbound firewall approval** for that port from whoever runs your network.

Until all three are in place, keep the Portal reachable only from your own network and run the webhook
from a self-hosted runner inside it.

**Which account matters**

The secret is read from the profile of the account **the Portal runs as**. Setting it while logged in
as someone else writes a different file, the Portal never sees it, and every request comes back `401`
with nothing to distinguish it from a wrong secret. If the Portal runs as a service account, run
`QOps-SetWebhookSecret` as that account.

**Rotating it**

```powershell
QOps-SetWebhookSecret                       # generate a new one and show it
QOps-SetWebhookSecret -Value 'your-value'   # set a specific one (16+ printable ASCII characters)
```

Either form replaces the previous secret. No reinstall, no installer rerun, no Portal restart. Jobs
still sending the old value start getting `401` immediately, so update your CI secret store first or
expect a short gap.

**The secret is shown once**

It is printed to the PowerShell console at the moment it is created, and nowhere else. It is not
written to any log, not printed by the Portal, and not shown in the web UI. Only a salted hash is
stored, so there is no "show me the secret I forgot" — if you lose it, rotate.

**Calling it from CI**

Read the value from your CI system's secret store; never commit it. GitLab CI:

```yaml
deploy-qlik:
  script:
    - |
      curl --fail-with-body -X POST "$QOPS_PORTAL_URL/api/v2/webhooks" \
        -H "X-Webhook-Secret: $QOPS_WEBHOOK_SECRET" \
        -H "Content-Type: application/json" \
        -d '{"event":"deploy","repositoryId":"sales-analytics","metadata":{"appId":"a1b2…"}}'
```

GitHub Actions:

```yaml
- name: Publish to Qlik
  env:
    QOPS_WEBHOOK_SECRET: ${{ secrets.QOPS_WEBHOOK_SECRET }}
  run: |
    curl --fail-with-body -X POST "$QOPS_PORTAL_URL/api/v2/webhooks" \
      -H "X-Webhook-Secret: $QOPS_WEBHOOK_SECRET" \
      -H "Content-Type: application/json" \
      -d '{"event":"deploy","repositoryId":"sales-analytics"}'
```

`--fail-with-body` matters: without it `curl` exits `0` on a `401` and the job goes green while nothing
was published. The `401` body names the cmdlet to run and which account to run it as.

## Health

`GET /api/v2/health` (always `200`) is the cheapest way to confirm the Portal can do work:

```json
{ "status": "healthy",
  "dependencies": {
    "git":         { "available": true, "version": "2.45.1" },
    "powershell":  { "available": true, "version": "7.4.2",
                     "path": "pwsh" },
    "qops-module": { "available": true, "version": "3.0.7.26061710",
                     "path": "C:\\Program Files\\WindowsPowerShell\\Modules\\QOpsModule\\QOpsModule.psd1" } } }
```

`status` is `healthy` when every dependency is available, `degraded` when some are, and `unhealthy`
when none are. A missing dependency carries an `error` naming what was looked for and where.

`path` answers *which one* — a version alone cannot tell two builds of `3.0.12` apart, and two
PowerShell installations on one machine are ordinary. It is absent for `git`, which the OS resolves
on `PATH`.

**`GET /health` and `GET /api/v2/health/detailed` were removed on 2026-09-17** and now return 404.
They had carried `Deprecation`, `Sunset` and `Link: </api/v2/health>; rel="successor-version"`
headers since the announcement. `GET /api/v2/health` above is the replacement and returns the same
body. If you were reading `/api/v2/health/detailed`, note that its dependency keys were `pwsh` and
`qops`; here they are `powershell` and `qops-module`, as everywhere else.

## Stopping the Portal

`POST /api/v2/portal/shutdown` ends the Portal process. This is **not** the endpoint that stops a
running build or publish — that one is `POST /api/v2/operations/{opId}/cancel`.

While an operation is running the request is refused, so a shutdown cannot quietly take work down
with it:

```json
HTTP/1.1 409 Conflict
{ "title":  "Operations are still running",
  "detail": "One operation is still running. Wait for it to finish, or shut down anyway to stop it.",
  "activeOperations": ["b3f1c0de-..."] }
```

Add `?force=true` to go ahead anyway. Each running operation is then **cancelled** — the same path
the Stop button uses, which is what lets the QOps run end cleanly instead of being killed with its
crash sentinel still armed — and the answer is:

```json
HTTP/1.1 202 Accepted
{ "accepted": true,
  "cancelledOperations": ["b3f1c0de-..."],
  "pidFileRemoved": true,
  "stopsInMs": 750,
  "restartCommand": "Start-QOpsPortal" }
```

`202`, not `200`: the Portal is still up as the reply is written and stops shortly after, so the
response reaches the caller that asked for it. Expect the next request to this Portal to fail — that
is the endpoint working. Start it again with `Start-QOpsPortal`.

Like every other state-changing endpoint, this one is behind the cross-origin guard: a page on
another site cannot fire it (see [Authentication](#authentication)). It is accepted only from this
computer and from `Portal:AdminAllowedAddresses`; anyone else gets `403` (see
[Who may switch versions, update, restart or stop the Portal](#who-may-switch-versions-update-restart-or-stop-the-portal)).

## Updating QOps from the Portal

`POST /api/v2/portal/update` runs `QOps-Update` on the machine the Portal runs on, from the update channel
that machine is set to. It takes no parameters: no `-Force`, `-Beta` or `-Channel` is ever passed.

```json
HTTP/1.1 202 Accepted
{ "jobId": "20261005101500-update-3f9a1c", "kind": "update" }
```

The update runs in a PowerShell of its own, outside the Portal's process, so it is not cut off if the
Portal stops while it works. Follow it with `GET /api/v2/portal/update` (poll; the record is kept on disk,
so it is still there after a restart):

```json
{ "canUpdate": true,
  "runningModuleVersion": "3.0.20.26092208",
  "update": { "id": "20261005101500-update-3f9a1c", "state": "finished",
              "outcome": { "kind": "installed", "success": true,
                           "message": "QOps 3.0.21.26092411 is installed.",
                           "fromVersion": "3.0.20.26092208", "toVersion": "3.0.21.26092411" },
              "lines": ["Updating 'QOpsModule' 3.0.20.26092208 -> 3.0.21.26092411", "..."] },
  "restartTarget": "3.0.21.26092411" }
```

`outcome.kind` is one of `running`, `installed`, `upToDate`, `newerThanPublished`, `noNetwork`,
`rateLimited`, `tokenRejected`, `noWritePermission`, `moduleInUse`, `partial`, `interrupted` and
`failed`; `outcome.message` says what happened and what to do about it. `outcome.channel` is the update
channel the run read, and every verdict is relative to it: `upToDate` means the latest build in that
channel, `newerThanPublished` a build newer than the latest one in it. When a comparison was made,
`outcome.localVersion` and `outcome.serverVersion` carry the installed version and the latest one in the
channel. While it runs, `outcome.phase` and `outcome.progress` (a percentage, while downloading) say how
far it is.

The update is refused with `409` while another one is running, and when the Portal was not started by
`QOps-StartPortal`: it then does not know which QOps installation it belongs to (`canUpdate: false`, with
`cannotUpdateReason`).

`POST /api/v2/portal/restart` restarts the Portal on the version the update installed (`restartTarget`),
by running `QOps-SetVersion <version> -RestartPortal`. It answers `202`, and the Portal then stops and
comes back on the same address. It is refused with `409` while operations are running (their ids are in
`activeOperations`), while an update is running, and when the Portal was not started by `QOps-StartPortal`.

Both are behind the cross-origin guard, like every other state-changing endpoint, and both are accepted
only from this computer and from `Portal:AdminAllowedAddresses`; anyone else gets `403` (see
[Who may switch versions, update, restart or stop the Portal](#who-may-switch-versions-update-restart-or-stop-the-portal)).
The check (`POST /api/v2/portal/check`) is not under that rule: it installs nothing.

`GET /api/v2/portal/update` also says which QOps operations run in this Portal (Operations panel actions
and panel commands), so a page can tell in advance why a restart or a version switch is unavailable:

```json
{ "activeOperationCount": 2,
  "activeOperations": [ { "id": "b3f1c0de-...", "name": "build" },
                        { "id": "7a2e91f0-...", "name": "publish" } ] }
```

`name` is the operation type: `prepare`, `build`, `publish`, `reload`, `reload-status`, `release`, or the
command id of a panel command. Git panel actions, assistant tool calls and anything run in a PowerShell
window outside the Portal are not counted.

## Installed versions and the update channel

### `GET /api/v2/portal/versions`

Lists every QOps version installed for the PowerShell edition the Portal runs on, newest first, by running
`QOps-Version -Installed`. It installs and changes nothing.

```json
{ "runningVersion": "3.1.2.26101600",
  "runningModuleDirectory": "C:\\Program Files\\WindowsPowerShell\\Modules\\QOpsModule\\3.1.2.26101600",
  "versions": [
    { "version": "3.1.3.26102000", "path": "...\\3.1.3.26102000", "complete": false, "running": false,
      "shortcut": false, "kind": "VersionedFolder", "origin": "staging", "canSwitchVersions": true },
    { "version": "3.1.2.26101600", "path": "...\\3.1.2.26101600", "complete": true, "running": true,
      "shortcut": true, "kind": "VersionedFolder", "origin": "main-3.x", "canSwitchVersions": true },
    { "version": "3.0.21.26092411", "path": "...\\3.0.21.26092411", "complete": true, "running": false,
      "shortcut": false, "kind": "VersionedFolder", "origin": "MSI", "canSwitchVersions": false } ],
  "cannotListReason": null }
```

- `running` marks the version this Portal runs.
- `complete: false` is a version that was not completely installed (an interrupted update). It cannot be
  switched to.
- `shortcut` marks the version the Portal shortcuts start; `kind` is `VersionedFolder` or `InstallerCopy`;
  `origin` is the update channel the version came from, `MSI`, `PKG` or `Unknown`
  (see [QOps-Update](COMMAND-update.md#which-versions-are-installed)).
- `canSwitchVersions: false` means the Portal of that version cannot switch versions itself: after switching
  to it, going back needs PowerShell (`QOps-SetVersion <version>`).

When the Portal was not started by `QOps-StartPortal`, `versions` is empty and `cannotListReason` says why.
When QOps cannot be asked, or lists nothing, the answer is `500` with the reason in `detail`.

### `POST /api/v2/portal/versions/switch`

Restarts the Portal on any complete installed version, newer or older, by running
`QOps-SetVersion <version> -RestartPortal`, the same way as `POST /api/v2/portal/restart`. The Start menu
and Desktop shortcuts start that version from then on.

```json
POST /api/v2/portal/versions/switch
{ "version": "3.0.21.26092411" }

HTTP/1.1 202 Accepted
{ "jobId": "20261016101500-restart-3f9a1c", "kind": "restart", "targetVersion": "3.0.21.26092411",
  "targetCanSwitchVersions": false, "older": true }
```

The switch is a restart job: follow it under `restart` in `GET /api/v2/portal/update`. The Portal then stops
and comes back on the same address. `older` says the target is older than the running version, and
`targetCanSwitchVersions: false` that the way back from it needs PowerShell.

| Status | `title` | When |
|---|---|---|
| `400` | `Version required`, `Not a version` | No version in the body, or not a version number. |
| `409` | `QOps module not found` | The Portal was not started by `QOps-StartPortal`. |
| `409` | `An update is already running` | An update, check or restart started from the Portal is running. |
| `409` | `Version not installed` | The version is not in `GET /api/v2/portal/versions`; `detail` lists the installed ones. |
| `409` | `Already running` | The Portal already runs that version. |
| `409` | `Version incomplete` | The version was not completely installed. |
| `409` | `The Portal cannot restart itself` | The Portal is not the one `QOps-StartPortal` started (no `portal.pid` naming it). |
| `409` | `Operations are still running` | QOps operations run in this Portal; `activeOperations` holds their ids and `activeOperationNames` their names. |
| `500` | `Could not list the installed versions` | QOps could not be asked which versions are installed. |

### `POST /api/v2/portal/channel`

Sets the update channel this computer updates from, for your account, by running
`QOps-SetUpdateChannel <channel> -PassThru`, then starts an update check, as `POST /api/v2/portal/check`
does, so the result shows what the new channel offers. Nothing is installed.

```json
POST /api/v2/portal/channel
{ "channel": "staging" }

HTTP/1.1 200 OK
{ "previous": "main-3.x", "channel": "staging", "isRelease": false,
  "checkJobId": "20261016101600-check-8b21d4", "checkNotStartedReason": null }
```

`main-3.x` (or `main`) is the release channel. The name follows the command's rule: letters, digits, dot,
dash and underscore, at most 100 characters. Follow the check under `check` in `GET /api/v2/portal/update`;
when it could not start, `checkJobId` is null and `checkNotStartedReason` says why. The channel is still
changed.

A channel change is allowed while operations run.

| Status | `title` | When |
|---|---|---|
| `400` | `Channel required`, `Not a valid channel name` | No name, or one the command would refuse. |
| `409` | `QOps module not found` | The Portal was not started by `QOps-StartPortal`. |
| `409` | `An update is already running` | An update, check or restart started from the Portal is running. |
| `500` | `The update channel was not changed` | The command did not change it; `detail` holds what it said. |

Both POSTs are behind the cross-origin guard, like every other state-changing endpoint, and both are
accepted only from this computer and from `Portal:AdminAllowedAddresses`; anyone else gets `403` before
the body is read (see
[Who may switch versions, update, restart or stop the Portal](#who-may-switch-versions-update-restart-or-stop-the-portal)).

## See also

- [User Guide](USER-GUIDE.md) — using the Portal UI.
- [Getting Started for Analytics Engineers](GETTING-STARTED.md) — first end-to-end run.
- `/swagger` on the running Portal — the complete, authoritative route catalog.
