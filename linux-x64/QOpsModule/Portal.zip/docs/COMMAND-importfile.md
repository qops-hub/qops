# QOps-ImportFile

**What it does.** Uploads a file from your disk into the data files of a Qlik Cloud space — the
CSVs, QVDs and spreadsheets a script loads with `lib://<space>:DataFiles/<file>`.

**Direction.** disk → Qlik. Nothing is downloaded and nothing local is changed.

**In the Portal.** On the **Operations** panel as **Import file**. Open **All commands**, find it
under *Data files*, and either run it from the list or pin it so it gets a button of its own — see
[Choosing what the panel shows](COMMANDS.md#choosing-what-the-panel-shows).

**Needs.** Qlik Cloud. Run against a Qlik Sense or QlikView configuration it reports that data files
are supported only in Qlik Cloud mode and stops without doing anything.

    QOps-ImportFile -Space Sales -Path .\data\Customers.csv
    QOps-ImportFile -Space Sales -Path .\data\*.csv
    QOps-ImportFile -Space Sales -Path .\data\*.csv -QlikPath Extracts/Daily
    QOps-ImportFile -Space Sales -Root .\data -Path *.csv -QlikPath Extracts

## What comes back

One object per file, carrying the file's `Name`, its `Id` in the space, and a `Status` of `Done` or
`Failed`. A run over a pattern returns as many objects as it matched, so

    (QOps-ImportFile -Space Sales -Path .\data\*.csv).Count

is the number of files, not one.

One file failing does not stop the run. The others are still attempted, and the failures are in the
output with their reason in the log.

## Naming the files

`-Path` takes either an exact name or a wildcard, so a set of files is one command rather than a
loop. It matches files **on your disk**.

A wildcard matching nothing is not an error. The command says what it searched for and returns
nothing — so "wrong folder" and "no such file" do not read identically.

An exact name is treated as a promise that the file is there: not finding it stops the command and
names the path it looked for. So is naming a folder without a wildcard — the message says to add one,
because a folder full of files is a different request from one file.

## Taking a tree out and putting it back

This is what `-Root` is for. Export the files, change one, import them back, and each file returns to
the folder it came from:

    QOps-ExportFile -Space Sales -QlikPath Extracts -File *.csv -Path .\out
    # edit .\out\2026\b.csv
    QOps-ImportFile -Space Sales -Root .\out -Path *.csv -QlikPath Extracts

The two are inverses, which is why the same folder name appears once on each line: the export takes
`Extracts` off the front and lays the rest out under `-Path`, and the import counts from `-Root` and
puts the rest back under `-QlikPath`. So `-Root` is simply the folder the export wrote into. Re-running the import is safe: a file already in its
folder is replaced rather than duplicated, and that holds at every level of the tree, not just the top.

## Re-importing

A name already present in the space is replaced in place. That is what makes re-running an import
after a change the same command each time, and it is why this command has no overwrite switch.

## Flags

### -Space

The Qlik Cloud space the file is uploaded into. Required. The space is found by name, and the API key
you are configured with has to be a member of it; if it is not, the command says so rather than
reporting an empty space.

### -Path

The local file to upload, or a wildcard matching several. Required — this is the source.

An absolute path is used exactly as written. A relative one is counted from the folder you are standing
in, so `.\data\*.csv` is the `data` folder you can see, and it stays that folder whether or not the
repository's `.qopsconfig` sits above you. Both forms, with examples, are in
[Local paths](COMMANDS.md#local-paths).

Only the file name may be a wildcard, and one folder is read: `-Path .\data\*.csv` takes the files in
`data` and not the ones in `data\2026`. To reach a whole tree, give [`-Root`](#root) — that is what
turns `-Path` into a pattern matched across folders.

The wildcard is PowerShell's own, so `*`, `?` and `[a-z]` select here exactly what they select at the
prompt.

### -Root

The folder your local structure is counted from. Optional. Give it, and two things change together:
`-Path` is matched against each file's path **relative to this folder**, and every file lands in
`-QlikPath` plus its own folder — so the shape on your disk is reproduced in the space.

    QOps-ImportFile -Space Sales -Root .\data -Path *.csv -QlikPath Extracts

    .\data\a.csv          ->  Extracts/a.csv
    .\data\2026\b.csv     ->  Extracts/2026/b.csv
    .\data\2026\q1\c.csv  ->  Extracts/2026/q1/c.csv

Without `-Root` nothing changes: one folder is read, no structure is copied, and every match goes
into `-QlikPath` itself. There is no separate switch to turn mirroring on, because without a folder
to count from there is nothing for it to mean.

**A `*` crosses folders here.** `-Path *.csv` takes the whole tree under the root, and
`-Path 2026/*.csv` takes one branch of it. This is worth knowing because it is the one place a
pattern behaves differently with `-Root` than without: on its own, `-Path` reads a single folder.

Counting from the root, rather than from wherever the wildcard happens to start, is what keeps the
result predictable — `-Path 2026/q1/*.csv` and `-Path *.csv` put `c.csv` in the same place, because
the tree is defined by the root and not by how you wrote the pattern.

### -QlikPath

A folder inside the space to upload into, for example `Extracts/Daily`.

Called `-TargetPath` before 3.0.20, and that spelling still works — it is kept as an alias, so
existing scripts need no change. The name moved because it reverses with direction: on an export the
disk is the target and Qlik is the source, so the Qlik folder needed a name that means the same thing
on all three data-file commands. Optional — without it the
files land at the top level of the space, which is where they have always gone.

One destination for the whole command — unless you also give [`-Root`](#root), which makes this the
TOP of a mirrored tree instead. Either way `-Path` chooses the files and `-QlikPath` chooses where
they land. Folders that do not exist yet are created on the way.

Give the folder path on its own, relative to the space — `Extracts/Daily`, not the `Space:DataFiles/...`
form you would write in a load script. The space is already chosen by `-Space`, so a prefix like that
would be taken as a folder name and a folder would be created called exactly that. The command refuses
it rather than creating it, and the same goes for a wildcard here: the wildcard belongs in `-Path`.

A file already in that folder is replaced, exactly as at the top level — so re-running the import
after a change stays the same command each time.

### -Profile

Which configured authentication profile to use, when you run the command yourself. The Portal does
not offer it: the command runs in the repository, so it uses the repository profile, like Prepare and
Build do.

### -VerboseLog

Writes a fuller log for this run, with passwords, keys and tokens masked. Turn it on when you are going to send a log to somebody.

## See also

- [Data files](COMMAND-datafiles.md) — the group this command belongs to, and the flows it takes part in
- [QOps-ExportFile](COMMAND-exportfile.md) — the other direction
- [QOps-RemoveFile](COMMAND-removefile.md) — deleting a data file from the space
- [Commands](COMMANDS.md) — the whole command map
