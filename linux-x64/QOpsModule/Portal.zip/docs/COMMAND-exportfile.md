# QOps-ExportFile

**What it does.** Brings a data file down from a Qlik Cloud space into a local folder.

**Direction.** Qlik → disk. The file in the space is left exactly as it is.

**Not `QOps-ExportQVF`.** That one writes out a whole application; this writes out one data file the
applications load from.

**In the Portal.** On the **Operations** panel as **Export file**. Open **All commands**, find it
under *Data files*, and either run it from the list or pin it so it gets a button of its own — see
[Choosing what the panel shows](COMMANDS.md#choosing-what-the-panel-shows).

**Needs.** Qlik Cloud. Run against a Qlik Sense or QlikView configuration it reports that data files
are supported only in Qlik Cloud mode and stops without doing anything.

    QOps-ExportFile -Space Sales -File Customers.qvd -Path .\data
    QOps-ExportFile -Space Sales -File *.qvd -Path .\data -Force

## What comes back

One object per file, carrying the file's `Name`, its `Id` in the space, and a `Status`. A run over a
pattern returns as many objects as it matched, so

    (QOps-ExportFile -Space Sales -File *.qvd -Path .\data).Count

is the number of files, not one.

`Status` is `Done`, `Failed`, or `Skipped`. **`Skipped` is its own outcome**, not a quiet failure: the
file was left alone because the name was already taken on disk and [`-Force`](#force) was not given.
A script reporting on a run should treat the three separately.

One file failing does not stop the run. The others are still attempted, and the failures are in the
output with their reason in the log.

## Naming the files

`-File` takes either an exact name or a wildcard, so a set of files is one command rather than a
loop. It matches the names **in the space**.

A space can hold folders, and `-File` looks through all of them, matching the full name a file has in
the space. **`-QlikPath` confines it to one folder**, and `-File` may then be the plain file name,
because you have said where to look.

    QOps-ExportFile -Space Sales -QlikPath archive/2025 -File *.qvd -Path .\data

**`-QlikPath` and `-Path` are not the same thing.** `-QlikPath` is the folder on Qlik to read
from; `-Path` is the folder on your disk to write to. The path on Qlik is relative to the space and
is the same `-QlikPath` that `QOps-ImportFile` puts a file into.

The name says which SIDE it is on, not which end of the transfer it is: on an export the disk is the
destination and Qlik is the source, so calling the Qlik folder a "target" would read backwards here
while reading correctly on import. `-QlikPath` means the same thing on all three data-file commands.

Nothing matching is not an error. The command says what it searched for and how many data files the
space holds, and returns nothing — so "wrong space" and "no such file" do not read identically.

## Large files

An export is fetched in pieces so that memory does not grow with the size of the file, and
[`-ChunkSize`](#chunksize) and [`-SliceSize`](#slicesize) are the two sizes involved. Expect a
several-hundred megabyte export to take minutes rather than seconds. Ctrl+C is answered between
pieces rather than only at the end of the file.

## Flags

### -Space

The Qlik Cloud space holding the data files. Required. The space is found by name, and the API key
you are configured with has to be a member of it; if it is not, the command says so rather than
reporting an empty space.

### -File

The data file **in the space** to export: an exact name or a wildcard. Required.

### -QlikPath

The folder **inside the space** to read from. Optional. Omitted, `-File` is matched against the name
each data file has in the space, folders included; named, the search is confined to that folder and
`-File` may be the plain file name, because you have said where to look.

    QOps-ExportFile -Space Sales -QlikPath archive/2025 -File sales.qvd -Path .\data

Written with `/` or `\`, relative to the space.

**The folder you name includes everything under it.** `-QlikPath archive` reads `archive/sales.qvd`
and `archive/2025/sales.qvd` alike: it bounds the search from above, it does not pick out one level.
Both keep their place under `-Path`, so they land as `sales.qvd` and `2025\sales.qvd` and cannot
overwrite each other. Where two matched files would resolve onto the same file on disk, the export
stops and names both rather than letting one replace the other.

It is the same `-QlikPath` that `QOps-ImportFile` puts a file into and that `QOps-RemoveFile` deletes
in, and it is **not** `-Path`: this one is the folder on Qlik, `-Path` is the folder on your disk. It
also decides the layout on disk — see [`-Path`](#path).

### -Path

The local folder each exported file is written into. Optional.

An absolute path is used exactly as written. A relative one is counted from the folder you are standing
in, so `.\data` is the `data` folder you can see, and it stays that folder whether or not the
repository's `.qopsconfig` sits above you. The folder is created if it is not there yet. Both forms,
with examples, are in [Local paths](COMMANDS.md#local-paths).

Left out altogether, the files are written into the folder QOps takes as the repository's — the one
holding `.qopsconfig` — which is not necessarily the folder you are standing in. **Write `-Path .` when
you mean here**; leaving the switch out and writing `.` are not the same request.

A file that sits inside a folder of the space **keeps the folders below the one you named**, and the
one you named is not repeated. Without `-QlikPath`, a file's name is its whole path, so
`archive/2025/sales.qvd` is written to `<-Path>\archive\2025\sales.qvd`. With `-QlikPath archive`,
the same file is written to `<-Path>\2025\sales.qvd` — you have already said `archive`. Either way
the folders in between are created for you, two files with the same leaf name in different folders
stay separate files on disk, and nothing is ever written outside `-Path`.

That is what makes the round trip work: `-QlikPath` on the way out and `-Root` on the way back are
inverses, so [QOps-ImportFile](COMMAND-importfile.md#root) puts each file where it came from.

### -Force

Replaces a local file that already has the name the export wants.

Without it, that file is left exactly as it is and the export reports it `Skipped`. This is on
purpose, and it is deliberately different from `QOps-ExportQVF`, which overwrites without asking: an
export can be run again at any time, whereas a local file somebody has edited cannot be brought back.
The check is made before the download as well as at the moment of writing, so a file you will not be
allowed to replace does not cost you the wait.

Note that this is not the `-Force` described on the
[Commands](COMMANDS.md#how-to-read-the-flag-sections) page, which skips the confirmation on a run
touching more than ten applications. Here it means "overwrite the local file".

### -ChunkSize

How many bytes of the source file are fetched per call, as a whole number. Omitted, it is 1 MB.

The working size belongs to your tenant rather than to QOps, so this is here for the tenant whose
memory limit is lower than the default assumes: a failing export on a large file is the reason to
bring it down.

### -SliceSize

How many bytes are read per pass, as a whole number. Omitted, it is 32 MB. The same reasoning as
`-ChunkSize`, one level up: `-ChunkSize` is how much comes back at a time within a pass, `-SliceSize`
is how much of the file a pass covers.

### -Profile

Which configured authentication profile to use, when the repository has more than one. The same
switch as on every other command.

### -VerboseLog

Writes a fuller log for this run. Turn it on when you are going to send a log to somebody.

## See also

- [Data files](COMMAND-datafiles.md) — the group this command belongs to, and the flows it takes part in
- [QOps-ImportFile](COMMAND-importfile.md) — the other direction
- [QOps-RemoveFile](COMMAND-removefile.md) — deleting a data file from the space
- [Commands](COMMANDS.md) — the whole command map
