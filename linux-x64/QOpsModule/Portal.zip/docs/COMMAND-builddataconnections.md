# QOps-BuildDataConnections

**What it does.** Creates the connections held in the repository as files in the target Qlik
environment. This is what [`QOps-Build`](COMMAND-build.md) does for applications.

**Direction.** disk → Qlik.

**In the Portal.** On the **Operations** panel as **Build connections**.

**Needs.** **Qlik Sense only.** Run against a Qlik Cloud configuration it says so and stops without
doing anything.

    QOps-BuildDataConnections
    QOps-BuildDataConnections -Filter "Name=lib_sales*"

## Which connections it creates

Given no `-Filter`, it uses the filter the repository has saved — the one
[`QOps-AddDataConnections`](COMMAND-adddataconnections.md) put there. Given a `-Filter`, that filter
wins for this run.

With no filter given and none saved, it creates nothing and says so:

    QOps-BuildDataConnections: no filter was given and none is saved in this repository, so no data
    connections were touched. Write commands do not act on everything by default - pass -Filter * to
    include every one of them, or a name or pattern to narrow it.

Everything stays reachable — it just has to be asked for. A write command that silently expanded "no
filter" into "all of them" would make an unattended script change far more than its author meant.

The source is the files [`QOps-PrepareDataConnections`](COMMAND-preparedataconnections.md) wrote, so
a Build with nothing prepared has nothing to create.

## A connection that already exists

A connection the target environment already has, matched by name, is updated in place, never deleted
and created again. It keeps its id. The password is never in the repository file, because Qlik Sense
does not hand it out, and the update does not send one, so QOps does not change the password stored
with the connection. Custom properties and tags are set from the file when the file lists them; when it
does not, the server's stay as they are.

The owner from the file is applied when it differs from the connection's owner, after the update. If
it cannot be applied, for example because that user does not exist on the server or the change is not
allowed, QOps writes a warning that names the connection, the owner and the reason, and keeps the
connection as updated; its row still says `Done`.

If Qlik Sense refuses the update, the connection is left exactly as it was and its row says `Failed`.
A connection that exists only in the repository is created.

## Flags

### -Filter

Which connections to act on. The same filter grammar the rest of QOps uses: `Name=`, `Id=`, `*` and
`?` as wildcards, and `;` between clauses when you want several.

    -Filter "Name=lib_sales*"
    -Filter "Name=lib_sales*;Name=lib_hr*"

> The `;` is part of the filter, not a separator the Portal invents. Typed into the panel it reaches
> the command intact, so a two-clause filter from the panel is the two-clause filter you wrote.

Left out, the repository's saved connection filter is used.

### -Sort

Which column the result is ordered by, by name. It changes the order of the output only, not which
connections are found.

### -Profile

Which configured authentication profile to use, when you run the command yourself. The Portal does
not offer it: the command runs in the repository, so it uses the repository profile, like Prepare and
Build do.

### -VerboseLog

Writes a fuller log for this run, with passwords, keys and tokens masked. Turn it on when you are going to send a log to somebody.

## See also

- [Data connections](COMMAND-dataconnections.md) — the group this command belongs to, and the flows it takes part in
- [QOps-PrepareDataConnections](COMMAND-preparedataconnections.md) — the other direction
- [Commands](COMMANDS.md) — the whole command map
