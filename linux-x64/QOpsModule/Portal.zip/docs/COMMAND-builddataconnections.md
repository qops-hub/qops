# QOps-BuildDataConnections

**What it does.** Creates the connections held in the repository as files in the target Qlik
environment. This is what [`QOps-Build`](COMMAND-build.md) does for applications.

**Direction.** disk → Qlik.

**In the Portal.** On the **Operations** panel as **Build connections**.

**Needs.** **Qlik Sense only.** Run against a Qlik Cloud configuration it says so and stops without
doing anything.

    QOps-BuildDataConnections
    QOps-BuildDataConnections -Filter "Name=lib_sales*"

## Which connections it creates

Given no `-Filter`, it uses the filter the repository has saved — the one
[`QOps-AddDataConnections`](COMMAND-adddataconnections.md) put there. Given a `-Filter`, that filter
wins for this run.

With no filter given and none saved, it creates nothing and says so:

    QOps-BuildDataConnections: no filter was given and none is saved in this repository, so no data
    connections were touched. Write commands do not act on everything by default - pass -Filter * to
    include every one of them, or a name or pattern to narrow it.

Everything stays reachable — it just has to be asked for. A write command that silently expanded "no
filter" into "all of them" would make an unattended script change far more than its author meant.

The source is the files [`QOps-PrepareDataConnections`](COMMAND-preparedataconnections.md) wrote, so
a Build with nothing prepared has nothing to create.

## Flags

### -Filter

Which connections to act on. The same filter grammar the rest of QOps uses: `Name=`, `Id=`, `*` and
`?` as wildcards, and `;` between clauses when you want several.

    -Filter "Name=lib_sales*"
    -Filter "Name=lib_sales*;Name=lib_hr*"

> The `;` is part of the filter, not a separator the Portal invents. Typed into the panel it reaches
> the command intact, so a two-clause filter from the panel is the two-clause filter you wrote.

Left out, the repository's saved connection filter is used.

### -Sort

Which column the result is ordered by, by name. It changes the order of the output only, not which
connections are found.

### -Profile

Which configured authentication profile to use, when the repository has more than one. The same
switch as on every other command.

### -VerboseLog

Writes a fuller log for this run, with passwords, keys and tokens masked. Turn it on when you are going to send a log to somebody.

## See also

- [Data connections](COMMAND-dataconnections.md) — the group this command belongs to, and the flows it takes part in
- [QOps-PrepareDataConnections](COMMAND-preparedataconnections.md) — the other direction
- [Commands](COMMANDS.md) — the whole command map
