# QOps-Update

**What it does.** Installs the newest QOps build in this computer's update channel, beside the version
you have. With `-CheckOnly` it only looks: it says whether a newer build exists and installs nothing.

**Direction.** GitHub, where QOps builds are published, to this computer. Nothing is sent to Qlik.

**When you need it.** To move to a newer build now rather than waiting for the daily automatic update,
or, with `-CheckOnly`, to find out whether there is one. The Portal's version panel runs both: **Check
for updates** is `QOps-Update -CheckOnly`, and **Update to &lt;version&gt;** is `QOps-Update`. See
[Updating QOps from the Portal](USER-GUIDE.md#updating-qops-from-the-portal).

    QOps-Update -CheckOnly
    QOps-Update

## Which channel it reads

One channel per run: the one given with `-Channel`, otherwise the one this computer is set to with
`QOps-SetUpdateChannel`, otherwise `main-3.x`. Every answer is about that channel only. A build can be
the latest in `main-3.x` while a newer one exists in another channel.

## What a check returns

`QOps-Update -CheckOnly` returns one object and prints one line saying the same.

| Field | What it holds |
|---|---|
| `Installed` | The newest QOps installed on this computer, across both PowerShell editions |
| `Channel` | The channel that was read |
| `LatestInChannel` | The latest build in that channel; empty when the check failed |
| `UpdateAvailable` | `True` only when that build is newer than `Installed` |
| `Status` | `UpdateAvailable`, `LatestInChannel`, `NewerThanChannel` or `Failed` |
| `FailureKind` | When the check failed: `NoNetwork`, `RateLimited`, `TokenRejected`, `NotPublished` or `Other` |
| `FailureReason` | When the check failed: the cause and what to do about it |

`LatestInChannel` means you have the latest build in that channel. `NewerThanChannel` means your build is
newer than anything in it, for example a build installed from another channel. Neither is an update.

A check can fail without reaching GitHub (`NoNetwork`), on GitHub's request limit (`RateLimited`), on a
GitHub token that GitHub no longer accepts (`TokenRejected`), or on a channel that has no QOps build
(`NotPublished`, usually a misspelt channel name). A failed check never reads as "nothing to update".

To use the answer in a script:

    $check = QOps-Update -CheckOnly
    if ($check.UpdateAvailable) { QOps-Update }

## Which versions are installed

`QOps-Update` installs each build beside the ones you have. To see them, run:

    QOps-Version -Installed

It returns one object per installed version of QOps for the PowerShell you run it in (Windows
PowerShell and PowerShell 7 keep separate copies), newest first. It only reads: it runs no automatic
update and changes nothing. Without `-Installed`, `QOps-Version` prints the running version as before.

| Field | What it holds |
|---|---|
| `Version` | The build, for example `3.1.1.26101409` |
| `Path` | The folder it is in |
| `Complete` | `True` when the folder holds the whole module. `False` for a download that was interrupted |
| `Running` | `True` for the version this PowerShell window runs |
| `Shortcut` | `True` for the version the Portal shortcuts start |
| `Kind` | `VersionedFolder`: its own folder named after the version. `InstallerCopy`: files straight in the module folder, as older installers and `QOps-Update -Force` on Windows lay them down |
| `Origin` | The update channel it was installed from, for example `main-3.x`, `staging` or `staging-mcp`; `MSI` or `PKG` when an installer put it there; `Unknown` when nothing recorded it, as for versions an earlier QOps release installed |

The origin is kept in a file named `.origin` inside the version's folder, so it goes when the folder
goes. Two installations of the same version, a version folder and an installer copy, are two entries.

## Changing the channel for good

    QOps-SetUpdateChannel staging-mcp
    QOps-SetUpdateChannel main

sets the channel every later update on this computer reads, including the daily automatic one. `main`
is the 3.x release channel, stored as `main-3.x`; `main-2.x` is the frozen 2.x line.

With `-PassThru` it also returns the change as an object, and prints the same lines:

| Field | What it holds |
|---|---|
| `Previous` | The channel before the change; `main-3.x` if it had never been changed |
| `Channel` | The channel now, as it is stored |
| `IsRelease` | `True` when `Channel` is the release channel, `main-3.x` |

Nothing is returned when the channel was not changed: an invalid name, or a settings folder that could
not be written. The printed line says which.

## Flags

### -CheckOnly

Reads the latest build in the channel, compares it with the installed one, and stops. It installs
nothing, runs no daily automatic update, and leaves the Portal shortcuts as they are. It makes one
request to the GitHub API, with your own GitHub token when one is set (`QOps-SetConfig -GitHubToken`),
the same as an update. `-Force` has no effect with it.

### -Channel

Reads or installs from this channel for this run only, for example `-Channel staging-mcp`. It changes
nothing on the computer. To change the channel for good, use `QOps-SetUpdateChannel`.

### -Beta

Reads the beta channel for this run, when no channel is given and none is set on this computer.

### -Force

Reinstalls the latest build in the channel even when the installed one is the same or newer. On
Windows it uses the update tool that closes running PowerShell windows to replace the files. When the
QOps Portal runs from a newer version that this build replaces, the update stops and asks you to close
the Portal first; run `QOps-Update -Force` again once it is closed. The Portal never passes it.
