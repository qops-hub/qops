# Data connections

**What this group is.** Four commands work on the data connections of a Qlik environment — the
`lib://` connections a load script reads through. Together they do for connections what Prepare and
Build do for applications: bring them into the repository as files, and put them back into Qlik.
This page is the map; each command has its own page with its own flags.

| Command | What it does | Direction | Page |
|---|---|---|---|
| `QOps-ShowDataConnections` | Lists the connections the environment has | Qlik only | [QOps-ShowDataConnections](COMMAND-showdataconnections.md) |
| `QOps-AddDataConnections` | Records which connections this repository tracks | configuration | [QOps-AddDataConnections](COMMAND-adddataconnections.md) |
| `QOps-PrepareDataConnections` | Writes the tracked connections into the repository as files | Qlik → disk | [QOps-PrepareDataConnections](COMMAND-preparedataconnections.md) |
| `QOps-BuildDataConnections` | Creates those connections in Qlik from the files | disk → Qlik | [QOps-BuildDataConnections](COMMAND-builddataconnections.md) |

**In the Portal.** All four are on the **Operations** panel. Open **All commands**, find them under
*Data connections*, and either run one from the list or pin it so it gets a button of its own — see
[Choosing what the panel shows](COMMANDS.md#choosing-what-the-panel-shows).

**Needs.** `QOps-ShowDataConnections` and `QOps-PrepareDataConnections` work against Qlik Sense and
Qlik Cloud. `QOps-BuildDataConnections` is **Qlik Sense only**: run against a Qlik Cloud
configuration it says so and stops without doing anything. `QOps-AddDataConnections` reaches no
server at all — it only writes the repository's own configuration — so it has no platform
requirement of its own.

## Flows

**Put a set of connections under version control.**

    QOps-ShowDataConnections                       # see what is there
    QOps-ShowDataConnections -Filter "Name=lib_*"  # narrow it down
    QOps-AddDataConnections  -Filter "Name=lib_*"  # remember that set for this repository
    QOps-PrepareDataConnections                    # write the files
    QOps-BuildDataConnections                      # create them in the target environment

The last two lines work with no arguments because `QOps-AddDataConnections` saved the set into the
repository's own configuration, under `DataConnectionsFilter`, and Prepare and Build fall back to it.

**Add a second set later.**

    QOps-AddDataConnections -Filter "Name=lib_hr*"

Add appends, so the repository now tracks both sets. Use `-NoAppend` when you want the new set to be
the whole set instead.

**Move connections to another environment.**

    QOps-PrepareDataConnections            # from the source environment
    QOps-BuildDataConnections -Profile target

Prepare reads from the environment the profile points at, and Build writes to the one you name. In the
Portal, switch the environment before you run Build instead: its Build does not offer `-Profile`.

## Show and Add, and when they are a pair

`QOps-AddDataConnections` given **no** `-Filter` uses what the last `QOps-ShowDataConnections` found
in the same PowerShell session. Given a `-Filter`, it uses what you typed and never consults Show at
all — so the two are linked in the no-filter case and independent otherwise.

The Portal runs each panel action in its own PowerShell process, so a Show run as one action and an
Add run as another would share nothing. The **Add connections** action therefore runs the pair in one
go when the filter box is empty, and runs Add alone when you have typed a filter. The command preview
shows whichever of the two it is about to run.

## If a run does nothing

- **Nothing is listed.** The filter matched nothing, or the profile is pointed at an environment that
  genuinely has no connections. Run `QOps-ShowDataConnections` with no filter to tell those apart.
- **Prepare or Build says data connections are supported only in Qlik Sense mode.** They are. The
  Qlik Cloud side of `QOps-BuildDataConnections` is not in this release.
- **Prepare finds nothing after an Add.** Check the repository's saved filter in
  [Configuration](CONFIGURATION.md#the-repository-file). If it is empty, an Add ran with no filter and
  no preceding Show in the same session — from the Portal that cannot happen, because the panel either
  runs the pair together or gives Add a filter of its own.

## See also

- [Data files](COMMAND-datafiles.md) — the other Cloud group: uploading, downloading and deleting the
  data files a script loads
- [Commands](COMMANDS.md) — the whole command map
- [Configuration](CONFIGURATION.md#the-repository-file) — where the saved connection filter is kept
- [Panels](PANELS.md#operations) — the Operations panel itself
