# QOps-Prepare

**What it does.** Reads an application from Qlik and writes it into the repository as files — the
script, the sheets and their objects, the master items, the variables, the application's own
properties. This is the direction that gets Qlik work under version control.

**Direction.** Qlik → disk. Nothing in Qlik is changed by a prepare.

**In the Portal.** Operations → Prepare.

## Prepare or Build

They are opposites, and the names do not say so.

- **Prepare** takes what is in Qlik and writes it to disk. Run it when somebody changed the app in
  Qlik and you want those changes in the repository.
- **Build** takes what is on disk and writes it into Qlik. Run it when you changed the files and want
  the application to match.

Running the wrong one does not fail — it succeeds in the direction you did not want, and overwrites
the side you meant to keep. Commit before either one and the mistake costs a `git checkout`.

## Adding an application that is not in the repository yet

A prepare filtered to an application Id writes a new `-prj` folder for it. That is how an app enters a
repository; the Portal's **Add App** button does exactly this. See
[Getting Started](GETTING-STARTED.md#2-get-an-app-into-the-repository).

## Flags

### -NoData

Opens the application without loading its data. The files a prepare writes are objects and script, not
data, so the result is the same — this is a speed and memory switch, and it is the one to reach for on
an application whose data model is large.

### -IncludeBookmarks

Bookmarks are not written by default. This writes them: the private ones, belonging to the user QOps
connects as.

### -AllBookmarks

Writes published bookmarks as well as private ones. It turns bookmark handling on by itself, so it
does not need `-IncludeBookmarks` alongside it.

### -AllSheets

On a published application, only approved sheets are written by default. This writes every sheet,
including private and community ones. On an unpublished application every sheet is written anyway, so
the switch changes nothing there.

### -AllPublishedSheets

The middle setting between the default and `-AllSheets`: every published sheet, whether or not it was
approved. Private sheets stay out. If both are given, `-AllSheets` wins.

### -AllVariables

Variables created by the load script are skipped by default, because the script recreates them on
every reload and storing them adds noise to every diff. This writes them too.

### -MaintainExtensions

Keeps the extension names the application uses as they are. Without it, a widget pointing at a local
copy of an extension is written with the original extension's name, so the files describe the shared
extension rather than your copy. Use it when the local names are the ones you want in the repository.

### -SkipCustomProperties

Does not read the application's custom properties. Useful against a Qlik where custom properties are
managed outside QOps, or where the account QOps uses cannot read them.

### -Path

Limits the run to the objects under one path, glob or single file inside the app's `-prj` folder —
`Dimensions`, `Sheets/<id>`, `Variables/v*`. Everything outside it is left exactly as it is. The full
rules are in [Scoping a prepare to part of an application](#scoping-a-prepare-to-part-of-an-application)
below.

### -VerboseLog

Writes a fuller log for this run, with passwords, keys and tokens masked.

### -Force

Skips the confirmation QOps asks before touching more than ten applications.

## Scoping a prepare to part of an application

`-Path` limits a prepare to the objects under one path, glob or single file inside the app's `-prj`
folder — `Dimensions`, `Sheets/<id>`, `Variables/v*`. Files outside the path are left exactly as they
are: a scoped prepare never prunes.

Most object kinds are stored as a folder named after the object's id, so `Sheets/<id>` names one
sheet. Variables, stories and snapshots are stored as a file instead, and either form names the
object: `Variables/Sales.yaml` and `Variables/Sales` both scope the run to that one variable.

The application's description and thumbnail live in `App.yaml`, outside every object folder, so a
scoped run does not touch them unless the scope names that file.

An empty folder outside the scope is left in place as well, including one left behind by an earlier
run: a scoped prepare changes nothing it was not pointed at.

Matching ignores case and accepts either slash. On QlikView the switch is refused with a message
rather than accepted and ignored.

## Fields that must not cause a rewrite

A prepare rewrites an object file only when the object itself differs. Some fields move on their own
without anything about the application changing — the version stamp QOps writes into each file is the
obvious one — and a file rewritten only because such a field moved shows up as a change in the
repository and conflicts on merge.

The version stamp is always treated this way and needs no configuration. To name further fields, add
`IgnoreFieldsOnCompare` to `.qopsconfig` with a list of field names:

```yaml
IgnoreFieldsOnCompare:
  - modifiedDate
  - publishTime
```

The names are matched anywhere in the object, at any depth. Listing a field here changes only whether
its value can *cause* a rewrite: when the file is rewritten for some other reason, the field is
written out with its current value as before.

## Incomplete project folders and parallel runs

Each run writes into its own temporary folder and removes only that folder when it finishes, also
when it fails. Two prepares of folders with the same name each get all their files. That happens, for
example, with the same app in two repositories, or with one prepare started from the Portal and one
from the console at the same time.

A project folder that is missing `App.yaml` (or `App.json`) or `Script.qvs` is written again in full
from the app by the next prepare of that app. The log shows a warning that names the missing files.

Prepare chooses the app by its own filter, not by the folder name. The folder is worked out from the
app. If the filter matches several apps with the same name, Prepare stops, unless you use
[-Force](#force).

## See also

- [QOps-Build](COMMAND-build.md) — the other direction
- [Commands](COMMANDS.md) — the whole command map
