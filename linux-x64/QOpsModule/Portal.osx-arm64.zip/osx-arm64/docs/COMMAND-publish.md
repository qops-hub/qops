# QOps-Publish

**What it does.** Puts an application in front of other people: into a stream on Qlik Sense, a space on Qlik Cloud. Nothing is read from the repository: publish works on what is already in Qlik.

**Direction.** Qlik only.

**In the Portal.** Operations → All commands → Publish, or `Ctrl+Shift+U` in the Operations panel.

## Publish or Release

- **Publish** takes an application that is already in Qlik and publishes it to its target.
- **[Release](COMMAND-release.md)** builds from the repository first and then publishes, in one run.

If you have just built, publish is the second half. If you have not, release does both.

## The four things a publish can do

Every publish does one of four things to the application you publish from (the *source*). Which one depends on the platform, on the kind of target and on whether the target already holds an application under the name you publish. What matters most about each is the application **Id**: links to the application, reload tasks and anything else that refers to it by Id keep working only while the Id stays the same.

- **Copy.** A new application is created in the target from the source, with a **new Id**. Used for a first publish to a Qlik Cloud managed space or a Qlik Sense stream.
- **Direct publish.** On Qlik Sense, the source itself becomes the published application and **keeps its Id**. Used only with [`-RemoveArtefacts`](#removeartefacts), for a first publish of a source that is not published yet.
- **Move.** The source itself moves into the target and **keeps its Id**. Used for a first publish to a Qlik Cloud shared space, which has no publishing of its own. The source leaves your personal space.
- **Replace.** The target already holds an application under that name. That application is updated from the source and **keeps its Id**, so no second one appears beside it. Needs `-Force`.

The [table at the end of this page](#application-id-after-a-publish) lists every case.

## Replace and -Force

When the target stream or space already holds an application under the name you publish, publish updates it only if you pass `-Force`. Without it, the run fails and says so, and nothing changes: a name already in use is usually the previous version of the same work, and overwriting it should not happen by accident.

With `-Force`, the application in the target is updated and keeps its Id:

- on Qlik Sense and on a Qlik Cloud managed space it is replaced with the content of the source;
- on a Qlik Cloud shared or personal space QOps reads the source and writes its content into the application in the space, which keeps its app Id, so links, schedules, subscriptions and bookmarks pointing at it stay valid. This carries the content, not the data: reload afterwards, or add `-Reload` to the same command.

[QOps-Release](COMMAND-release.md) follows the same rule for shared and personal spaces.

On Qlik Cloud managed spaces the published application takes its name from `-Filter` and its description from the source, on a first publish and on a replace.

On Qlik Sense `-Force` is also needed to publish a source that is already published in a stream. The source is then copied (see the table). On Qlik Cloud a source that is already published in a managed space cannot be published again, with or without `-Force`.

## -Filter: the source, the name and the target

`-Filter` is required, and it carries everything publish needs:

    QOps-Publish -Filter "Id=<source app id>,Name=<name to publish under>,Space=<target space>"

- **`Id=`** is the source application.
- **`Name=`** is the name the published application gets, and the name QOps looks for in the target to decide between a first publish and a replace.
- **`Stream=`** or **`Space=`** is the target. The two keys mean the same thing on both platforms. If it does not exist, QOps creates it: a stream on Qlik Sense, a shared space on Qlik Cloud.
- **`Owner=`** is optional: the published application is given to that user.

A filter missing `Id`, `Name` or the target is refused and the command says which one is empty. Several filters can be given, separated by `;`.

This command does **not** read the filter saved in the repository's `.qopsconfig`, and it does not take the target from the application's properties file. Running it with no `-Filter` publishes nothing and says so. [QOps-Build](COMMAND-build.md) and [QOps-Release](COMMAND-release.md) read the saved filter, and Release takes the target from the app file (see [Configuration](CONFIGURATION.md#the-publish-target-in-the-app-file)), because it publishes the application it has just built.

### Which Id to pass

A build records the application it wrote to on this machine in `App.local`, so that is normally the Id to publish.

After a first publish to a Qlik Cloud shared space the two part. That publish **moved** the application into the space. It is no longer in your personal space, so your next build creates a new application there, with a new Id, and records that Id in `App.local`. To publish what you built, pass the Id from `App.local`, with `-Force`: the application in the space is then updated from it and keeps its own Id.

    QOps-Publish -Filter "Id=<the Id in App.local>,Name=<app name>,Space=<space name>" -Force

If you pass the Id of the application that is already in the space while your personal space holds another one of that name, the run fails and the message names both Ids. If your personal space holds none, publishing it again changes nothing and succeeds, so a pipeline that re-publishes does not fail.

**In the Portal** the filter is built for you. By default it takes the Id from `App.local`, falling back to the Id in `App` when the folder records none. When the folder holds two different Qlik app Ids, the Publish confirmation adds an **App Id** choice next to the target space: **Local Id (App.local)** publishes the app your last build wrote to, **Id (App)** publishes the one committed to the repository, for example to move an already shared app into another space. The preview under it shows the resulting command before you confirm. See [Panels](PANELS.md).

## Flags

### -Force

Allows a [Replace](#replace-and-force): updates the application the target already holds under the name you publish. On Qlik Sense it also allows publishing a source that is already published.

### -RemoveArtefacts

When a publish involves a source application in its stream or space and a target application in the target stream or space, both applications stay after the publish without this switch. With it, the target application stays and the source application is removed.

In short, the switch removes the source, wherever it is. How that works out:

- **With a target**: Replace, then the source is removed.
- **Qlik Sense, no target, source not published yet**: Direct publish instead of Copy, so the source becomes the published application and keeps its Id.
- **Qlik Sense, no target, source already published**: Copy, then the source is removed.
- **Qlik Cloud managed space, no target**: Copy, then the source is removed.
- **Qlik Cloud shared space, no target**: Move. The source is the published application, so the switch changes nothing.

⚠️ The same switch means something different on [Release](COMMAND-release.md#removeartefacts), where it deletes files from the repository.

### -Reload

Reloads after publishing, and reloads the application that was actually published — which on a managed space is the copy in the space, not the one you published from. Publishing and then reloading by hand is the step where that distinction is easy to get wrong.

The reload runs the load script that is in the published application. Placeholders in that script were
filled in when the application was built, so a publish takes no placeholders: pass `-Placeholders` to
[QOps-Build](COMMAND-build.md) or [QOps-Release](COMMAND-release.md).

### -ServiceUrl

Not used by a publish, nor by the reload that `-Reload` runs after it. With `-ServiceUrl` the command
stops with an error before anything is published. To reload QlikView documents through a service, use
[QOps-Reload](COMMAND-reload.md) `-ServiceUrl`.

### -VerboseLog

Writes a fuller log for this run, with passwords, keys and tokens masked.

## See also

- [QOps-Release](COMMAND-release.md) — build and publish in one run
- [Commands](COMMANDS.md) — the whole command map

## Application Id after a publish

Every case, by target and source. *Target app exists* means the target already holds an application under the name you publish; those cases need `-Force`, as does publishing an already published source on Qlik Sense. On Qlik Cloud, *already published* means published to a managed space.

| Where | Target app exists | Source already published | Without -RemoveArtefacts | With -RemoveArtefacts |
|---|---|---|---|---|
| Qlik Sense stream | no | no | Copy: new Id; source stays | Direct publish: Id kept (the source is the published app) |
| Qlik Sense stream | no | yes | Copy: new Id; source stays | Copy: new Id; source removed |
| Qlik Sense stream | yes | no | Replace: target keeps its Id; source stays | Replace: target keeps its Id; source removed |
| Qlik Sense stream | yes | yes | Replace: target keeps its Id; source stays | Replace: target keeps its Id; source removed |
| Qlik Cloud managed space | no | no | Copy: new Id; source stays | Copy: new Id; source removed |
| Qlik Cloud managed space | yes | no | Replace: target keeps its Id; source stays | Replace: target keeps its Id; source removed |
| Qlik Cloud shared space | no | no | Move: Id kept (the source is the published app) | the same; the switch changes nothing |
| Qlik Cloud shared space | yes | no | Replace: target keeps its Id; source stays | Replace: target keeps its Id; source removed |
| Qlik Cloud, any space | any | yes | refused; nothing changes | refused; nothing changes |
