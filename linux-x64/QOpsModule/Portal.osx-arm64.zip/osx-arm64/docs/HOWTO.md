# How-to guides

Short pages, one per task. Each one says what the task achieves, when you need it, the commands to run
in order, how to check that it worked, and the mistakes people make with it. The command pages under
[Commands](COMMANDS.md) describe every switch; these pages put the commands together for one job.

## Applications and environments

| I want to | Page |
|---|---|
| understand which Qlik application a repository folder belongs to | [How does QOps know which Qlik application a repository folder belongs to?](HOWTO-app-identity.md) |
| work on a repository I just cloned, whose applications already exist on my environment | [Connect a freshly cloned repository to your Qlik environment](HOWTO-connect-cloned-repository.md) |
| bring the repository's applications to an environment where they do not exist yet | [Set up a repository's applications on another Qlik environment](HOWTO-set-up-another-environment.md) |
| make a new application from files in the repository | [Create a new Qlik application from the repository](HOWTO-create-new-application.md) |
| keep application folders in subfolders such as `apps/`, or move the configuration to the repository root | [Keep applications in subfolders with AppSubfolders](HOWTO-app-subfolders.md) |

## The model in one paragraph

Every application folder has two ids. The `Id` in the committed `App.yaml` (or `App.json`) is the
folder's identity inside the repository and can be any string. The `Id` in `App.local.yaml` binds the
folder to one application on the environment this checkout works with; that file is never committed,
so a fresh clone does not have it. A build writes `App.local` after every run, and
[QOps-SetLocalApp](COMMAND-setlocalapp.md) writes it when you bind a folder yourself. The full picture
is in [How does QOps know which Qlik application a repository folder belongs to?](HOWTO-app-identity.md)

## Qlik Sense and Qlik Cloud: the same idea under different names

The pages above apply to both platforms. Where they say "stream or space", this is what each word means.

| | Qlik Sense | Qlik Cloud |
|---|---|---|
| Where other people see a finished application | a **stream** | a **space**: a **shared** space or a **managed** space |
| Where an application lives while it is still yours | in no stream, owned by the account QOps connects as | in your **personal space**: in no space, owned by the account QOps connects as |
| Where a build creates a new application | there, unpublished | there, unpublished |
| What publishing does | [QOps-Publish](COMMAND-publish.md) moves the application into its target stream | into a **managed** space, the first publish of a name creates a new application with a new Id, and later ones (with `-Force`) update that application, which keeps its Id; into a **shared** space, the first publish moves the application itself, and later ones (with `-Force`) update the application already there in place. See [QOps-Publish](COMMAND-publish.md#the-four-things-a-publish-can-do) |
| Which applications a build writes into | an unpublished application owned by the account QOps connects as | an unpublished application in your personal space, owned by the account QOps connects as |
| Which ones it copies instead | a published application, or one owned by somebody else | the same, and every application in a shared or managed space |
| Why it copies | Building is the step you take while the work is still yours; putting it in front of other people is a separate, deliberate step, done by [QOps-Publish](COMMAND-publish.md) or [QOps-Release](COMMAND-release.md). A plain build makes its own copy and binds `App.local` to it; `-UpdateOnly` skips such a folder instead | the same. See [Shared and managed spaces on Qlik Cloud](COMMAND-build.md#shared-and-managed-spaces-on-qlik-cloud) |
| The target in the app file | `Stream` | `Space`. Both names carry one value; see [The publish target in the app file](CONFIGURATION.md#the-publish-target-in-the-app-file) |
| `App.yaml` and `App.local.yaml` | the committed `Id` names the folder, `App.local` binds it to an application on this environment | exactly the same |

## See also

- [Getting Started](GETTING-STARTED.md): a guided first run in the Portal
- [Commands](COMMANDS.md): every command, and which one to reach for
- [QOps-Build](COMMAND-build.md): including [-New](COMMAND-build.md#new) and
  [-UpdateOnly](COMMAND-build.md#updateonly)
