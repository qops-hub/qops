# QOps-SetLocalExtension

**What it does.** Tells the repository that an extension folder is called something else on **this**
environment. It writes a local properties file for that extension, inside the repository's
`Extensions` folder, carrying the target name; later builds use that name instead of the one the
folder was prepared with.

**Direction.** Repository only. Nothing in Qlik is contacted or changed.

**In the Portal.** On the **Operations** panel, under **All commands**, as **Set local extension**.

    QOps-SetLocalExtension -OriginExtensionName "sales-kpi" -TargetExtensionName "sales-kpi-test"

## If it finds nothing

The origin name is looked up among the extensions the repository holds. A name it cannot find is
reported (`Can't find extension ...`) and nothing is written. The target name is not checked against
the environment, so a typo there is written as typed.

## Flags

### -OriginExtensionName

The name of the extension as the repository has it now. Required.

### -TargetExtensionName

The name that extension has in the environment this repository is used with. Required.

### -Profile

Which configured authentication profile to use, when you run the command yourself. The Portal does
not offer it: the command runs in the repository, so it uses the repository profile, like Prepare and
Build do.

### -VerboseLog

Writes a fuller log for this run, with passwords, keys and tokens masked. Turn it on when you are going to send a log to somebody.

## See also

- [Extensions](COMMAND-extensions.md): the group this command belongs to, and how the commands fit together
- [Commands](COMMANDS.md): the whole command map
