# Changelog

What changed in QOps, written for the person using it. Each entry says what is different when you sit
down in front of the product, and carries its ticket so the detail is one click away.

Versions are ordered newest first. A version heading is `## <version> — <date>`, kept in that exact
shape so it can be parsed: the Portal will show a version's notes in-app rather than sending you to
the website.

This page carries the current release and the one before it. Everything earlier is in
[Earlier releases](CHANGELOG-ARCHIVE.md), in the same shape and linked version by version at the
bottom of this page.

---

## 3.1.2 — unreleased (staging)

### Get the latest build of your channel, and switch to it, from PowerShell and the Portal

`QOps-Update -IgnoreInstalledFromOtherChannels` installs the latest build of the update channel when it is not installed
yet, even when a newer build from another channel is installed, for example to go back to the release
build after trying a pre-release. It uses the channel this computer is set to, or the one given with `-Channel`
for this run only (`QOps-Update -Channel main-3.x -IgnoreInstalledFromOtherChannels`). The build goes into a folder of its own,
for both PowerShell editions; no PowerShell window is closed and no other version is removed. The new
folder is loaded once in a separate PowerShell before QOps switches to it, and removed again if it does
not load. QOps then stays on that build until you switch with `QOps-SetVersion`. When the build is
installed already, it says so and how to switch to it. It cannot be combined with `-Force`.

In the Portal, **Update to &lt;version&gt;** in the version panel now runs
`QOps-Update -IgnoreInstalledFromOtherChannels`, so it gets the latest build of the channel you chose.
**Check for updates** (and the check that follows a channel change in **Version settings**) answers in one
of two ways about that build when it is not the version the Portal runs:

- When the build is not installed: **You do not have the latest build from the &lt;channel&gt; channel**, with **Download &lt;version&gt;**:
  after a confirmation the update installs it and shows its progress, and the panel then offers
  **Restart on &lt;version&gt;** right away, also when that build is older than the one the Portal runs.
- When it is installed: **You already have the latest build from the &lt;channel&gt; channel**, with **Switch to &lt;version&gt;**:
  after a confirmation, which says when the build is older, the Portal switches to it.

Like the update, both are accepted only from the Portal's own computer and the addresses in
`Portal:AdminAllowedAddresses`.

`QOps-Update -CheckOnly` returns three more fields: `LatestInChannelInstalled` says whether the channel's
latest build is installed, `ChannelInstall` says what `-IgnoreInstalledFromOtherChannels` would do, and
`NewerFromChannelInstalled` says whether a newer build from the same channel is installed. When the
channel's latest build is missing and a plain `QOps-Update` would not install it, the printed line names
`QOps-Update -IgnoreInstalledFromOtherChannels`. See [-IgnoreInstalledFromOtherChannels](COMMAND-update.md#ignoreinstalledfromotherchannels) (QOPS-780).

### The AI assistant knows every chart setting it can change

Ask the AI assistant in the Portal how a chart type can be customised and it now answers with the full
list of settings for that chart, each explained in plain words: titles, subtitle and footnote, whether
titles, details and expressions are shown, the legend and its position, value labels, axis labels,
position, scale and range, grid lines, the scrollbar, missing values, the tooltip, colours and sorting,
and the chart's own options, such as stacked bars, donut pies, gauge ranges, treemap labels and pivot
rows. Fonts, font sizes, outlines, borders and shadows from the Styling panel are included too. The
assistant can apply any of them to a chart it has created, the same way you would set them in the
properties panel in Qlik (QOPS-786).

### Register a repository from your AI assistant

Ask an AI assistant connected to the QOps MCP server to register a repository folder, for example
"Register /workspaces/finance as a QOps repository", and it adds the folder to the same list of
repositories the Portal uses, without starting the Portal. The repository is then listed by the
assistant's repository tools and shown in the Portal. The rules are those of Add repository in the
Portal: the folder must exist on this machine and be given by its full path, an id you choose may contain
only letters, digits, `-`, `_` and `.`, and a folder or id that is already registered is refused, with the
answer naming the id the folder already has. The folder is registered as it is; nothing is created or
written in it. When no repository is registered yet, the
assistant's repository list now points at this instead of at the Portal.

A relative path such as `.` is now refused by Add repository in the Portal as well, because the Portal
and the MCP server each resolve it against a folder of their own. A new repository id with other
characters, such as `/` or a space, is refused in the Portal too; repositories already registered under
such an id keep working. An empty repository id is treated as no id, and a short id is generated. The
Portal and the assistant can register repositories at the same time without either registration being
lost (QOPS-791).

### The QOps-Setup installer installs for all users only, and shows both PowerShell folders

`QOps-setup.msi` now installs for all users of the machine only, and asks for administrator rights when
the installation starts, with no choice of who the installation is for. For a per-user install without
administrator rights, use `QOpsModule.msi`.

Its Destination Folder page is laid out like the one of `QOpsModule.msi`: an intro line, then the
Windows PowerShell 5.1 folder (`C:\Windows\System32\WindowsPowerShell\v1.0\Modules\QOpsModule`) and the
PowerShell 7 folder (`C:\Program Files\PowerShell\Modules\QOpsModule`) as plain text, with no input
field and no Change button.

Upgrading replaces an earlier QOps-Setup installed for all users. A QOps-Setup installed earlier with
Install just for you is not removed by the upgrade; remove it from Settings > Apps (QOPS-767).

### The Codespace repository is registered on its own

In a GitHub Codespace, `QOps-StartPortal` now makes the repository the Codespace was opened on ready to
use: the Portal registers the workspace folder, for example `/workspaces/finance`, under the repository's
name, so the Portal and the AI assistant's `list_repositories` show it without Add repository. A folder
that is already registered keeps its id, and starting the Portal again changes nothing. When your QOps
configuration has no `default` profile yet, an empty one is added, with no address, user or password, so
commands do not stop on a missing default profile; fill it in with your Qlik connection. Other profiles and
settings are kept, a configuration QOps cannot read is left alone, and nothing is written in the
repository folder. Outside a Codespace nothing changes (QOPS-792).

### The assistant sorts a chart's dimension the way Qlik does

Ask the assistant to sort the dimension of a bar, line or combo chart or of a table alphabetically,
numerically or by an expression, ascending or descending, and the chart is sorted the same way Qlik stores
it when you choose that sorting yourself: the dimension's sorting is switched from Auto to Custom in the
same change, so the chart settings show the sorting you asked for. Alphabetical and numeric sorting can
also be turned off on a bar chart, and alphabetical sorting on a table. Pie charts do not offer these
settings yet (QOPS-802).

### MCP: master items, variables and app lists answer with names first

`list_measures`, `list_dimensions` and `list_variables` now answer with the id and the name of each
item. The expressions, fields, definitions, descriptions and tags come back when the assistant asks
for them with `includeDetails`. Looking an item up by part of its name (`titleContains`,
`nameContains`) returns only the id and the name of each match, and so does `list_qlik_apps` when
it is given `nameContains`; with `includeDetails` it returns the full rows as before. Every page of
these lists also stays under about 27,600 characters: a page ends early and says there is more,
instead of returning a shortened text. Listing a large library of master items costs a few thousand
characters of the assistant's conversation, and it is faster, because the names come from one call. If you have scripts or prompts
that read expressions or definitions from these lists, add `includeDetails: true` (QOPS-834).

### Shorter first answers from the object tools in the MCP server

Reading a large object or application from an AI assistant no longer fills its context in one call. The defaults changed:

- `get_object` returns a summary of the object (type, title, dimensions, measures, sheet contents and the size of each property). `includeProperties` returns the whole definition, `includeLayout` the evaluated layout, and `path` one part of either, for example `/properties/qHyperCubeDef/qMeasures/0`. A part too big for one reply is listed with its parts and their sizes instead of being cut.
- `get_app_metadata` returns the counts and the sheet titles. `section` returns sheets, dimensions, measures, variables or master objects in full, a page at a time.
- `list_objects` returns 100 objects per page (was 200, at most 400 with `limit`, was 1000). `list_app_objects` is paged too: 100 per page, at most 200. Both give `nextOffset` for the next page.

If you have prompts or scripts that expect the full definition from `get_object` or the full application from `get_app_metadata`, add `includeProperties` or `section` (QOPS-835).

### AI assistant (MCP): data answers keep to a size the assistant can use

The analytic tools now keep their default answers under about 12,000 tokens, so one call no longer
fills the assistant's conversation with data. This changes what a call without a page size returns:

- `get_hypercube_data` returns up to 100 rows by default (it was 200), and `get_field_values` up to
  100 values. Both stop earlier when the rows or values are long, give the total and the offset of
  the next page, and add a short `note` saying the page was cut.
- A page size you pass yourself (`maxRows` up to 5,000, `maxValues` up to 1,000) is returned in full,
  as before.
- `get_current_selections` lists up to 20 selected fields by default (there was no limit). It gives
  the number of selected fields in total and `nextFieldOffset` to continue; the new `maxFields` and
  `fieldOffset` arguments page through the rest. `select_field_values` and `clear_selections` show
  the resulting selections the same way (QOPS-837).

### Lineage answers the assistant with a summary first

`get_lineage` answers with a summary instead of the whole lineage of a repository. By default it answers with a
summary: how many apps, sheets, charts, master items and data connections the repository has, which
apps and data connections they are, and how to ask for more. Ask about one app, sheet, chart or master
item (by its id or its exact name) to get what it depends on and what depends on it, two steps away by
default (`depth` sets how far, `direction` limits it to one side). The complete lineage is still
available with `full=true`, 50 items per page (`limit`, `offset`). Assistants or scripts that read the
whole graph from the default answer need to pass `full=true` and read every page. The lineage view in the
Portal is unchanged (QOPS-838).

### The qops MCP tools return a shorter output tail

`qops_prepare`, `qops_build`, `qops_publish` and `qops_reload` now return the last 60 lines of the
command output, at most 8,000 characters, and at most 50 per-app results (`appsTotal` gives the full
count). When the output is longer, the reply names the path of a file with the full output
(`fullOutputPath`). The file goes to the repository's `.mcp-files` folder, which ignores itself, so it
never shows up in your changes or commits. Nothing is lost, and the reply stays small enough for an
assistant to read in one go (QOPS-840).

### The AI assistant knows more chart settings

The list of chart settings the AI assistant in the Portal can explain and change has grown. From the
Data panel: the label of a dimension or measure, leaving out null or zero values, a condition for
showing a dimension or a measure, a calculation condition for the whole chart, number formatting,
limiting a dimension to a fixed number of values, alternative dimensions and measures, reference lines
and trend lines, and sorting by a measure (Custom, numeric ascending or off, alphabetical). From the
appearance settings: hiding the hover menu, colouring by measure or by expression with their colour
options (colour scheme, reversed colours, a custom range, whether the expression is a colour code,
12 or 100 colours and persistent colours when colouring by dimension), the legend position of a
treemap, a gauge limit that splits it into two bands, and the KPI link to a sheet and whether it opens
in a new tab. Straight tables gain the footnote, subtitle, titles, details and expressions settings,
totals (custom, position and label), pagination, the accessibility option, a hidden header and text
wrapping. Each setting is listed only for the chart types where it has been checked in Qlik, and the
assistant changes it the same way Qlik does when you set it in the properties panel (QOPS-842).

### Fixes

- **Chart property names the chart does not read are refused, with the right name suggested.** When the AI assistant creates a chart or changes an existing one, a property name the chart type is not known to read, such as `legend.position`, is refused before anything is written, and the answer names the closest known one (`legend.dock`). Properties the chart already has, removing a property, and objects that are not charts are not affected. `list_chart_customisations` lists the known settings for each chart type (QOPS-782, QOPS-789).

- **The version panel no longer shows a failed restart once the Portal has been started again.** A restart that did not take is shown under Updates while the Portal it tried to replace is still the one running. Once the Portal has been started again after that, for example with `QOps-StartPortal` or by restarting the computer, the failure is no longer shown. A restart in progress, and one that fails while you watch, are always shown (QOPS-785).

- **The version panel shows the QOps version the Portal runs.** With more than one QOps version installed,
  the version panel, the status bar and the What's new link show the version the Portal was started from,
  the same one Version settings marks as running (QOPS-788).

- **A chart setting with a fixed list of choices accepts only the values the chart reads.** When the AI assistant sets one, such as the labels of a pie chart, a value the chart does not take is refused before anything is written, and the answer names the value the chart takes (`value`, not `values`). This covers the fixed-choice settings of bar, line, combo, pie and scatter charts, whether the assistant creates the chart or changes an existing one. A value a chart already has is left alone, so a chart saved before can still be saved again (QOPS-790).

- **Switching to an older version says what you give up.** The confirmation says that features, bug fixes
  and settings added in newer versions are not available in the version you switch to (QOPS-794).

- **An expired licence key is reported as expired.** After QOps-SetLicense with an expired key, the next
  command says that the licence has expired, and a key that was refused once does not block activating a
  valid key afterwards (QOPS-713).

- **`QOps-Update -Force` installs into a version folder on Windows too.** The build goes into its own folder
  named after the version, as on Linux and macOS, records the channel it came from, shows as
  `VersionedFolder` in `QOps-Version -Installed`, and this PowerShell window switches to it without a
  restart. Open PowerShell windows stay open. Nothing is replaced until the new folder has loaded QOps;
  when it does not load, the versions you have stay as they are and the message says why. On Windows,
  a forced reinstall of the version the PowerShell window runs is kept ready beside it, and the next
  new PowerShell window puts it in place before it loads QOps; while another window or the Portal still
  uses that version, the version you had keeps working and the reinstall waits (QOPS-755).

- **Chart Styling settings the chart does not have are refused.** When the AI assistant creates or changes a chart, a Styling property that the chart type does not have for that part of the chart, such as a glow effect on the bars of a bar chart, is refused before anything is written, and the answer names the closest Styling property it does have. Styling the chart already has is left alone, and objects that are not charts are not affected (QOPS-796).

- **Pie chart labels show what the assistant set in one step.** When the assistant sets what the slice
  labels of a pie chart show (nothing, the share or the values), the value labels are switched to Custom in
  the same write, so the chart shows the chosen labels right away. A write that also asks to keep the value
  labels on Auto is refused before anything is written, and the answer says which setting to change (QOPS-797).

- **Treemap labels and the continuous X axis show what the assistant set in one step.** When the assistant
  turns the group headers or the box labels of a treemap on or off, the treemap labels are switched to Custom
  in the same write, and when it chooses whether a line or combo chart draws its X axis on a continuous scale,
  the X axis Continuous setting is switched to Custom with it, so the chart shows the change right away. A
  write that also asks to keep that setting on Auto is refused before anything is written, and the answer
  says which setting to change (QOPS-798).

- **Release sorts by `-Sort`, and parameters without effect are refused.** `QOps-Release -Sort` sets the
  order in which applications are built and published, as it does on `QOps-Build`. `-SkipCustomProperties`
  on `QOps-Build` and `QOps-Release`, and `-Ignore` given to `QOps-Release`, stop the command with an error
  that says the parameter has no effect for this command, before anything is changed; the Portal does not
  offer `-SkipCustomProperties` on Build and Release. `QOps-Build` has no `-ServiceUrl` parameter, and
  `QOps-Reload` and `QOps-Publish` have no `-Placeholders` parameter: both run the load script that is
  already in the application, where the build filled in the placeholders (QOPS-799).

- **A global configuration that cannot be read is kept when you save.** When
  `%USERPROFILE%\qopsconfig\.qopsconfig` exists but cannot be read, saving in Environment settings, adding a
  profile or removing one leaves the file as it is: the Portal refuses the change and shows a banner with its
  path and the reason. From there you can fix the file by hand, or choose **Back up and start fresh**: the file
  is kept as `.qopsconfig.broken-<date>-<time>` and a new, empty one is created. On the command line the same
  reset is `QOps-Configure -ResetGlobal`, and `QOps-Configure` stops before its first question when the file
  cannot be read. QOps and the Portal write the global file to a temporary file first and then put it in
  place, so an interrupted write leaves the previous file intact. On Windows, when another program holds the
  file open so it cannot be swapped, QOps writes it in place and logs a warning, so a save still succeeds
  while another QOps session is reading the file (QOPS-765).

- **A chart setting written onto a sheet is refused.** When the AI assistant changes a sheet with a property that sheets do not have, such as a glow effect meant for a chart on that sheet, nothing is written and the answer says the object is a sheet and names the charts placed on it, so the assistant can change the chart instead. Title, description, grid and the other sheet settings are written as before, and so is a property the sheet already has (QOPS-800).

- **Turning a chart sort option off passes the check after the write.** When the AI assistant turns a sort option off by setting it to 0, such as sorting by number next to a sort by text, the check after the write reports the change as passed. Qlik leaves such values out of the stored chart, and the check now treats them as written. A value other than 0, off or empty that is missing after the write is still reported (QOPS-801).

## 3.1.1 — 2026-10-23

### Version manager: installed versions, switching and the update channel

The version panel in the Portal has a **Version settings** window. It lists the QOps versions installed on
the computer, newest first, with the date each was built, which one is running, and a badge for where it
came from: green **Release**, amber for a staging channel with its name, grey for anything else (another
channel, MSI or PKG, or Unknown). A filter shows All, Release, Staging or Other. **Switch** on any complete
version restarts the Portal on it at the same address, and the Start menu and Desktop shortcuts start that
version from then on; it is greyed out, with the reason, while operations, an update or a restart run. See
[Version settings](USER-GUIDE.md#version-settings-the-installed-versions-and-switching-between-them).

The same window sets the **Update channel**: **Release** (recommended), **Staging**, or **Other** with a
channel name such as `staging-mcp`. A channel other than Release shows a warning that its builds are not
release-tested. After the change the Portal checks what the new channel offers and installs nothing. The
version panel has **Check for updates**, and shows **Update to &lt;version&gt;** only when the channel has a
newer build. See [Version settings: the update channel](USER-GUIDE.md#version-settings-the-update-channel).

Staying on an older version now lasts. After `QOps-SetVersion`, or `QOps-Update -Force` to an older build,
QOps stays on the version you chose until an update installs a newer one or you switch to the newest
installed version, and later updates compare the channel with the version you chose. `QOps-Update -Force`
asks you to close the Portal first when the Portal runs from a version it would replace. See
[Staying on an older version](USER-GUIDE.md#staying-on-an-older-version).

The same is available from PowerShell and the Portal API: `QOps-Update -CheckOnly` checks the channel
without installing and names the cause when the check fails (no network, GitHub's request limit, a rejected
token); `QOps-Version -Installed` lists the installed versions as objects with their origin;
`QOps-SetUpdateChannel -PassThru` returns the change as an object. The Portal API lists installed versions,
switches between them and sets the channel. See [QOps-Update](COMMAND-update.md#what-a-check-returns) and the
[API reference](API-v2-reference.md#installed-versions-and-the-update-channel).

Switching versions, changing the channel, updating, restarting and stopping the Portal are accepted from
the computer the Portal runs on and from the addresses listed in the new `Portal:AdminAllowedAddresses`
setting in `portal.settings.json`. Used at `http://localhost`, nothing changes; from any other address the
request is refused with `403` naming the setting, and the Version settings window is read-only. Behind a
reverse proxy on the same computer every caller looks local, so restrict these actions at the proxy. See
[Who may switch versions, update, restart or stop the Portal](API-v2-reference.md#who-may-switch-versions-update-restart-or-stop-the-portal)
(QOPS-710, QOPS-723, QOPS-745, QOPS-746, QOPS-747, QOPS-748, QOPS-749, QOPS-750, QOPS-756, QOPS-781).

If an installation is broken or removed, the installers for Windows, macOS and Linux are on the
[Installation](https://qops.datalabsua.com/documentation/installation/) page (QOPS-766).

### Smoother start in GitHub Codespaces

Licence activation in a GitHub Codespace works out of the box: it completes in the Codespace's home
folder, and it no longer needs a configured Qlik profile first. Configure your Qlik connection when you
are ready to work with it (QOPS-773, QOPS-783, QOPS-784).

### Git panel: a filterable list for many remote branches

With more than eight remote branches, the Branches card shows one button that opens a filterable list
instead of a chip per branch. Each row has Check out and Merge, and the list works from the keyboard
(QOPS-690).

### Fixes

- **Line endings follow one order in every command and in the Portal.** QOps uses the first that is set:
  `EOLStyle` in the repository's `.qopsconfig`, the global `EolStyle`, `eol=` in `.gitattributes`, Git's
  `core.autocrlf` or `core.eol`, then the system's line ending. With CRLF set, a file with mixed endings is
  written entirely in CRLF. If `EOLStyle` is set in neither configuration file, some files
  may now be written with different endings than before; set it to keep the endings you want
  (QOPS-434, QOPS-504, QOPS-505).

- **The Portal lists the same applications as QOps.** The application list and the screens built on it
  find applications the way Prepare and Build do: a folder with `App.yaml` or `App.json` directly inside
  the repository or inside a folder listed in `AppSubfolders`; the folder name no longer has to end in
  `-prj`. Spaces around `AppSubfolders` entries are ignored. See
  [Keep applications in subfolders](HOWTO-app-subfolders.md) (QOPS-758, QOPS-763).

- **Charts from the assistant get a title only when you ask for one, and combo chart lines get their own
  axis** unless your request puts them on the bars' axis (QOPS-743, QOPS-769).

- **Licence activation works in Docker containers on hosts with cgroup v2**, and the Portal and QOps
  commands in one container can check the licence back to back (QOPS-752, QOPS-753).

- **An expired licence is renewed whenever the licence service can be reached** (QOPS-778).

- **`QOps-Deactivate` says when there is nothing to deactivate** (QOPS-775).

- **Qlik Cloud connection errors say why the connection failed.** `Can't validate server` is followed by
  the HTTP status and, for a rejected API key, the setting that holds the key and the `QOps-SetConfig`
  command that stores a new one (QOPS-774).

- **Three switches stop the command where they do not apply**: `QOps-Release -ReloadBeforePublish` outside
  Qlik Cloud, `QOps-Publish -Placeholders` without `-Reload`, and `QOps-Publish -ServiceUrl`. On Qlik Cloud,
  `QOps-Release -ReloadBeforePublish` carries the reloaded data into an application already published in a
  managed space (QOPS-516).

- **Settings saved in the Portal's environment editor are read back reliably** when several screens read
  the configuration at the same time (QOPS-759).

## 3.1.0 — 2026-10-13

### QOps and your AI assistant: the QOps MCP server

QOps now includes an MCP server, so an AI assistant can work with your QOps repositories and Qlik
applications in plain language. It runs on your own machine, uses the connection profiles and licence
you already have, and never passes your Qlik credentials to the assistant. See
[AI Assistants (MCP)](MCP.md).

- Chat in the Portal. A Chat panel, opened from the Dashboard or docked beside the editor in Studio,
  talks to Claude or Gemini with the QOps tools and nothing to connect. Under **Settings → Global →
  Chat** you pick the provider and model and store your own API token, encrypted on this machine.
  Prompt caching is on by default, so long chats use fewer full-price tokens, and **Show token usage**
  adds a line with the tokens each answer used. The provider and model can also be changed for the
  chat you are in, from the provider's own model list.
- Your own assistant. Claude Desktop, Claude Code, Cursor and other MCP clients connect through a
  launcher that `QOps-StartPortal` writes to a fixed place, so the connection keeps working across
  updates.
- QOps operations. The assistant reads your repositories (apps, objects, lineage, load scripts) and
  runs Prepare, Build, Publish and Reload in a repository folder, exactly as the commands do.
- Qlik objects. It creates and changes sheets, charts, master items, variables and load scripts in a
  live application, with a read-only mode, a preview before a change, and one save for several
  changes. After each write it reads the result back and reports a broken expression, a chart that
  cannot draw, or a change that was not stored as sent. Charts cover bar, line, combo, pie, table,
  KPI, scatter, gauge, treemap and pivot table. A catalogue of chart settings lets it change legends,
  labels, axes, sorting, colours, combo series and donut or area styles exactly as Qlik does when you
  change them yourself. On Qlik Cloud it can make a sheet public with `publish_sheet`.
- The MCP-QOps licence. An MCP-QOps licence includes all of QOps and adds the analytic tools, which
  return the data in an application: values, calculated expressions and selections. With a QOps licence
  every other tool works and data values are left out. **Settings → Global → License** shows the
  licence tier. A tool call takes a licence slot only while it runs, so QOps commands can run while
  the assistant keeps an application open.

### Git panel: remote branches, fetch and a 3-way merge editor

The Branches card lists the branches of every remote. You can merge a remote branch into the current
one without switching, check one out as a tracking branch, and **Fetch** to see how far each branch is
behind. A conflicted file opens in a 3-way merge editor, with Current and Incoming side by side and an
editable Result, a choice to accept either side or both for each conflict, and Save marking the file
resolved and staged once no conflict is left.

### Release notes and updates from the Versions panel

The **Versions** panel, opened from the version badge, opens these notes at your installed version,
runs `QOps-Update` after you confirm, and restarts the Portal on the new version at the same address.
It shows the date and hour each Portal was built. `QOps-Update` can use your own GitHub token to stay
clear of GitHub's shared request limit, set with `QOps-SetConfig -GitHubToken` or in the Portal.
`QOps-SetVersion -RestartPortal` restarts a running Portal on the version you switch to, and the Portal
shortcut starts the version QOps last settled on.

### Building into new and existing applications

A folder with no `Id` is built into a new application, and the folder records it, so the next build
updates that application. `QOps-Build -UpdateOnly` builds only into applications that already exist on
the server you are connected to and never creates one, which is the safe first build after a fresh
clone. In the Portal it is **Update only** on Build.

### How-to guides in Help

The Help panel has **How-to Guides**: pages written around a task, such as connecting a fresh clone
to existing applications or setting the applications up on another environment, each with the commands
in order, how to check the result, and what to do when it did not work.

### QOps-Reload saves the task log to a file

On Qlik Sense, `QOps-Reload -LogPath` writes the full log of each task's last run to a file, and the
Portal's Reload status can download it.

### App files are written with only the Space key by default

A repository without a `StreamSerialization` setting now writes only the `Space` key into its app
files. Set `StreamSerialization: Both` to keep writing the older `Stream` key as well. Reading is
unchanged. See [The publish target in the app file](CONFIGURATION.md#the-publish-target-in-the-app-file).

### Fixes

- QOps-Release on Qlik Cloud publishes every sheet marked `Published: true`.
- QOps-Build on Qlik Sense saves again when the Engine reloads the application during the save.
- Uploads that Qlik Sense refuses because too many arrive at once are sent again.
- Publishing to a Qlik Cloud managed space keeps the application's description, and `-Sort Space` works on Qlik Cloud.
- Setting a new licence key works when a previous key is still activated, and on machines where the
  Windows user name differs from the profile folder name.
- QOps runs under PowerShell 7.4, and installing over an older version completes when the Portal was not stopped cleanly.

Work on the Portal and the MCP server continues, and more will come in the next releases.

---

## Earlier releases

Notes for the releases before the two above, newest first:

- [3.0.23 — 2026-10-08](CHANGELOG-ARCHIVE.md#3-0-23-2026-10-08)
- [3.0.22 — 2026-10-06](CHANGELOG-ARCHIVE.md#3-0-22-2026-10-06)
- [3.0.21 — 2026-09-25](CHANGELOG-ARCHIVE.md#3-0-21-2026-09-25)
- [3.0.20 — 2026-09-22](CHANGELOG-ARCHIVE.md#3-0-20-2026-09-22)
- [3.0.19 — 2026-09-18](CHANGELOG-ARCHIVE.md#3-0-19-2026-09-18)
- [3.0.18 — 2026-09-18](CHANGELOG-ARCHIVE.md#3-0-18-2026-09-18)
- [3.0.17 — 2026-09-17](CHANGELOG-ARCHIVE.md#3-0-17-2026-09-17)
- [3.0.16 — 2026-09-14](CHANGELOG-ARCHIVE.md#3-0-16-2026-09-14)
- [3.0.15 — 2026-09-11](CHANGELOG-ARCHIVE.md#3-0-15-2026-09-11)
- [3.0.14 — 2026-09-04](CHANGELOG-ARCHIVE.md#3-0-14-2026-09-04)
- [3.0.13 — 2026-08-24](CHANGELOG-ARCHIVE.md#3-0-13-2026-08-24)
- [3.0.12 — 2026-08-13](CHANGELOG-ARCHIVE.md#3-0-12-2026-08-13)
- [3.0.11 — 2026-08-07](CHANGELOG-ARCHIVE.md#3-0-11-2026-08-07)
- [3.0.10 — 2026-07-28](CHANGELOG-ARCHIVE.md#3-0-10-2026-07-28)
