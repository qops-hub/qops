# Changelog

What changed in QOps, written for the person using it. Each entry says what is different when you sit
down in front of the product.

Versions are ordered newest first. A version heading is `## <version> — <date>`, kept in that exact
shape so it can be parsed: the Portal will show a version's notes in-app rather than sending you to
the website.

This page carries the current release and the one before it. Everything earlier is in
[Earlier releases](CHANGELOG-ARCHIVE.md), in the same shape and linked version by version at the
bottom of this page.

---

## 3.1.4 — unreleased (staging)

### Fixes

- **Passwords, keys and tokens are masked in the detailed log written with `-VerboseLog`.** Request and
  response details stay in the log for troubleshooting, with credential values, including those inside
  connection strings, shown as `***` (QOPS-879).

- **A QOps MCP tool given a Qlik connection profile where it expects a repository, or the other way
  round, says which is which.** The answer names the tool that reads the other side, for example
  `get_object` for the live app instead of `describe_object` (QOPS-890).

- **AI assistant (MCP): replacing the sort of a chart dimension or measure replaces it.** When
  `apply_object_patches` replaces a dimension's or a measure's sort as a whole, every sort option the new
  sort does not name is turned off, so a chart reset to an earlier sort shows that sort and nothing of the
  one it had (QOPS-892).

- **On Qlik Cloud, commands work with apps created, copied, moved or deleted a moment earlier.**
  `QOps-Apps`, `QOps-SetAppOwner`, `QOps-Reload` (including `-Status` and `QOps-Publish -Reload`),
  `QOps-ExportQVF` and `QOps-RemoveApps` with `-Filter Id=...`, and `QOps-Build` and `QOps-Release` on the
  app recorded for the folder, work with that app right away, and an in-place `QOps-Publish` into a shared
  space updates the app the space holds. When `QOps-Publish` is about to refuse because of an app it sees
  in the target space or in your personal space, it checks the tenant again for up to 10 seconds and
  refuses only if the app is still there; a publish that is not refused does not wait. An app deleted a
  moment earlier that Qlik Cloud still lists is skipped with a line in the log by `QOps-Release` and
  `QOps-Publish` into a managed space and by `QOps-Prepare` (QOPS-898).

- **Two QOps runs on the same app take turns.** A build, Release or publish takes a write lease inside
  the app before it changes anything. A second run that reaches the same app waits for the first one to
  finish, up to 10 minutes, and names the run it waits for. A lease left by a run that stopped
  unexpectedly expires after 2 minutes. When a sheet is changed by another session during a build, for
  example by someone editing the app, the error names the sheet and the object and says to run the command
  again (QOPS-905).

- **`list_chart_customisations` tells the assistant to read the setting names first.** Its description
  says to call it with the chart type alone, which returns the valid setting names of that chart type.
  A name that does not exist gets a short answer listing every valid setting of that chart type
  (QOPS-874).

- **When a Portal MCP write refuses a property path, the refusal says which form the path takes.**
  `apply_object_patches`, `set_object_properties`, `create_object` and `add_chart_to_sheet` name the
  accepted form with one example, such as `/legend/dock`. A patch path that starts with `/properties`,
  the form `get_object` reads, is refused on every object type and the reply names the path to send
  (QOPS-875).

- **A build keeps every object on its sheet when the engine reports a change while the object is placed.**
  QOps finds the object by the id the engine gave it, places it when its cell is missing, and writes its
  position directly (QOPS-900).

- **A Qlik Cloud build or publish stops as soon as its engine connection drops.** The command says when
  the connection was lost, the last step it had started, and that the app may be partly updated, so it
  can be run again (QOPS-906).

- **An in-place `QOps-Publish` or `QOps-Release` on Qlik Cloud reports the app it was updating.** In
  every outcome the result row names the app the shared space holds, so a `Failed` row points at the app
  that may be partly updated (QOPS-907).

## 3.1.3 — 2026-11-04

### Commands and the Portal store saved credentials the same way on Linux and macOS; your licence serial is restricted to your account

Passwords, API keys, tokens and client secrets saved with [QOps-SetConfig](COMMAND-setconfig.md#which-of-the-two-configuration-commands-you-want), `QOps-Configure` or
`QOps-SetSensePassword`, or in the Portal's Environment settings, are encrypted the same way. Commands
such as `QOps-Apps` read the credentials saved in the Portal both inside a repository and from a folder
without a `.qopsconfig`, for example right after `QOps-StartPortal` in a GitHub Codespace. Values saved
with an earlier version are converted the next time QOps reads them inside a repository.

Your licence serial is readable only by your own account and the system account. QOps restricts the
`qopsconfig` folder, the `license.key` file, the `IPManager` activation folder and the activation files
in it to these two accounts: mode 600 for the file and 700 for the folders on Linux and macOS, and on
Windows an access list with inheritance disabled that holds only your account and the system account.
The restriction is applied when these are created and again on every write, so existing files and
folders are restricted the next time QOps writes them. If the permissions cannot be changed, QOps
carries on and the licence check is not affected.

### AI assistant (MCP): a shorter tool list, and smaller answers for chart settings, sheet lists and dry runs

The list of tools the assistant receives gives each tool a short description of what it does and when
to use it, so the list takes about a third of the room it took in the assistant's conversation. The
details of a tool (what each argument means, the accepted values, examples) come from the new
`describe_tool`, which the assistant calls for one tool when it needs them.

`list_chart_customisations` needs a chart type; without one, or with an unknown one, it answers with
the list of valid types. By default it returns the names of the settings for that type. Ask for up to
10 settings by name (`settings`) to get their description, current value and a ready patch. This keeps
each answer small enough for the assistant's conversation.

`list_sheets` answers with the id, title and object count of each sheet, 100 sheets to a page, and a
page stays under about 27,600 characters. The assistant finds a sheet by part of its title
(`titleContains`), or names sheets by id (`sheetIds`) to get only those, each with the id and type of
every object on it. When the full list is too large for one answer, it is also written once to a file
in the `.mcp-files` folder, and the answer gives its path.

`set_object_properties` and `apply_object_patches` with `dryRun` return the changed paths, each with its
old and new value, instead of the whole object before and after. Long values are shortened, and more
than 50 changed paths are cut with a note saying how many there are in total.

When such a dry run would change more than fits in one reply, the reply gives the counts per kind of
change and lists as many changed paths as fit, the paths that would be removed first. The full before
and after of every changed path is written once to a result file named in `fullResultPath`.

### AI assistant (MCP): chart sorting that Qlik applies

Ask the assistant to sort the dimension of a pie chart alphabetically, numerically or by an expression,
or to sort its measure numerically or alphabetically, and the chart is changed the same way Qlik stores
it when you choose that sorting yourself: the Sorting is switched from Auto to Custom in the same
change.

When `apply_object_patches` or `set_object_properties` writes the sort of a chart dimension or measure
while its Sorting stays on Auto, the change is refused before anything is written, a preview included,
and the answer says to switch that Sorting to Custom in the same change or to use the sort settings of
`list_chart_customisations`, which do both.

### Fixes

- **Activation and deactivation work when your Windows profile folder has a different name from your account.** For example, the account `jsmith` with the profile folder `C:\Users\John`. QOps keeps the activation files in your own roaming AppData folder (`IPManager`) and the file it reads them with in your `qopsconfig` folder, next to `license.key`. Files that an earlier version put in a folder named after the account are copied there once, on first use, and the existing activation keeps working. The originals stay where they were, so an earlier QOps version still finds them, and a later deactivation is not undone by copying them again. If a file exists in both places, the one in your profile is used and the other is left as it is. When QOps-Deactivate releases the licence but cannot remove a local file, it says so and names each file it left behind.

- **QOps-Push commits and pushes with the message, branch name, remote URL and folder exactly as written.** A commit message with spaces, quotes, semicolons, brackets, `$` or backticks is recorded word for word, and such characters in a branch name, URL or folder path are passed to git as plain text.

- **QOps-CleanSessions outside Qlik Sense says it works only with Qlik Sense.** In a Qlik Cloud profile, or in any mode other than Qlik Sense, the command says that cleaning sessions works only with Qlik Sense and does nothing.

## 3.1.2 — 2026-11-02

### Updates and version switching: the latest build of your channel, in both PowerShell editions

The version panel in the Portal works with the latest build of the update channel you chose. **Check for
updates** says either **You do not have the latest build from the &lt;channel&gt; channel**, with
**Download &lt;version&gt;**, or **You already have the latest build from the &lt;channel&gt; channel**, with
**Switch to &lt;version&gt;**. After a confirmation the Portal installs the build or switches to it, and
offers **Restart on &lt;version&gt;** right away, also when that build is older than the one the Portal runs.
A switch to an older version says that features, bug fixes and settings from newer versions are not
available in it. The panel, the status bar and the What's new link show the QOps version the Portal was
started from.

From PowerShell, `QOps-Update -IgnoreInstalledFromOtherChannels` installs the latest build of the channel
this computer is set to, or of the one given with `-Channel`, even when a newer build from another channel
is installed, for example to go back to the release build after trying a pre-release. `QOps-Update
-CheckOnly` reports whether that build is installed. See
[-IgnoreInstalledFromOtherChannels](COMMAND-update.md#ignoreinstalledfromotherchannels).

Every update goes into a folder of its own named after the version, on Windows as on Linux and macOS,
including `QOps-Update -Force`. No PowerShell window is closed and no other version is removed, and the
new folder is checked to load QOps before QOps switches to it.

`QOps-SetVersion`, `QOps-Update` and `QOps-Version -Installed` work with the module folder of the
PowerShell you run them in, so PowerShell 7 switches to the PowerShell 7 build. A Portal started from
Windows PowerShell 5.1 runs QOps commands in PowerShell 7 when it is installed, so `QOps-Prepare` on
Qlik Cloud works from such a Portal. `QOps-SetVersion` also switches the MCP server that assistants such
as Claude Desktop start; restart the assistant after switching. A Portal started from Windows PowerShell
on an earlier version updates and restarts into this version from the Portal. Leaving an earlier version
from the console still needs one PowerShell restart; every switch after that works.

### The QOps-Setup installer installs for all users

`QOps-setup.msi` installs for all users of the machine and asks for administrator rights when the
installation starts. Its Destination Folder page shows the Windows PowerShell 5.1 and PowerShell 7 module
folders. For a per-user install without administrator rights, use `QOpsModule.msi`. A QOps-Setup installed
earlier with Install just for you is not removed by the upgrade; remove it from Settings > Apps.

### GitHub Codespaces: the repository is ready when the Portal starts

In a GitHub Codespace, `QOps-StartPortal` registers the repository the Codespace was opened on, so the
Portal and the AI assistant list it without Add repository. When your QOps configuration has no `default`
profile yet, an empty one is added for you to fill in with your Qlik connection. Outside a Codespace
nothing changes.

### AI assistant (MCP): more chart settings, safer chart changes, shorter answers

- **More chart settings.** The assistant knows the full list of settings it can change for each chart
  type, explained in plain words: titles, legend, labels, axes, grid lines, colours, sorting, number
  formatting, reference and trend lines, conditions, alternative dimensions and measures, table totals and
  pagination, and the Styling panel. It sorts a chart's dimension and changes each setting the same way
  Qlik does when you set it in the properties panel.
- **Safer chart changes.** A property name, value or Styling setting the chart does not read, or a chart
  setting sent to a sheet, is refused before anything is written, and the answer names the right one.
  Settings behind an Auto switch, such as pie chart labels, are applied in one step.
- **Register a repository from the assistant.** Ask it to register a repository folder and it is added to
  the same list the Portal uses, under the same rules as Add repository in the Portal.
- **Answers that fit the assistant's conversation.** Master item, variable, object, application, lineage
  and data tools answer with a summary or a page first and give the rest on request, and the qops
  operation tools return the end of the command output. A complete answer that is too long for one reply
  is written to the repository's self-ignoring `.mcp-files` folder, where the assistant can search it.
  Prompts or scripts that read full details from these tools need `includeDetails`, `includeProperties`,
  `section` or `full=true`. See [AI Assistants (MCP)](MCP.md).

### Fixes

- **A global configuration that cannot be read is kept when you save.** The Portal refuses the change and
  shows the file's path and the reason, and offers **Back up and start fresh**; on the command line the
  same reset is `QOps-Configure -ResetGlobal`. The file is written to a temporary file first, so an
  interrupted write leaves the previous file intact.

- **`QOps-Release -Sort` sets the build and publish order, and parameters without effect are refused.**
  `-SkipCustomProperties` on `QOps-Build` and `QOps-Release`, and `-Ignore` on `QOps-Release`, stop the
  command before anything is changed. `QOps-Build` has no `-ServiceUrl` parameter, and `QOps-Reload` and
  `QOps-Publish` have no `-Placeholders` parameter.

- **QOps-Publish on Qlik Cloud publishes an app copied or imported a moment earlier**, and names an id
  that matches no app.

- **QOps-Prepare says when no app on the server matches the filter**, and names the server and how many
  apps it returned for the profile.

- **An expired licence key is reported as expired**, and a refused key does not block activating a valid
  one afterwards.

- **The version panel stops showing a failed restart once the Portal has been started again.**

- **Add repository in the Portal refuses a relative path and an id with characters other than letters,
  digits, `-`, `_` and `.`**; repositories already registered under such an id keep working.

---

## Earlier releases

Notes for the releases before the two above, newest first:

- [3.1.1 — 2026-10-23](CHANGELOG-ARCHIVE.md#3-1-1-2026-10-23)
- [3.1.0 — 2026-10-13](CHANGELOG-ARCHIVE.md#3-1-0-2026-10-13)
- [3.0.23 — 2026-10-08](CHANGELOG-ARCHIVE.md#3-0-23-2026-10-08)
- [3.0.22 — 2026-10-06](CHANGELOG-ARCHIVE.md#3-0-22-2026-10-06)
- [3.0.21 — 2026-09-25](CHANGELOG-ARCHIVE.md#3-0-21-2026-09-25)
- [3.0.20 — 2026-09-22](CHANGELOG-ARCHIVE.md#3-0-20-2026-09-22)
- [3.0.19 — 2026-09-18](CHANGELOG-ARCHIVE.md#3-0-19-2026-09-18)
- [3.0.18 — 2026-09-18](CHANGELOG-ARCHIVE.md#3-0-18-2026-09-18)
- [3.0.17 — 2026-09-17](CHANGELOG-ARCHIVE.md#3-0-17-2026-09-17)
- [3.0.16 — 2026-09-14](CHANGELOG-ARCHIVE.md#3-0-16-2026-09-14)
- [3.0.15 — 2026-09-11](CHANGELOG-ARCHIVE.md#3-0-15-2026-09-11)
- [3.0.14 — 2026-09-04](CHANGELOG-ARCHIVE.md#3-0-14-2026-09-04)
- [3.0.13 — 2026-08-24](CHANGELOG-ARCHIVE.md#3-0-13-2026-08-24)
- [3.0.12 — 2026-08-13](CHANGELOG-ARCHIVE.md#3-0-12-2026-08-13)
- [3.0.11 — 2026-08-07](CHANGELOG-ARCHIVE.md#3-0-11-2026-08-07)
- [3.0.10 — 2026-07-28](CHANGELOG-ARCHIVE.md#3-0-10-2026-07-28)
