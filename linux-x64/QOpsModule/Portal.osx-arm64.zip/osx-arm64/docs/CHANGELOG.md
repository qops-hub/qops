# Changelog

What changed in QOps, written for the person using it. Each entry says what is different when you sit
down in front of the product.

Versions are ordered newest first. A version heading is `## <version> — <date>`, kept in that exact
shape so it can be parsed: the Portal will show a version's notes in-app rather than sending you to
the website.

This page carries the current release and the one before it. Everything earlier is in
[Earlier releases](CHANGELOG-ARCHIVE.md), in the same shape and linked version by version at the
bottom of this page.

---

## 3.1.6 — unreleased (staging)

### AI assistant (MCP): line charts coloured by dimension, and the object border width on four more chart types

Ask the assistant to colour a line chart by dimension and it colours the lines the way the Qlik Cloud UI
does: with two dimensions, each value of the second dimension, the one the lines are split by, gets its
own colour; with one dimension, each of its values does. The assistant can also set the border width
around the object (Styling > General) on bar, combo, line and scatter charts, written as a CSS width such
as `2px` (QOPS-782).

### Studio: Qlik expressions in object files get highlighting and a formula editor

In a widget, measure, dimension or master object file, Studio colours each Qlik expression the way it
colours a load script, so functions, field names, strings and `$(variable)` expansions stand out inside the YAML
or JSON. Hover an expression and choose Formula editor, or right-click it and choose Open in Formula
Editor, to edit it in a large panel that opens over Studio.

Apply (or Ctrl+Enter) puts the expression back into the same value in the file's tab, with the quoting
and escaping the file already uses, and closes the panel. Cancel or Esc closes it without changes.
Applying does not write the file: the file's tab shows it has changes, the file is written when you save
that tab, and undo in that tab takes the change back out. If the value can no longer be found in the
file, nothing is applied and you are told why (QOPS-846).

### AI assistant (MCP): title, subtitle and footnote fonts, corner rounding and drop shadow on five more chart types

The assistant can now set more of Styling > General on bar, line, combo and scatter charts and on
treemaps: the title font, the subtitle and footnote font and font size, the corner rounding of the object
border (a CSS radius such as `6px`) and the drop shadow behind the object (the size name, such as
`Small`). Each chart type gets the options that were missing for it, written the way the Qlik Cloud
Styling panel writes them (QOPS-944).

### Licence checks report the installed QOps version

When QOps activates or checks a licence, it now also tells the licence service which version of QOps is
installed. Nothing changes in how licences are activated or checked (QOPS-824).

### Studio: arrange a sheet's widgets on its grid

Right-click a sheet in the Studio file tree and choose Open layout view to see the sheet's grid with each widget drawn on it. Click a widget to select it and click it again to deselect it. Only the selected widget moves and resizes: drag it to move it, or drag its edges and corners to resize it, and the arrow keys move it one cell (Shift with an arrow resizes it). Where two widgets touch, the edge you grab belongs to the selected one. Everything snaps to whole cells and stays inside the grid. A widget cannot be placed over another one: while a widget is dragged over another one, the line under the sheet title reads, in red, that the last action will not be saved because the widgets overlap, and names both widgets. The note goes away as soon as there is no conflict, and a drop over another widget is refused, so the widget goes back to where it was. The tab has Revert, Save and the usual unsaved-changes marker. Save changes only the position and size in the widget files that moved, and if a widget's file was changed outside Studio in the meantime, that widget is not saved and the message names it (QOPS-849).

### Send a support case from the Portal

**Help → Send support case**, also in the command palette, collects what QOps support needs from the
computer the Portal runs on, the same as `QOps-SendSupportCase`. Before anything is sent, the dialog shows every file in
the case, its size and how many values were masked in it. You can add what happened and an e-mail
address for the answer, both optional, then tick the box to agree and press **Send**. When the case is
received the dialog shows its number. When it cannot be sent, the dialog says why, and offers the zip as
a download and the technical support form to send it through. It works without a licence and without a
Qlik connection.

`QOps-SendSupportCase -CaseFile <zip>` sends a case written earlier with `-OutFile`, unchanged, which is
what the Portal uses to send exactly what it showed (QOPS-940).

### Fixes

- **On Qlik Cloud, `QOps-Build`, `QOps-Release` and `QOps-Publish` apply the app thumbnail from `App.yaml`
  to every app they write** (QOPS-156).

- **Commands keep running when the licence server is busy or briefly unavailable.** A gateway or overload
  answer from the licence server (502, 503, 504, 429, or 520 to 527) is treated the same as a server that
  cannot be reached: a valid licence on the machine is accepted and the command continues. A licence call
  that gets no answer gives up after 15 seconds. A licence the server refuses, for example an expired one,
  is still refused, and Community Edition and Codespace licences still need an answer from the server
  (QOPS-825).

- **Usages of a master dimension list only the objects that use that dimension.** Charts, filters and
  expressions that use its field directly are not counted in its "N uses" and are not listed there, so a
  master dimension that nothing uses is shown as unused. When the field has uses of its own, the Usages
  window offers "Usages of field <name>", which lists them together with other master dimensions built
  on the same field. A master dimension or measure used only inside a master visualization counts that
  visualization as a use (QOPS-934).

- **AI assistant (MCP): colouring a chart by dimension writes the full colour setting.** The colour mode
  entry in the chart settings catalogue shows a ready by-dimension example, on a line chart with two
  dimensions coloured by the second one as in Qlik Cloud, and names every property it writes. A raw edit
  that sets the colour mode to by dimension without the matching colour definition and colour field is
  refused before anything is written, with the complete edit to send instead (QOPS-945).

- **AI assistant (MCP): changing one Styling option keeps the other Styling options of the chart.** An
  edit that rewrites the whole list of Styling entries of a chart and leaves out entries the chart already
  has is refused before anything is written, naming the entries it would remove and how to change a
  single entry instead. Edits of one entry and edits that keep every entry are written as before
  (QOPS-946).

- **AI assistant (MCP): a chart dimension written as an expression without = is refused with the accepted form.**
  When a dimension such as `Month(OrderDate)` is not a field of the data model but is a valid expression,
  creating the chart is refused before anything is written, and the message names the accepted form
  `=Month(OrderDate)`. A field name that is simply missing from the data model is written and reported as
  before, and the warning about a missing field now names the = form when the name looks like an
  expression (QOPS-924).

- **QOps-Prepare with bookmarks no longer changes variable values for the user who runs it.** With
  `-IncludeBookmarks` or `-AllBookmarks`, the variables a bookmark carries keep their values in that user's
  later sessions of the app, for example in the Hub or the next QOps run (QOPS-951).

- **Qlik Sense: two runs on the same unpublished app are kept apart.** In an unpublished app the write
  lock is a private object, seen by every session of the app's owner and by administrators, so a second
  `QOps-Build` under the same account stops and names the run that holds the app. Published apps and Qlik
  Cloud keep the published lock (QOPS-969).

## 3.1.5 — 2026-11-18

### Prevent concurrent QOps writes to the same app and show who holds the lock
When another QOps run is already writing to the same app, `QOps-Build`, `QOps-Release`, and in-place `QOps-Publish` runs stop at once without changing it and report the user, machine, and start time of the active run — regardless of which account or machine started it. Pass `-WaitAndRewrite` to wait up to 10 minutes for the other run to finish before writing, or `-IgnoreWriteLease` to write immediately when you are sure the lock was left behind; both flags are also available under **Flags** in the Portal. A lock left behind by a run interrupted mid-write is treated as stale after 60 minutes (configurable via `WriteLockStaleMinutes`), after which the next run removes it and continues. While an app is reloading, QOps skips writing and reports it (or waits if `-WaitAndRewrite` is used).

## 3.1.4 — 2026-11-13

### Studio: .qvs files get proper syntax highlighting and breadcrumbs

A `.qvs` file opens in the Studio editor as a Qlik load script, with load-script syntax highlighting, `Ctrl+/` comments
and folding by `///$tab` section and block. As you type, Studio suggests load-script statements and
functions (`Ctrl+Space` to ask); a suggestion fills in the whole statement with placeholders, and `Tab`
moves between them. `Ctrl+Shift+O` lists the script's tabs with the subroutines and tables in each; pick one to
jump to it. A bar above the script shows where the cursor is, such as `Main › SUB LoadCalendar ›
Calendar`; click a part of it to jump to another tab, subroutine or table at that level.

### Studio: master item ids get inlay hints and link to the item's file

In an object file opened in Studio, an id such as `qLibraryId` shows the title of the object it points to,
for example `master measure: Total Sales`. Hover it for the description and file, Ctrl+Click to open that
file. A reference to a deleted master item shows `Object not found by ID`.

### Studio: rename an object or change its id from the file tree

Right-click a sheet, chart or master item in the Studio file tree and choose Rename or Change id. Change id
rewrites every reference to the object in the app, after a preview of every line that will change, and
writes all of it or nothing. The result stays in the working tree for you to review and commit.

### Operations panel: extensions, custom properties, tags and reload tasks

**All commands** on the Operations panel has groups for extensions, custom properties, tags and reload
tasks, so you can run Prepare and Build for them from the Portal without typing a command. **Dry Run** applies
to every command on the panel, including those that open a dialog, and every command uses the repository
profile.

### Lineage panel: master items, fields and variables, a compact layout and Isolate

The Lineage panel now draws lines from charts and master objects to the master items they use, and the
**Fields** toggle adds the app's fields and variables. **Compact** lays the graph out left to right, from
tables and fields to sheets, with no overlapping labels, and **Isolate** shows only one node's lineage. For
example, isolate a sheet of a large app to see just its charts, the master items they use and the fields
behind them, at full size.

### AI assistant (MCP): what uses a field or a master item, and where a field comes from

Ask the assistant "what uses the field `Target`?" or "where does `Region` come from?" and `get_lineage`
answers from a repository or from the live app in the engine. It lists the master items, charts and sheets
that read the field, through variables and master objects, and says the path to each chart in words. For
where a field comes from it gives the tables that load it and their data connection, from the load script
or the engine's lineage of the last reload, and names what in the script it could not follow instead of
guessing. When nothing is found to use a field, the answer says this does not prove the field is unused,
so the assistant does not advise removing it on that basis.

### AI assistant (MCP): labels for chart dimensions and measures

When the assistant creates a chart, it can give each dimension and measure its own label, so the table
header reads `Paywall shown` instead of `Count({<Event={paywall_shown}>} Event)`.

### Use the chat through a company LLM gateway

When the chat provider is Claude, **Settings → Global → Chat → Advanced settings** has an optional
**Base URL**. Enter the address of your company's gateway, and the chat goes through it instead of
`api.anthropic.com`. The gateway must accept Anthropic API requests; gateways that only offer the OpenAI
format are not supported, and the Gemini provider has no Base URL. Left empty, the chat works as before.

If Claude Code is already set up for the gateway, **Settings → Global → Chat → Advanced settings → Import
from Claude Code settings…** takes the same settings: the gateway address, the token, the default model and the model
list with its labels. It shows what will be set, with the token masked, before anything is saved.

### Send a support case from QOps in one command

[`QOps-SendSupportCase`](COMMAND-sendsupportcase.md) collects the logs and system details support needs,
masks passwords, tokens, connection strings and your licence serial, shows what it will send and asks
first, then prints the case number. It works without a licence and when the Portal is down; `-OutFile`
only writes the zip.

### Two QOps runs on the same app take turns

Before a Build or Release changes an app (on Qlik Cloud, also a Publish that updates an app in place), it places a small marker object in the app; the marker
is removed before the app is saved and never ends up in the repository. A second run on the same app, for
example a pipeline started while a colleague's Release is still going, waits for the first to finish and
names the run it waits for. After 10 minutes it stops with an error and changes nothing, so you can run it
again later. A running QOps renews its marker every 20 seconds; a marker that has not been renewed for 2
minutes, because its run crashed or lost the connection, is taken over.

### Fixes

- **On Qlik Cloud, commands work with an app right after it is created, copied or moved.**
  `QOps-Release`, `QOps-Publish` into a managed space and `QOps-Prepare` skip an app deleted a moment
  earlier that Qlik Cloud still lists, with a line in the log.
- **A Qlik Cloud Build or Publish that loses its engine connection stops at once** and names the app that
  may be partly updated, so it can be run again.
- **Concurrent `QOps-Prepare` runs on the same app from different repositories don't lose files.** If a
  project folder has lost `App.yaml` or `Script.qvs`, the next Prepare of that app writes the folder
  again from the app in Qlik and says in the log which files were missing.
- **A Build or Release keeps every object on its sheet and needs fewer calls to the Qlik engine**, which is
  most noticeable on Qlik Cloud and slow networks.
- **The Portal keeps logs for a support request**: earlier sessions as `portal.log.1` to `portal.log.5`, a
  log for every operation from the moment it starts, and the logs of failed command runs for 30 days.
- **The Portal closes operations it did not finish as interrupted**, and `QOps-StopPortal` shuts the
  Portal down the same way **Dashboard → Shut down Portal** does.
- **AI assistant (MCP):** reading master measures, master dimensions and variables is faster and does not
  hold up the next call; a call the engine does not answer in time closes its session, and the next call
  opens a new one.
- **AI assistant (MCP):** a refused chart write names the property path to send; replacing a chart's sort
  replaces it completely; a tool that works on repository files but was given a Qlik profile, or a
  live-app tool given a repository, says which kind of input it takes and names the tool to use instead.
- **Lineage links fields with an apostrophe in their name to their table.**

---

## Earlier releases

Notes for the releases before the two above, newest first:

- [3.1.3 — 2026-11-04](CHANGELOG-ARCHIVE.md#3-1-3-2026-11-04)
- [3.1.2 — 2026-11-02](CHANGELOG-ARCHIVE.md#3-1-2-2026-11-02)
- [3.1.1 — 2026-10-23](CHANGELOG-ARCHIVE.md#3-1-1-2026-10-23)
- [3.1.0 — 2026-10-13](CHANGELOG-ARCHIVE.md#3-1-0-2026-10-13)
- [3.0.23 — 2026-10-08](CHANGELOG-ARCHIVE.md#3-0-23-2026-10-08)
- [3.0.22 — 2026-10-06](CHANGELOG-ARCHIVE.md#3-0-22-2026-10-06)
- [3.0.21 — 2026-09-25](CHANGELOG-ARCHIVE.md#3-0-21-2026-09-25)
- [3.0.20 — 2026-09-22](CHANGELOG-ARCHIVE.md#3-0-20-2026-09-22)
- [3.0.19 — 2026-09-18](CHANGELOG-ARCHIVE.md#3-0-19-2026-09-18)
- [3.0.18 — 2026-09-18](CHANGELOG-ARCHIVE.md#3-0-18-2026-09-18)
- [3.0.17 — 2026-09-17](CHANGELOG-ARCHIVE.md#3-0-17-2026-09-17)
- [3.0.16 — 2026-09-14](CHANGELOG-ARCHIVE.md#3-0-16-2026-09-14)
- [3.0.15 — 2026-09-11](CHANGELOG-ARCHIVE.md#3-0-15-2026-09-11)
- [3.0.14 — 2026-09-04](CHANGELOG-ARCHIVE.md#3-0-14-2026-09-04)
- [3.0.13 — 2026-08-24](CHANGELOG-ARCHIVE.md#3-0-13-2026-08-24)
- [3.0.12 — 2026-08-13](CHANGELOG-ARCHIVE.md#3-0-12-2026-08-13)
- [3.0.11 — 2026-08-07](CHANGELOG-ARCHIVE.md#3-0-11-2026-08-07)
- [3.0.10 — 2026-07-28](CHANGELOG-ARCHIVE.md#3-0-10-2026-07-28)
