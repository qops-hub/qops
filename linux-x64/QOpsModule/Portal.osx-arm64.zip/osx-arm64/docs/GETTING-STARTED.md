# Getting Started in the QOps Portal

You have QOps installed and the Portal open in your browser. This page picks up from there and walks
you through your first real job: take a Qlik app under version control and publish a change through
it, all from the Portal.

If you have used `dbt` for data models, the idea is the same. Your BI app becomes source files in Git.
You Prepare it into files, edit those files, Build the app back, and Publish through review instead of
clicking around a live server.

## Before you start

You need four things. If any is missing, the [User Guide](USER-GUIDE.md) has the full prerequisites
with the commands to fix them.

1. **A QOps licence serial.** The Portal opens without one, so this is something you sort out from
   inside it rather than before you start: on a machine with no licence you land on the panel where
   the serial is entered, with Dashboard, Settings and Help available and everything else waiting.
   Put the serial in under **Settings → Global → License** and save it. That is the whole step —
   the machine activates itself the first time a command runs, so there is nothing else to do.
   **Activate** on that panel and `QOps-Activate` at a prompt do the same thing explicitly, which is
   what you want when you are re-activating or checking that it worked.
2. **A Qlik connection** — at least one `.qopsconfig` profile pointing at your target. You can browse
   the Portal without one; Prepare, Build, Publish and Release need it.
3. **Git installed.** The folder itself does not have to be a repository yet — the Git panel offers a
   **git init** button for a plain folder.
4. **A folder for your app sources.** Any local directory.

Quick sanity check: open `http://localhost:5555/api/v2/health` — or whatever URL `QOps-StartPortal` printed,
if you gave it a `-Port` or persisted one. Git, PowerShell and the QOps module should all read
`available`.

## 1. Add your repository

On the **Dashboard**, click **Add Repository** and enter the local path of your folder (for example
`C:\Projects\sales-analytics`). It shows up in the grid.

The Portal scans that folder for apps already decomposed into source (`*-prj/` directories). A fresh
repo shows none yet, which is fine.

Adding a repository registers a directory that **already exists on disk — it does not clone**. If your
repo lives on a remote, `git clone` it first, then add the local copy.

In a GitHub Codespace this step is done for you: when `QOps-StartPortal` runs there, the Portal registers
the Codespace's workspace folder (for example `/workspaces/finance`) under the repository's name. If your
QOps configuration has no `default` profile yet, an empty one is added; fill it in with your Qlik
connection before you work with Qlik, see the [User Guide](USER-GUIDE.md).

## 2. Get an app into the repository

Two different starting points, and picking the wrong one is the most common first stumble:

- **The app is not in this repository yet** → **Add App**, and give it the Qlik app id. This is what
  brings a new app in.
- **The app is already here** (a `<app>-prj/` folder exists, e.g. you cloned a repo a colleague set
  up) → **Prepare**, which refreshes those source files from Qlik.

Either way: click the repository card to open **Operations**, choose the target, and watch the live
output.

You end up with a `<app>-prj/` directory holding `App.json`, `Sheets/`, `Dimensions/`, `Measures/`,
`Variables/` and `LoadScript.qvs`. That is the reviewable, diffable source of your app.

## 3. Commit the source

Open the **Git** panel. The new files show up as changes. Type a message — or pick the **Prepare**
template — and click **Commit**. Your app is now under version control.

Get in this habit: commit after each meaningful step. Build, Diff and Release all need clean reference
points to compare against.

## 4. Edit, then Build

Open a source file from the left tree, from a node in the **Lineage** graph, or from a file in
**Studio**. It opens as a tab in Studio's editor. Make your change — a measure expression under
`Measures/`, say — and **Save** (`Ctrl+S`).

Then **Commit** in the Git panel and, in **Operations**, click **Build** (`Ctrl+Shift+B`). QOps
recomposes the app from the source files.

Editing in an external editor works just as well; commit from the Git panel the same way.

Two panels help you review before you ship:

- **Diff** shows exactly what changed — between two commits, or the working tree against a branch —
  file by file with line-level detail.
- **Lineage** draws the app's structure — sheets, the objects on them, and the master items and data
  connections belonging to the app — so you can see where the file you edited sits. To find out what
  *uses* a master item, use where-used in Studio rather than the graph.

## 5. Publish to Qlik

When the change looks right:

1. Check the **environment switcher** in the status bar at the bottom of the window points at the
   profile you mean — *Dev* rather than *Production*. The next publish uses that profile's credentials.
2. **Operations → All commands → Publish**, or press `Ctrl+Shift+U` in the Operations panel with the
   applications selected. Confirm the dialog, since this deploys.
3. Watch the logs. The app lands in the selected Qlik environment.

To cut a versioned snapshot, use **Release**.

## 6. The loop from here

Once you are set up, the day-to-day rhythm is short:

```
branch  ->  Prepare / edit  ->  commit  ->  Build  ->  Diff + Lineage review
        ->  Publish (Dev)   ->  merge   ->  Publish (Prod) / Release
```

A few habits that keep it clean:

- **One branch per change.** Keeps diffs and reviews focused.
- **Commit templates** for a consistent history.
- **Promote by switching environments**, not by building differently. Point the environment switcher
  at the next profile and re-publish the same build.
- **Dry Run** when you are unsure what a filter or flag will do. It prints the exact command and calls
  nothing.
- **Automate later** with the webhook endpoint: a CI job can `POST /api/v2/webhooks` with
  `event: "deploy"` or `"release"` to drive Publish and Release headlessly. Run
  `QOps-SetWebhookSecret` once on the Portal machine and send the value it prints in the
  `X-Webhook-Secret` header — without it the endpoint answers `401`. See the
  [API Reference](API-v2-reference.md).

## Where to go next

- [Panels](PANELS.md) — what every panel is for, and the complete keyboard shortcuts. Read this one
  next; most "can the Portal do X" questions are answered there.
- [User Guide](USER-GUIDE.md) — architecture, the environment switcher, how long operations behave,
  the security model, what is stored on disk, and troubleshooting.
- [API Reference](API-v2-reference.md) — scripting and integrating the Portal.
