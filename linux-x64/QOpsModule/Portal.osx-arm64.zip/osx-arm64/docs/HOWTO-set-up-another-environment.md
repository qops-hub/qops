# Set up a repository's applications on another Qlik environment

**Goal:** create the applications a repository holds on a Qlik environment where they do not exist yet,
such as a new test server or a new Qlik Cloud tenant, without writing into any application that is
already there.

This page applies to Qlik Sense and Qlik Cloud.

## When you need this

- You are bringing the repository's applications to an environment for the first time.
- Some of them may already exist there, and those must not be touched.

If all the applications already exist on the environment and you only need your checkout to find them,
you want [Connect a freshly cloned repository to your Qlik environment](HOWTO-connect-cloned-repository.md)
instead.

## What changes and what stays

The committed `Id` in each `App.yaml` stays exactly as it is, whether it is a Qlik id, a folder name or
a name you chose. What is new is the binding: the build writes each folder's `App.local.yaml` with the
Qlik id of the application it created on this environment. The model is explained in
[How does QOps know which Qlik application a repository folder belongs to?](HOWTO-app-identity.md)

## Before you start

QOps has a connection profile for the new environment and it is the one in use. In the Portal, check
the environment switcher in the status bar at the bottom of the window. See
[Before you start](GETTING-STARTED.md#before-you-start).

## Steps

### 1. Use a checkout for this environment

Clone the repository into its own folder for this environment:

```powershell
git clone <repository url> C:\Repos\sales-test
```

A checkout holds one binding per folder, in `App.local.yaml`. A checkout already bound to another
environment would have its bindings replaced by the build below, and would then point at the new
environment.

### 2. Create the applications that are missing

From the root of that checkout:

```powershell
QOps-Build -New
```

`-New` builds only the applications that do not exist yet on this environment:

- A folder whose id matches nothing on this server gets a new application.
- A folder whose id already resolves to an application here is **skipped**, with the line
  `'<name>' was skipped: it already exists on the server, and -New only creates. Run the build without -New to update it.`
  So `-New` never writes into an application that is already there.

Add `-Filter` to create only some of them, for example `QOps-Build -New -Filter "Name=Sales*"`. See
[-New](COMMAND-build.md#new).

In the Portal: **Operations → Flags / Options**, set **Operation** to Build, switch on
**New (only apps not created yet)**, then press **Build**. To create only some of the applications,
select them in the panel instead of typing a filter.

### 3. Commit any Id the build added

A folder whose committed `Id` was empty gets the folder name as its `Id`. Commit that change to
`App.yaml` so every other checkout sees the same identity. Folders that already had an `Id` are not
changed.

### 4. Publish

New applications are created unpublished in the personal area of the account QOps connects as: on
Qlik Sense in no stream, on Qlik Cloud in your personal space. Move them to their stream or space with
[QOps-Publish](COMMAND-publish.md), or build and publish in one run with
[QOps-Release](COMMAND-release.md).

In the Portal: **Operations → Release**, or **Operations → All commands → Publish** for applications
you have already built. Both ask for confirmation and name the target first.

## How to check it worked

- The build log shows `Created new app: <name>(<id>)` for each application that was missing, and a
  `was skipped` line for each one that already existed.
- Every application folder has an `App.local.yaml` whose `Id` is the new application on this
  environment.
- Running `QOps-Build -New` a second time creates nothing: every folder now resolves, so every folder is
  skipped.
- `git status` shows `App.yaml` changes only for folders that had no `Id`.

## If it did not work

These are the lines QOps prints when this task goes wrong, as they appear in the output.

**A folder was skipped although you expected a new application.** `-New` found an application for that
folder on this environment and left it alone:

```text
'<name>' was skipped: it already exists on the server, and -New only creates. Run the build without -New to update it.
```

If that application really is the same one, nothing is wrong: it was already there. If it is not, the
folder's id happens to match an application on this environment; see the second item under
[Common mistakes](#common-mistakes).

**The build refused to start.** `-New` and `-UpdateOnly` were given together, and the command stops
before it does any work:

```text
-New and -UpdateOnly cannot be used together: -New builds only the apps that do not exist yet, -UpdateOnly only the ones that do. Use one of them.
```

Run `QOps-Build -New` alone for this task. In the Portal the two switches cannot both be on: switching
one on switches the other off.

## Common mistakes

- **Using a plain `QOps-Build` when some applications already exist.** Without `-New` the build also
  writes into every application that resolves. Use `-New` when the ones already there must stay
  untouched.
- **Committed Ids that are Qlik ids which also exist on the new environment.** This happens when the
  environment was restored or migrated with application ids preserved. Such a folder resolves, so
  `-New` skips it and a plain build writes into it. That is right when it really is the same
  application; if it is not, bind the folder to the application you mean with
  [QOps-SetLocalApp](COMMAND-setlocalapp.md) first.
- **Running it from a checkout bound to another environment.** The bindings for the other environment
  are replaced. Keep one checkout per environment.
- **Expecting the new applications to be published.** A build never publishes. See step 4.
- **Using `-New` together with `-UpdateOnly`.** The command refuses the pair: one builds only the
  applications that do not exist yet, the other only the ones that do.

**Next:** anyone else who works against this environment clones the repository and binds each folder
to an application on it, as described in
[Connect a freshly cloned repository to your Qlik environment](HOWTO-connect-cloned-repository.md).

## See also

- [How does QOps know which Qlik application a repository folder belongs to?](HOWTO-app-identity.md)
- [QOps-Build: -New](COMMAND-build.md#new)
- [Shared and managed spaces on Qlik Cloud](COMMAND-build.md#shared-and-managed-spaces-on-qlik-cloud)
- [How-to guides](HOWTO.md)
