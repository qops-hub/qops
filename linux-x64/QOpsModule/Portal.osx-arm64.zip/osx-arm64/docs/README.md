# QOps Portal — Documentation

User- and developer-facing documentation for the QOps Portal.

## Install a ready-built Portal

If you downloaded a ready-built release from the repository rather than building it yourself - get the module onto the machine one of two ways:

- **MSI installer** — run the `QOps-Setup` MSI. It installs the QOps module (Portal included) for
  you.
- **Archive** — unpack the release archive into one of your PowerShell module directories (a path
  from `$env:PSModulePath`, e.g. `Documents\PowerShell\Modules\QOps`), so that `Import-Module QOps`
  resolves it. The Portal ships inside the module's `Portal/` folder.

Then start and stop it from PowerShell:

```powershell
QOps-StartPortal                 # port 5555, or the one set in portal.settings.json; -NoBrowser to skip the browser
QOps-StartPortal -Port 8080      # a different port, this start only
QOps-StopPortal                  # stop it (or Dashboard -> Shut down Portal, in the browser)
```

To make a port permanent, put `{"Portal": {"Port": 8080}}` in
`%USERPROFILE%\qopsconfig\portal.settings.json` — see
[Keeping a different port](USER-GUIDE.md#keeping-a-different-port). `-Port` still wins when given.

`QOps-StartPortal` opens the Portal in your browser. If you want to build the Portal from source
instead, see [`../README.md`](../README.md).



| Doc | Audience | Read it for |
|-----|----------|-------------|
| [GETTING-STARTED.md](GETTING-STARTED.md) | Analytics engineers | A guided first run from inside the Portal: add a repo → get an app in → commit → edit → Build → Diff/Lineage review → Publish, plus the branch/promote rhythm that follows. |
| [PANELS.md](PANELS.md) | Everyone | The map: what each panel is for, what it needs, how to reach it, and the complete keyboard shortcuts. The answer to most "can the Portal do X" questions. |
| [USER-GUIDE.md](USER-GUIDE.md) | Everyone | The reference: architecture, the environment switcher, how long-running operations behave, the security model, what is stored where, troubleshooting. |
| [HOWTO.md](HOWTO.md) | Everyone | Task pages, one per job: the goal, when you need it, the commands in order, how to check it worked, and the usual mistakes. Starts with how a repository folder finds its Qlik application, connecting a fresh clone, setting applications up on another environment, and creating a new application. |
| [API-v2-reference.md](API-v2-reference.md) | Integrators / automation | The REST calling guide — base URL, conventions, the RFC 7807 error model, pagination, realtime (SignalR/SSE), worked examples, and the CI webhook with its shared secret. |
| [CONFIGURATION.md](CONFIGURATION.md) | Everyone | Every field a repository's and the global configuration file has, what it means, and the command that writes it. |
| [COMMANDS.md](COMMANDS.md) | Everyone | The command map: what each command does, which one to reach for when two of them sound alike, and a page per command with a section for every switch. |
| [MCP.md](MCP.md) | Everyone using an AI assistant | Connecting Claude Desktop, Claude Code, Cursor or another MCP client to QOps: what you can ask it to do, setting it up, its options, working safely with live applications, and troubleshooting. |
| [CHANGELOG.md](CHANGELOG.md) | Everyone | What changed in each release, written for the person using the product. |

These are what the Portal's **Help** panel LISTS, in this order; this README is not one of them.
Each page owns its material rather than repeating a neighbour's, and cross-references between them are
clickable inside the panel.

`COMMAND-*.md` are the per-command reference pages. They are served — the panel opens them, and links
into them work — but they are deliberately absent from the Help menu, which would otherwise be a list
of commands rather than a list of manuals. They are reached from `COMMANDS.md`, from the ⓘ beside
Flags / Options in the Operations panel, and from links in the release notes. Adding one is a matter
of the file name: the `COMMAND-` prefix is what keeps it out of the menu.

`HOWTO-*.md` are the task pages. Like the command pages they are served but kept out of the Help
menu; they are reached from `HOWTO.md`, which is in the menu. The `HOWTO-` prefix is what keeps a page
out of the menu, and the title of each page is phrased as the question or task a reader would search
for, so the pages also stand on their own when published outside the Portal.

`changelog.d/` holds the release notes of changes merged since the last daily assembly, one file per
ticket; they are not served. How to write one is in [its README](changelog.d/README.md).

The **authoritative, always-current** route catalogue lives in [`../portal-api/API.md`](../portal-api/API.md)
and the live Swagger UI at `http://localhost:<port>/swagger`. The API reference above is the
companion "how to call it" guide, not a second copy of the route table.
