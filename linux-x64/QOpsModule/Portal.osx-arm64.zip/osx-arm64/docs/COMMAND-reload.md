# QOps-Reload

**What it does.** Reloads an application's data in Qlik. Nothing is read from or written to the
repository — this is the command that makes an application's figures current.

**Direction.** Qlik only.

**In the Portal.** Operations → All commands → Reload. The status query is its own command,
Operations → All commands → Reload status, and not a flag on Reload — see [-Status](#status). Its
flags, such as `-Wait`, are under Flags / Options.

## What it does not do

A reload does not build. If you changed the script in the repository and want the application to run
the new script, [build](COMMAND-build.md) first, then reload — or build with `-Reload`, which does
both in one run.

## Flags

### -Filter

Which applications to act on. The same filter grammar the rest of QOps uses: `name=`, `id=`, `*` and
`?` as wildcards, and `;` between clauses when you want several.

    -Filter "name=Sales Dashboard"
    -Filter "name=Sales*;name=HR*"

In the Portal the Reload button builds this for you out of the applications you selected, by the Id
in `App`. When an application folder holds a different Qlik app Id in `App.local`, the Reload
confirmation lets you choose which one to reload: **Id (App)** (the default) or **Local Id
(App.local)**. The preview shows the Id that will be used. The
**Reload status** button asks for it, and asks for it as a *required* field: an empty filter means
every application in the environment, which is a harmless answer to a question nobody asked.

### -Wait

Waits for the reload to finish and reports its outcome, instead of returning once Qlik has accepted
the request. Anything that has to know whether the reload succeeded — a pipeline, a chained step —
needs it.

### -Timeout

How many seconds to wait before QOps stops waiting. Qlik Sense and Qlik Cloud.

**No flag, no limit. Flag, limit.** Leaving `-Timeout` off changes nothing at all, so every command
that worked yesterday waits exactly as long as it did. On Qlik Cloud it also wins over
`ReloadTimeoutSeconds` in the configuration file, which in turn wins over the built-in ten minutes,
so the file can carry what suits most of your applications while one command makes room for the one
that takes longer.

**In the Portal.** Operations → Flags / Options, **Operation** Reload → *Stop waiting after (s)*, then
run it from Operations → All commands → Reload. Leave it empty
for no limit. The Portal also stretches its own run ceiling to cover the wait you ask for, so a value
larger than its usual allowance is honoured rather than cut short.

It bounds how long QOps WATCHES, not how long the reload may take. When it runs out nothing is
cancelled — the reload carries on in Qlik and usually finishes. The run says so and names what was
still running, so a reload you stopped waiting for can be told apart from one that failed, and on
Qlik Cloud you can ask about it afterwards with `-Status`.

On Qlik Cloud such a run reports the application as **Unfinished**. That is deliberately neither
*Done* nor *Failed*: the reload did not fail, and it has not been confirmed either. Anything that
checks outcomes — a pipeline step, the Portal's own run status — treats *Unfinished* as not successful,
because the honest answer at that moment is "not known yet". If you want a reload you never wait for,
use `-Detached`, which is the flag that means exactly that.

It applies wherever QOps polls for the answer, which on both platforms means `-Detached -Wait` and
`-Status -Wait`, and on Qlik Cloud the plain attached reload as well.

The one place it does not reach is a plain attached reload on **Qlik Sense**: that one is handled by
the Qlik engine in a single call which QOps waits out rather than polls, so there is no loop to
bound. The engine's own hour-long ceiling still applies there.

### -Attached

Runs the reload through the QOps session. This is what happens when neither switch is given; naming it
explicitly states the choice. If `-Attached` and `-Detached` are both set, the detached one is dropped.

### -Detached

Hands the reload to Qlik and returns without waiting for it, reporting one row per application: the id
of the reload that was started, the application's name, and the state that reload is in. Add `-Wait`
to hold until every one of them finishes instead.

Qlik Sense and Qlik Cloud. Against QlikView the run reports that detached reloads are not supported
and stops.

### -Status

Reports the most recent reload of every application the filter selects, and starts nothing. This is
the other half of `-Detached`: start the reloads in one run, ask how they went in a later one.

Qlik Sense and Qlik Cloud. Against QlikView the run reports that the status query is not supported.

The states are the same on both platforms:

| State | Meaning |
|-------|---------|
| `Queued` | accepted, not started yet |
| `Started` | running |
| `FinishedSuccess` | finished, data updated |
| `FinishedFail` | finished, the script failed — `-ShowLogs` says why |
| `Aborting`, `Aborted` | being cancelled, cancelled |
| `NeverStarted` | this application has no reload to report |
| `Error` | the reload ended in a state QOps does not recognise |

### -ShowLogs

Brings back the last N lines of the reload log, where N is the number you give. `-ShowLogs 200`
returns two hundred lines; `0` is off. It returns the log of the reloads that failed.

**On Qlik Sense it needs `-Wait`.** There the log is fetched only on a run that waited for the reload
to finish, so `-ShowLogs` on its own returns nothing and looks like an empty log rather than a switch
that did not apply.

**On Qlik Cloud it does not.** The log comes back with the status, so `QOps-Reload -Status -ShowLogs
200` returns the log of the last reload that failed without reloading anything.

### -LogPath

Saves the full log of each task's last run to a file in the folder you give, for example `QOps-Reload -Status -LogPath C:\logs`. The folder is created if it does not exist, and a relative path is taken from the current PowerShell location. Each file is named after the task with the date and time added, so later runs do not overwrite earlier files. The path of the saved file comes back in the `LogFile` field of the result.

`-LogPath` does not need `-ShowLogs`: `-ShowLogs` controls how many lines come back in the result, `-LogPath` keeps the whole log on disk.

The log belongs to a Qlik Sense reload task, so use `-LogPath` with `-Status`, or with `-Detached -Wait` so the saved log is the one of the run that has just finished. A reload without `-Status`, `-Detached` or `-Attached` runs in the QOps session and has no task log: QOps says so in the log, saves no file and still returns the reload results.

If the file cannot be written, the reload is not marked as failed: the reason is written to the log and `LogFile` stays empty.

In the Portal the log file comes to you as a browser download: use **Reload status** with **Download the full task log** turned on. See [Reload status](COMMAND-reload-status.md).

**Qlik Sense only.** On Qlik Cloud and QlikView no file is written and QOps says so in the log.

### -Profile

Which configured authentication profile to use, when the repository has more than one. The same
switch as on every other command.

### -VerboseLog

Writes a fuller log for this run. This is QOps' own log — a different thing from `-ShowLogs`, which
returns Qlik's reload log.

### -Force

Skips the confirmation QOps asks before touching more than ten applications.

## See also

- [QOps-Build](COMMAND-build.md) — `-Reload` there does a build and a reload in one run
- [Commands](COMMANDS.md) — the whole command map
