# QOps-Reload -Status

**What it does.** Reports what an application's last reload did — queued, running, finished, failed —
and starts nothing. It is the same cmdlet as [reload](COMMAND-reload.md) with `-Status`, which replaces
the reload rather than modifying it.

**Direction.** Qlik only. Qlik Sense and Qlik Cloud both answer. Against QlikView the run reports that
the status query is not supported and stops.

**In the Portal.** Operations → All commands → Reload status. It asks about the applications you have
selected, the same way Reload does.

## What it does not do

It does not start a reload, and it cannot be made to. Asking while a reload is still running is the
normal case rather than a conflict — that is the question this command exists for.

It does not report history. The answer is the state of the LAST reload of each application, not a list
of previous ones.

## Why it is a separate button

A reload started without waiting hands back a reload id and returns immediately. That id is the one
this command answers about, so a pipeline can start a reload in one run and ask about it in a later
one.

It is not an option on Reload because it starts nothing: asking never waits for a running reload and
never delays one, and a question can never be mistaken for a run that changed your data.

## Flags

### -Wait

Holds until the reload being asked about reaches a terminal state, instead of reporting whatever state
it is in at the moment you ask. Without it the answer is immediate and may well be `Queued` or
`Started`.

### -ShowLogs

Returns the tail of the reload's script log, as a number of lines.

    -ShowLogs 200

Only a FAILED reload has a log to show — after a successful reload there is deliberately none.

On Qlik Cloud the log arrives together with the status, so this works on its own. On Qlik Sense the log
is fetched separately and needs `-Wait`.

### -LogPath

Saves the full log of each task's last run to a file, for example `QOps-Reload -Status -LogPath C:\logs`. Each file is named after the task with the date and time added, and its path comes back in the `LogFile` field of the result. Qlik Sense only: on Qlik Cloud and QlikView no file is written and the run says so.

In the Portal you do not choose a folder. Turn on **Download the full task log** under Flags / Options for Reload status and run it. When the run finishes, each saved log is listed under **Task logs** in the result with a download link, and your browser saves it the way it saves any download: it asks where to put the file, or puts it in your downloads folder, depending on your browser settings.

The Portal keeps these files for 24 hours, so download them after the run. The option is disabled when the active environment is not Qlik Sense. If the task has never run, or Qlik no longer keeps its log, the result says that no task log was saved.

### -VerboseLog

Writes a fuller log for this run, with passwords, keys and tokens masked. This is QOps' own log — a different thing from `-ShowLogs`, which
returns Qlik's reload log.

### -Force

Skips the confirmation QOps asks before touching more than ten applications.

## See also

- [QOps-Reload](COMMAND-reload.md) — starting a reload, including `-Detached`, which this reads the result of
- [Commands](COMMANDS.md) — the whole command map
