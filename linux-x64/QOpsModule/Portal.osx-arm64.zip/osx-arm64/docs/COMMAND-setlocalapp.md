# QOps-SetLocalApp

**What it does.** Points one application folder in the repository at a different Qlik application,
for this machine only. The committed files are untouched, so the repository keeps saying what it
said to everybody else.

**Direction.** Local configuration. Nothing is read from Qlik and nothing is written to it.

**When you need it.** After cloning a repository onto an environment where the applications already
exist. Development, test and production each hold their own copy of an application under its own id,
and the repository can only carry one of them in `App.yaml`. This is what tells your machine which
copy it is working on — the recommended step after cloning, before the first
[QOps-Prepare](COMMAND-prepare.md) or [QOps-Build](COMMAND-build.md).

    QOps-SetLocalApp -OriginAppId "Sales Analytics" -TargetAppId 6f1c2a90-3d40-4a1e-9f77-0c0be8b5f1d2

## The two ids are not the same kind of thing

`-OriginAppId` names the **folder in the repository**, by the `Id` its committed `App.yaml` /
`App.json` carries. `-TargetAppId` is the **Qlik application id** on the environment you are on. The
first says which project you mean; the second says what it should talk to.

The lookup reads the committed file and deliberately ignores any local one, so re-pointing a folder
that is already pointed somewhere takes the same `-OriginAppId` as the first time — never the id you
set last time.

## What comes back

One object carrying `Name`, `OriginAppId`, `TargetAppId` and a `Status` of `Done` or `Failed`.

`Failed` has one cause: no folder in the repository carries that `-OriginAppId`. Nothing is written,
and the run says

    Can`t find app with id <id>

If more than one folder carries the same committed `Id`, the one directly under the repository root
is chosen.

## The target is not checked

Nothing is asked of Qlik, which is what makes this work offline and against an environment you are
not connected to yet. The consequence is that a mistyped id is recorded exactly as willingly as a
correct one, and nothing says so until the next `QOps-Build` or `QOps-Reload` goes looking for an
application that is not there.

**An application in a shared or managed space is a target you can set and will not keep.** Nothing
here refuses it, but `QOps-Build` does not write into a space: the next build copies that application
into your personal space and rewrites this file to name the copy. See
[Shared and managed spaces on Qlik Cloud](COMMAND-build.md#shared-and-managed-spaces-on-qlik-cloud).

## The file it writes

`App.local.yaml` or `App.local.json`, beside the `App.yaml` / `App.json` it belongs to, in whichever
format the repository uses. It is created if it was not there.

The file is **local by construction**: configuring a repository puts `*App.local.yaml` and
`*App.local.json` in its `.gitignore`, so it is yours and does not travel to anybody else.

**It holds a full copy of the application's properties, with the id replaced** — not a single line
naming the id. While it exists, the properties QOps reads for that folder come from it *instead of*
the committed file, rather than being layered on top. So a change somebody else makes to the
application's name, stream or description in the committed file does not reach your machine until
this file is written again or deleted. Deleting it is the way to go back to the committed id: there
is no command that clears the mapping.

## Flags

### -OriginAppId

Required. The `Id` in the committed `App.yaml` / `App.json` of the folder you are pointing.

### -TargetAppId

Required. The id of the application on this environment that the folder should work on from now on.

### -Profile

Which configured authentication profile to use, when the repository has more than one. The same
switch as on every other command — but it reaches less far here than elsewhere: this command never
contacts Qlik, so the profile decides only which configuration is read, never which Qlik is asked
whether the target exists. Nothing does.

### -VerboseLog

Writes a fuller log for this run.

## The same idea for extensions

[`QOps-SetLocalExtension`](COMMAND-extensions.md) does this for an extension, keeping a local variant
of its properties the same way.

## See also

- [Commands](COMMANDS.md) — every command and which one to reach for
- [QOps-Prepare](COMMAND-prepare.md) — writing an application from Qlik into the repository
- [QOps-Build](COMMAND-build.md) — writing the repository back into a Qlik application
- [Configuration](CONFIGURATION.md) — the settings a repository carries
