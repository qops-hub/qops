# QOps-BuildExtensions

**What it does.** Puts the extensions held in the repository into the environment as **work in progress**: each one appears under a name prefixed with `_WIP_` and your account, so it cannot collide with the published one your users see.

**Direction.** disk → Qlik.

**In the Portal.** On the **Operations** panel, under **All commands**, as **Build extensions**.

**Needs.** **Qlik Sense only.** Run against a Qlik Cloud or QlikView configuration it says so and
stops without doing anything, and the panel disables it on those environments.

    QOps-BuildExtensions -Filter "Name=sales-*"
    QOps-BuildExtensions -Filter *

## Work in progress

A build never disturbs the version already in use. To replace that one, run
[`QOps-ReleaseExtensions`](COMMAND-releaseextensions.md).

## When no filter is given

Given no `-Filter`, it uses the filter the repository has saved, the one
[`QOps-AddExtensions`](COMMAND-addextensions.md) put there. With no filter given and none saved it
does nothing and says so:

    no filter was given and none is saved in this repository, so no extensions were touched.
    Write commands do not act on everything by default - pass -Filter * to include every one of
    them, or a name or pattern to narrow it.

So `-Filter *` is how you ask for all of them. See
[Leaving the filter out](COMMAND-extensions.md#leaving-the-filter-out) for why reading and writing
differ here.

## Flags

### -Filter

Which extensions to act on. The same filter grammar the rest of QOps uses: `Name=`, `*` and `?` as
wildcards, and `;` between clauses when you want several.

    -Filter "Name=sales-*"
    -Filter *

> The `;` is part of the filter, not a separator the Portal invents. Typed into the panel it reaches
> the command intact.

Left out, the filter this repository has saved under `ExtensionsFilter` is used.

### -Sort

Which column the result is ordered by, by name. It changes the order of the output only, not what is
found.

### -SkipCustomProperties

Leaves the custom property values attached to each extension out of this run. Use it when the
environment you are writing to does not have the same custom properties defined, or when you only
want the extension's own files.

### -Profile

Which configured authentication profile to use, when you run the command yourself. The Portal does
not offer it: the command runs in the repository, so it uses the repository profile, like Prepare and
Build do.

### -VerboseLog

Writes a fuller log for this run, with passwords, keys and tokens masked. Turn it on when you are going to send a log to somebody.

## See also

- [Extensions](COMMAND-extensions.md): the group this command belongs to, and how the commands fit together
- [Commands](COMMANDS.md): the whole command map
