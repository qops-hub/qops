# How does QOps know which Qlik application a repository folder belongs to?

Every application folder in a QOps repository carries two ids, in two files. One says which folder
this is inside the repository. The other says which Qlik application that folder is bound to on the
environment you are working with. Knowing which is which answers most questions about what a build
will write into, and why a fresh clone behaves differently from the checkout it came from.

This page applies to Qlik Sense and Qlik Cloud.

## The two files

An application folder sits directly under the repository root (or under a folder listed in
`AppSubfolders`) and holds its properties in `App.yaml`, or `App.json` when the repository uses JSON.
Beside it there may be a second file, `App.local.yaml` or `App.local.json`.

| | `App.yaml` / `App.json` | `App.local.yaml` / `App.local.json` |
|---|---|---|
| Committed to Git | yes | no: configuring a repository adds `*App.local.yaml` and `*App.local.json` to its `.gitignore` |
| What its `Id` means | the folder's identity inside the repository | the Qlik application this folder is bound to on one environment |
| What the `Id` looks like | any string: a Qlik application id, the folder name, or a name you chose | a Qlik application id |
| Who has it | everybody who clones the repository | only the checkout where it was written |

### The committed Id

The `Id` in `App.yaml` names the folder. It does not have to be a Qlik application id, and QOps does
not require it to exist on any server. It is what `-Filter "Id=..."` matches and what
[QOps-SetLocalApp](COMMAND-setlocalapp.md) takes as `-OriginAppId`.

It is written once, when the folder gets its identity:

- **QOps-Prepare** writing an application into a new folder records that application's Qlik id.
- **QOps-Build** creating an application for a folder whose `Id` is empty records the **folder name**,
  for example `Id: Sales Overview-prj`. See
  [Create a new Qlik application from the repository](HOWTO-create-new-application.md).
- **You** can write any Id yourself. A readable one, such as `Id: sales-overview`, works everywhere a
  Qlik id does.

QOps never rewrites a committed `Id` that is already there. A build only fills in an empty one.

### The local Id

The `Id` in `App.local.yaml` is the Qlik application id this folder is bound to on the environment
this checkout works with. It is written by:

- **QOps-Build**, which records the application it wrote into after every build.
- **QOps-Prepare**, when it writes an application into a folder that already exists.
- **QOps-SetLocalApp**, which binds a folder to an application you name. In the Portal: right-click
  the application's `-prj` folder in the Studio file tree and choose **Set local App…**, or open
  **Operations → All commands → Set local App**.

`App.local.yaml` is a full copy of the application's properties with its own `Id`, not a single
line. The details are on the [QOps-SetLocalApp](COMMAND-setlocalapp.md#the-file-it-writes) page.
Deleting the file returns the folder to its committed `Id`.

## Which id a command uses

When a folder has an `App.local` file, its `Id` decides which Qlik application the command works
on. Without one, the committed `Id` is looked up on the server.

A filter always starts from the committed `Id`. `QOps-Build -Filter "Id=sales-overview"` finds the
folder whose `App.yaml` says `Id: sales-overview`, then reads that folder's `App.local` to find the
application on this environment.

That split is what lets one repository serve several environments. Development, test and production
each hold their own copy of an application under its own Qlik id. The repository carries one committed
`Id` for the folder, and each checkout keeps its own binding in `App.local`.

## What a build does with each folder

`QOps-Build` looks up the folder's id on the server you are connected to and then acts on what it
found. The [-New](COMMAND-build.md#new) and [-UpdateOnly](COMMAND-build.md#updateonly) switches select
which folders the run acts on; they cannot be used together.

| The folder on this environment | `QOps-Build` | `QOps-Build -New` | `QOps-Build -UpdateOnly` |
|---|---|---|---|
| Has no `Id` | creates an application, records the folder name as `Id` and the Qlik id in `App.local` | the same | skipped, with the command that maps it |
| Its id is an application you own and can write in place | updates it | skipped | updates it |
| Its id is an application a build does not write in place | creates a copy and binds `App.local` to the copy | skipped | skipped |
| Its id is not an application on this server | creates an application and records its Qlik id in `App.local`; the committed `Id` stays as it is | the same | skipped, with the command that maps it |

**Can write in place** means: on Qlik Sense, an unpublished application owned by the account QOps
connects as; on Qlik Cloud, an unpublished application in no space, owned by that account (your
personal space). A published application, one owned by somebody else, or on Qlik Cloud one that lives
in a shared or managed space, is copied rather than written. See
[Shared and managed spaces on Qlik Cloud](COMMAND-build.md#shared-and-managed-spaces-on-qlik-cloud).
Putting the work into a stream or a space is the job of [QOps-Publish](COMMAND-publish.md) and
[QOps-Release](COMMAND-release.md).

A build limited with `-Path` only acts on an application that already exists; it creates nothing.

## The three situations this explains

- **You cloned a repository and the applications already exist on your environment.** There is no
  `App.local` yet, so no folder knows its application. Bind each folder with QOps-SetLocalApp. See
  [Connect a freshly cloned repository to your Qlik environment](HOWTO-connect-cloned-repository.md).
- **You want the repository's applications on another environment where they do not exist yet.**
  The committed Ids stay as they are, and the build writes a new `App.local` for that environment.
  See [Set up a repository's applications on another Qlik environment](HOWTO-set-up-another-environment.md).
- **You want a new application.** A folder with no `Id` is built into one. See
  [Create a new Qlik application from the repository](HOWTO-create-new-application.md).

## See also

- [How-to guides](HOWTO.md): every task-oriented page
- [QOps-Build](COMMAND-build.md): which application a build writes into, and every switch
- [QOps-SetLocalApp](COMMAND-setlocalapp.md): binding a folder to an application on this environment
