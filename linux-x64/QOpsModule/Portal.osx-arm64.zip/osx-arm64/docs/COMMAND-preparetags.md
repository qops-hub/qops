# QOps-PrepareTags

**What it does.** Writes tags from the environment into the repository as files.

**Direction.** Qlik → disk.

**In the Portal.** On the **Operations** panel, under **All commands**, as **Prepare tags**.

**Needs.** **Qlik Sense only.** Run against a Qlik Cloud or QlikView configuration it says so and
stops without doing anything, and the panel disables it on those environments.

    QOps-PrepareTags
    QOps-PrepareTags -Filter "Name=Finance*"

## When no filter is given

Given no `-Filter`, it uses the filter the repository has saved under `TagsFilter`
(`QOps-AddTags` writes it). With none saved it finds nothing to write and reports `Nothing found`;
pass `-Filter *` for every tag.

## Flags

### -Filter

Which tags to act on. The same filter grammar the rest of QOps uses: `Name=`, `*` and `?` as
wildcards, and `;` between clauses when you want several.

    -Filter "Name=Finance*"
    -Filter *

> The `;` is part of the filter, not a separator the Portal invents. Typed into the panel it reaches
> the command intact.

Left out, the filter this repository has saved under `TagsFilter` is used.

### -Sort

Which column the result is ordered by, by name. It changes the order of the output only, not what is
found.

### -Profile

Which configured authentication profile to use, when you run the command yourself. The Portal does
not offer it: the command runs in the repository, so it uses the repository profile, like Prepare and
Build do.

### -VerboseLog

Writes a fuller log for this run, with passwords, keys and tokens masked. Turn it on when you are going to send a log to somebody.

## See also

- [Tags](COMMAND-tags.md): the group this command belongs to
- [Commands](COMMANDS.md): the whole command map
