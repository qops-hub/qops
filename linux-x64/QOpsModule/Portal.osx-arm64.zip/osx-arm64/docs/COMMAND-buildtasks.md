# QOps-BuildTasks

**What it does.** Creates the reload tasks held in the repository in the target environment. Its source is what
[`QOps-PrepareTasks`](COMMAND-preparetasks.md) wrote.

**Direction.** disk → Qlik.

**In the Portal.** On the **Operations** panel, under **All commands**, as **Build reload tasks**.

**Needs.** **Qlik Sense only.** Run against a Qlik Cloud or QlikView configuration it says so and
stops without doing anything, and the panel disables it on those environments.

    QOps-BuildTasks
    QOps-BuildTasks -Filter "Name=Nightly*"

## When no filter is given

Given no `-Filter`, it uses the filter the repository has saved under `TasksFilter`
(`QOps-AddTasks` writes it). With none saved it finds nothing and reports `Nothing found`; pass
`-Filter *` for every task.

## Flags

### -Filter

Which reload tasks to act on. `Name=` matches the task name and `AppId=` the id of the app the task
reloads; `*` and `?` are wildcards, and `;` goes between clauses.

    -Filter "Name=Nightly*"
    -Filter "AppId=2a1f7c60-9d3e-4a52-8d1c-6b0f5e2a4c11"

> The `;` is part of the filter, not a separator the Portal invents. Typed into the panel it reaches
> the command intact.

Left out, the filter this repository has saved under `TasksFilter` is used.

### -Sort

Which column the result is ordered by, by name. It changes the order of the output only, not what is
found.

### -Profile

Which configured authentication profile to use, when you run the command yourself. The Portal does
not offer it: the command runs in the repository, so it uses the repository profile, like Prepare and
Build do.

### -VerboseLog

Writes a fuller log for this run, with passwords, keys and tokens masked. Turn it on when you are going to send a log to somebody.

## See also

- [Reload tasks](COMMAND-reloadtasks.md): the group this command belongs to
- [Commands](COMMANDS.md): the whole command map
