# Which apps a repository tracks

A repository does not automatically work on every application in Qlik. It carries a saved **filter**,
and the operations use it whenever you do not pass one for the run. This page is about changing that
filter — and about the two commands whose names suggest they do something else.

## The commands

| Command | What it does |
|---|---|
| `QOps-Apps` | Lists the applications a filter matches, and remembers that filter for the next command |
| `QOps-AddApps` | Saves the remembered filter into the repository's configuration |
| `QOps-SetFilter` | Replaces the saved filter with a value you give |
| `QOps-ClearFilters` | Resets the saved filter to `*`, everything |

The usual sequence is the first two together: list what a filter matches, look at the result, and only
then save it.

```powershell
QOps-Apps -Filter "Name=Sales*"   # see what matches
QOps-AddApps                      # keep it
```

`QOps-AddApps` ADDS to what is already saved. To replace the saved filter instead of extending it, use
`-NoAppend`, or set it outright with `QOps-SetFilter`.

## `QOps-AddApps` does not create an application

The name reads as "add an application", and there is no command that creates one, so this is where
people looking for that end up. It edits the repository's filter — which applications are worked on —
and nothing about it reaches Qlik.

To create an application, see
[Creating a new application](COMMAND-build.md#creating-a-new-application): put an identifier in the
app's properties file that no application on your Qlik uses, and the next build creates it. An empty
Id does not work — that page says why, and what to watch out for when inventing one.

## `QOps-RemoveApps` is not its opposite

Despite the names, these two are not a pair.

- `QOps-AddApps` changes a filter in the repository.
- `QOps-RemoveApps` **deletes applications from Qlik.**

And it needs `-Force`. Without it, the command lists the applications it would delete and stops
without deleting anything — no error, no warning, just a report that reads like a summary of work
done. If you ran it and the applications are still there, that is why.

## See also

- [QOps-Build](COMMAND-build.md#creating-a-new-application) — how an application is created
- [Configuration](CONFIGURATION.md#the-repository-file) — the `Filter` field this is stored in
- [Commands](COMMANDS.md) — the whole command map
