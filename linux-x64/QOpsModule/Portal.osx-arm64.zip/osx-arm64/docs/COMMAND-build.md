﻿# QOps-Build

**What it does.** Reads the files in the repository and writes them into a Qlik application: the
script, the sheets and their objects, the master items, the variables, the application's properties.

**Direction.** disk → Qlik. This is the direction that changes what people see in Qlik.

**In the Portal.** Operations → Build.

## Where an application has to live

A build looks for applications by scanning **one level** below the repository root: a folder is an
application when it sits directly inside the root and contains an `App` file (`App.yaml`, or
`App.json` when the repository is configured for JSON). It does not look deeper.

The folder's name does not matter. The `-prj` suffix is a convention, not a condition.

If your applications are not at the root, `AppSubfolders` is the supported way to say so: each entry
becomes another place to scan, again one level deep. See
[Keep applications in subfolders](HOWTO-app-subfolders.md).

This is worth knowing because of what a run says when it finds nothing: **Nothing found** is the same
message whether no application folder was found at all or the filter matched none of the ones that
were. If a build reports it and you are sure the Id is right, check the layout before you check the
Id.

## What a build targets

Two separate things decide what a build does: which applications the run is about, and which Qlik
application each one writes into.

**Which applications the run is about** is the filter. On the command line that is `-Filter`; leave it
out and the build uses the repository's saved filter from `.qopsconfig` — the one
[`QOps-AddApps`](COMMAND-addapps.md) writes. In the Operations panel you pick the applications and the
panel builds the filter for you: an application whose properties file names an `Id` is addressed by
that Id, and one whose `Id` is empty is addressed by `Name`, because an id-less folder has no id to
match on the server.

**Which Qlik application a build writes into** is decided by the `Id` in that folder's properties
file, and by nothing else. The name in the files plays no part in it, so renaming an application on
disk does not redirect the build — it keeps writing into the same Qlik application under a new name.

Where a folder has both `App.yaml` and `App.local.yaml`, the `.local` file is the one that decides.

## Shared and managed spaces on Qlik Cloud

This section is about **Qlik Cloud** only.

`QOps-Build` writes into an application that sits in **no space and is owned by the account QOps
connects as** — in practice, your own personal space. An application that lives in a shared or a
managed space is not written in place: the build creates its own copy in your personal space, writes
there, and leaves the application in the space exactly as it was.

That is what the command is for rather than a limitation of a particular run. Building is the step
you take while the work is still yours; putting it in front of other people is a separate and
deliberate one.

There are two ways you arrive at that copy, and both are ordinary:

1. **You prepared from an application in a shared or managed space.** The first build creates the
   copy and records it in `App.local`. Every build after that goes into the same personal
   application — there is nothing to repeat and nothing to undo.

2. **You pointed `App.local` at an application in a shared or managed space**, with
   [`QOps-SetLocalApp`](COMMAND-setlocalapp.md) for instance. The next build does not write into it:
   it creates the copy and rewrites `App.local` to name the copy. From that point you are in case 1,
   and the id you set by hand is no longer the one in the file.

Either way `App.local` is the record of where the build actually went, which makes it the file to
read when you want to know which application this repository is bound to right now.

**Putting the work into a shared or managed space** is the other half, and two commands do it:
[QOps-Publish](COMMAND-publish.md), and [QOps-Release](COMMAND-release.md), which builds and
publishes in one run. Those two are the only ones that write an application from the repository into
a space.

An application owned by somebody else is copied for the same reason and in the same way. What decides
this is settled before any flag is read — see [`-Inplace`](#inplace).

## Sheet visibility on Qlik Cloud

This section is about **Qlik Cloud** only. On Qlik Sense a sheet's published state means nothing
until the application itself is published, and a build leaves it alone there.

On Qlik Cloud a sheet is published on its own, whether or not the application is. That is what the
sections in the sheet list are: a published sheet sits in **Public**, an unpublished one in **My
own**. A build applies the `Published` value each sheet carries in the repository, so a sheet you
published before you prepared the application is published again in the application the build writes
into — you do not have to republish it by hand afterwards.

It works the same way in both directions. A sheet whose repository file says `Published: false` is
made private if it is public on the server, and one that says `Published: true` is published if it is
private.

Two things to know before you rely on it:

- **`Approved` is not applied on Qlik Cloud.** Qlik Cloud has no approve operation for a sheet at
  all, so the value is read and written in the repository but cannot be sent to a tenant. `Published`
  is what moves a sheet between **My own** and **Public**, and it is applied.

- **A sheet that is approved but not published has its `Approved` value cleared** when the repository
  is written, because approval only means something for a published sheet.

If the sheets in a repository were prepared by QOps 3.0.16 or earlier, check their `Published` values
before your first build with this version. Those versions did not report the server's state for the
application they were prepared from — they wrote a substitute — and a build now applies what the files
say.

Which applications that covers depends on the version that prepared them. **3.0.6 to 3.0.16** wrote
the substitute for an application in a **personal** space. **3.0.5 and earlier** wrote it for any
application that was **not published**, which includes one sitting in a shared space. From **3.0.17**
onwards the state in the files is the state the tenant reported.

## Creating a new application

There is no create command. An application is created by a build: a folder whose properties file names
no `Id` is built into a new application, and a build never skips it for that reason. Each such folder
gets its own application: three folders with no `Id` in one run make three applications.

1. **Start from an app folder whose properties file names no `Id`** — an empty value, or no key at
   all. That is how you say *there is no target yet*. Give it the `Name` you want the application to
   have. If an `App.local` file sits beside the properties file it decides the Id, so clear it there
   or remove the file.

2. **Run the build**, narrowed the ordinary way if you want only some of them:

   ```powershell
   QOps-Build -Filter "Name=Sales Overview"
   ```

   Add `-New` when you want the run to create the new applications and leave every existing one
   alone — see [-New](#new).

3. **Nothing after that.** The build creates the application and records an `Id` in
   `App.yaml`/`App.json` if it was missing or empty, so every later command can address it and every
   later build updates it instead of creating another one.

   **The recorded `Id` is the project folder name, not the Qlik application id.** The Qlik id goes
   where it always went — `App.local` — and a filter finds the app through both: `-Filter "Id=<the
   folder name>"` matches the committed properties, and the `App.local` beside them says which
   application on this Qlik it means. That indirection is why one repository can serve several Qlik
   environments: the committed identity is the repository's own, and each environment keeps its own
   binding locally. A Qlik id committed into the app properties would tie the repository to one
   environment, which is the trap described under the older method below.

   Only the `Id` field is written; nothing else in the file is touched.

The new application is created in your own personal area — unpublished, and in no stream or space. To
put it somewhere, publish it afterwards; see [QOps-Publish](COMMAND-publish.md). It is owned by the
account QOps connects as, which is not necessarily the person who started the build.

### The older way still works, and this is its drawback

The older way to create an application is to give the `Id` an identifier that is
**present and wrong** — one that does not exist on your Qlik. The build finds no such application,
makes one, and writes the real Id back. That still works and nothing about it has been removed.

Its drawback is that it asks you to invent an identifier, and an invented identifier can turn out to
belong to something. A build picks its target by Id and nothing else, so an id that does exist on that
server writes into THAT application instead of creating one — with no error, because from the build's
point of view it found what it was addressed to.

⚠️ **This is what to think about when you move a repository to another server.** The Ids in a
repository prepared against one Qlik mean nothing on the next one — but *mean nothing* is not the same
as *cannot collide*, and if one does collide the result is a build into an application that was
already there. Migrating, **clear the `Id`** rather than relying on the old identifier
not matching anything.

Two traps around this, both of them things people hit:

- `QOps-AddApps` sounds like it creates one. It does not — it edits the repository's saved app filter.
  See [Which apps a repository tracks](COMMAND-addapps.md).
- Edit `Id` and `Name` at the start of the line, in the top-level block. There is a `name:` inside the
  owner block further down, and changing that one does nothing.

## Flags

### -Reload

Reloads the application's data after the build, in the same run. The same as running
[QOps-Reload](COMMAND-reload.md) afterwards.

### -Inplace

Changes **how** the application is written, not **which** one. With it, the objects are saved into the
application that is open and variables created by the load script are kept; without it, the document
is saved whole.

It does not choose the target. Whether a build writes into the application that is already there or
makes another one is settled before this flag is read: an unpublished application that belongs to you
is written to, while a published one, one owned by somebody else, or — on Qlik Cloud — one that lives
in a space, is not, and a build against those creates a new application instead — see
[Shared and managed spaces on Qlik Cloud](#shared-and-managed-spaces-on-qlik-cloud). `-Inplace` does
not override that on an ordinary build. It changes the target only on the publishing path, where
[Release](COMMAND-release.md#inplace) uses it.

That is also why a scoped build against an application in a space is skipped even though `-Path` turns
`-Inplace` on: writing in place is not reachable there at all, so the run refuses instead of leaving a
copy behind.

### -UseLocalExtensions

Builds the sheets against your local copies of the extensions: a widget whose type names the shared
extension is switched to the local one. Without it, the names in the files are used as they are.

### -UseBuildDiffs

Builds only the objects whose files changed since the last build, instead of every object. Faster on a
large application; it needs the repository's Git history to work out what changed, and a new
application is always built in full. It can also be turned on permanently for a repository — see
[Configuration](CONFIGURATION.md#the-repository-file).

### -IncludeBookmarks

Bookmarks are not written into the application by default. This writes the private ones.

### -AllBookmarks

Writes published bookmarks as well, and republishes the ones that were published. It turns bookmark
handling on by itself.

### -SkipCustomProperties

Does not write custom properties into the application.

### -SetOwner

Sets the application's owner to the account you name. It applies to a plain build; on a build that
publishes, the owner is decided by the publish and this is not used.

### -New
Builds only the applications that **do not exist yet**. A folder whose application already exists is
**skipped**, with a line saying so, so `-New` never writes into an application that is already there.

`-New` is not needed to create an application: without it every folder is built, and one that names
no `Id` is built into a new application just the same. Either way the new application's folder records
its `Id` in the committed app properties and the Qlik Id in its `App.local`, so the next build updates
it. See [Creating a new application](#creating-a-new-application).

**On the command line.** `QOps-Build -New` is the whole command for *create whatever is missing and
touch nothing else*. Combine it with `-Filter` to create only some of them; with no `-Filter` the run
uses the repository's saved filter, the same as any other build.

**In the Operations panel.** The same switch sits on Build and means the same thing, and the panel
also decides how each application you selected is addressed: by `Id` where the properties file names
one, by `Name` where the `Id` is empty. With the switch on, a selection holding both new and existing
applications creates the new ones and skips the rest; with it off, every application you picked is
built, the new ones included. Every application reports what happened to it — built, created, or
skipped and why.

An `Id` that is present but does not exist on the server still creates an application, with or without
`-New`, exactly as it always has. To skip such a folder instead, use [`-UpdateOnly`](#updateonly).

`-New` and `-UpdateOnly` cannot be used together: one builds only the applications that do not exist
yet, the other only the ones that do. The command refuses the pair before it starts; in the Operations
panel turning one on turns the other off.

### -UpdateOnly

Builds only into applications that **already exist on the server**, and never creates one. Use it when
a new application appearing would be a mistake, for example the first build after cloning a repository
onto a machine or environment where the applications are already there.

A folder is built when the `Id` it names is an application on the server you are connected to. Where a
folder has an `App.local` file, the `Id` in that file is the one looked up, as for every build. The
other folders are **skipped**, each with a line that names the folder, says what was looked up, and
prints the command that fixes it. Nothing is created for them.

Two kinds of folder do not resolve, and they are different situations:

- **No `Id`.** The properties file names no application at all. Without `-UpdateOnly` the build creates
  a new application for it. With it, the folder is skipped. If the folder belongs to an application that
  already exists, give it an `Id` first (the folder name is a good one: `Id: Sales Overview-prj`), then
  point it at that application:

  ```powershell
  QOps-SetLocalApp -OriginAppId 'Sales Overview-prj' -TargetAppId <server app id>
  ```

- **An `Id` that is present but is not an application on this server.** This is the usual shape after
  a fresh clone. A folder that a build created records its folder name as its `Id` in the committed
  properties file, and records the Qlik id only in `App.local`, which is never committed. On a new clone
  there is no `App.local` yet, so the `Id` in the properties file matches nothing on the server. Without
  `-UpdateOnly` the build creates an application for it, which is a second copy when the first one is
  already there. With it, the folder is skipped, and the line gives you the command with the folder's
  own `Id` filled in:

  ```powershell
  QOps-SetLocalApp -OriginAppId 'Sales Overview-prj' -TargetAppId <server app id>
  ```

  An `App.local` that names an application which is no longer on the server is the same case. The
  command uses the `Id` from the committed properties file, because that is how
  [QOps-SetLocalApp](COMMAND-setlocalapp.md) finds the folder.

After `QOps-SetLocalApp` the folder resolves, and the next `QOps-Build -UpdateOnly` builds it.

An application that is found but that a build does not write into is skipped as well, because a build
would create a copy of it: one that is published, one owned by somebody else, or, on Qlik Cloud, one
that lives in a space. See [`-Inplace`](#inplace) for why a build copies those.

`-UpdateOnly` changes nothing about publishing. [QOps-Publish](COMMAND-publish.md) and
[QOps-Release](COMMAND-release.md) find their target by stream or space and name, as before, and do not
take this switch. It is not supported for QlikView, where the command refuses it with a message.

**In the Operations panel.** The switch sits on Build as **Update only**, and the command preview shows
it.

### -Path

Limits the run to the objects under one path, glob or single file inside the app's `-prj` folder —
`Dimensions`, `Sheets/<id>`, `Variables/v*`. Inside the path the build is a full sync, deletions
included; outside it nothing is touched.

`-Path` is for applications that already exist. A folder that names no `Id` has no application to
scope into, so a `-Path` build skips it with a line saying so and creates nothing; run a full build
first.

It implies in-place: a scoped build changes part of an application that already exists, so
[`-Inplace`](#inplace) is on whether or not you asked for it. In the Operations panel the switch shows
that — it is on and cannot be changed while a path is set.

The full rules are in [Building one part of an application](#building-one-part-of-an-application)
below.

### -VerboseLog

Writes a fuller log for this run.

### -Force

Skips the confirmation QOps asks before touching more than ten applications.

## Building one part of an application

`-Path` limits a build to the objects under one path, glob or single file inside the app's `-prj`
folder — `Dimensions`, `Sheets/<id>`, `Variables/v*`.

Inside the path the build is a full sync, deletions included: an object you deleted on disk is deleted
in the application. Outside it, nothing is touched.

A scoped build acts on an application that already exists, and only ever edits the application it
names — it never creates one and never leaves a copy behind. Where it cannot do that it is skipped, with the reason,
rather than building something else: the application does not exist yet, it is published, or it
belongs to somebody else. On Qlik Cloud there is a fourth — the application lives in a space and you
did not ask to publish, where building would produce a copy and leave the named application untouched.

A scoped build does not push the application's description or thumbnail, which live in `App.yaml`
outside every object folder. Name `App.yaml` in the path when they are what you want to move.

Matching ignores case and accepts either slash. On QlikView the switch is refused with a message
rather than accepted and ignored.

## See also

- [QOps-Prepare](COMMAND-prepare.md) — the other direction
- [QOps-Release](COMMAND-release.md) — build and publish in one run
- [Commands](COMMANDS.md) — the whole command map
