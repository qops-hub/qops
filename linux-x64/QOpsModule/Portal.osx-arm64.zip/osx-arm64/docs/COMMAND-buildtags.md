# QOps-BuildTags

**What it does.** Creates the tags held in the repository in the target environment. Its source is what
[`QOps-PrepareTags`](COMMAND-preparetags.md) wrote.

**Direction.** disk → Qlik.

**In the Portal.** On the **Operations** panel, under **All commands**, as **Build tags**.

**Needs.** **Qlik Sense only.** Run against a Qlik Cloud or QlikView configuration it says so and
stops without doing anything, and the panel disables it on those environments.

    QOps-BuildTags
    QOps-BuildTags -Filter "Name=Finance*"

## When no filter is given

Unlike most write commands, this one treats no filter as **all of them**: every tag the repository
holds is created. Give a filter to narrow it.

## Flags

### -Filter

Which tags to create. `Name=`, `*` and `?` as wildcards, and `;` between clauses.

    -Filter "Name=Finance*"

Left out, **every** tag the repository holds is created.

### -Sort

Which column the result is ordered by, by name. It changes the order of the output only, not what is
found.

### -Profile

Which configured authentication profile to use, when you run the command yourself. The Portal does
not offer it: the command runs in the repository, so it uses the repository profile, like Prepare and
Build do.

### -VerboseLog

Writes a fuller log for this run, with passwords, keys and tokens masked. Turn it on when you are going to send a log to somebody.

## See also

- [Tags](COMMAND-tags.md): the group this command belongs to
- [Commands](COMMANDS.md): the whole command map
