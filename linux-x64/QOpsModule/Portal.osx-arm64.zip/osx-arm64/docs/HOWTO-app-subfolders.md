# Keep applications in subfolders with AppSubfolders

**Goal:** keep the application folders in one or more subfolders of the repository, such as `apps/`,
and have Prepare, Build and Release find them there.

This page applies to Qlik Sense and Qlik Cloud.

## When you need this

- The repository holds more than applications (scripts, pipeline files, documentation) and you want
  the application folders in their own place.
- You want the `.qopsconfig` at the repository root and the applications under `apps/`.

If every application folder sits directly under the repository root, you do not need `AppSubfolders`.

## What it is

`AppSubfolders` is a field of the repository's `.qopsconfig`. It is a list of folders, written as paths
relative to the folder that holds the `.qopsconfig`, separated by `;`:

```yaml
AppSubfolders: apps;partners/emea
```

QOps always scans the folder holding the `.qopsconfig`. Each entry in the list is one more folder to
scan. In each scanned folder QOps looks **one level down**: a child folder is an application when it
holds an `App.yaml` (or `App.json` when the repository uses JSON). Its name does not matter.

Things to know about the syntax:

- **Plain relative paths only.** There are no wildcards: `apps*` is looked up as a folder with that
  literal name. The configuration wizard's question mentions wildcards; the code does not apply them.
- **An empty value means the root only.** It does not mean "all subfolders". Nothing is scanned that
  you did not list.
- **Entries are separated by `;` and used as typed.** Spaces around an entry are not trimmed.
- **An entry is itself one folder.** `partners/emea` scans the application folders directly inside
  `partners/emea`, not inside `partners`.
- **The scan is not recursive.** An application folder inside `apps/team/` is invisible when only
  `apps` is listed. List `apps/team` as well.

## Set it

Edit the `AppSubfolders` line in the repository's `.qopsconfig`, or open the repository's settings in
the Portal and fill **App subfolders** (for example `sub1;sub2`). The configuration command takes the
same value in its `-AppSubfolders` switch; see its [command page](COMMAND-setconfig.md).

The configuration command checks every entry before writing anything. An entry that is not
an existing folder under the repository, or that is an absolute path, stops the command:

```text
Given subfolder '<entry>' does not exist
```

Editing `.qopsconfig` by hand, or saving the field in the Portal, does not run that check, so spell each entry carefully. To clear the list, give
the switch an empty value or empty the field in the Portal.

## Example layouts

Applications under one folder:

```text
my-repo/
  .qopsconfig            AppSubfolders: apps
  apps/
    Sales-prj/App.yaml
    Finance-prj/App.yaml
```

Applications in the root and in two subfolders:

```text
my-repo/
  .qopsconfig            AppSubfolders: apps;partners/emea
  Common-prj/App.yaml
  apps/Sales-prj/App.yaml
  partners/emea/Reports-prj/App.yaml
```

Not found, because the application sits two levels below a listed folder:

```text
my-repo/
  .qopsconfig            AppSubfolders: apps
  apps/team/Sales-prj/App.yaml
```

## How each command uses it

| Command | What happens |
|---|---|
| **QOps-Prepare** | Looks for an existing folder of the application in the root and in every listed folder, matching by the application's `Id`. If it finds one, it updates it there. If both the root and a subfolder hold the same application, the one directly in the root wins. |
| **QOps-Build** and **QOps-Release** | Take the application folders from the root and every listed folder, then apply the filter. Release runs the same build step first. |
| **QOps-SetLocalApp** | Looks for the `-OriginAppId` folder in the root and every listed folder. |
| **QOps-ConvertToYaml / ConvertToJson** | Convert the application folders found the same way. |
| **QOps-Reload and QOps-Publish** | Do not read local folders for this, so `AppSubfolders` has no effect on them. |

### Where Prepare puts a new application

`AppSubfolders` helps Prepare **find** a folder. It does not decide where a **new** one goes. An
application that has no folder yet is written to `<folder holding .qopsconfig>/<Name>-prj`, next to the
`.qopsconfig`, even when `AppSubfolders: apps` is set. Move that folder into `apps/` yourself. Later
Prepare and Build runs find it there by its `Id` and update it in place.

### Publishing in place on Qlik Cloud

When a publish to a shared space updates an existing application in place, QOps temporarily clears
`AppSubfolders` for the Prepare and Build it runs in a temporary folder, and restores it afterwards.
This keeps that build away from the folders in your checkout. Your `.qopsconfig` is not changed.

## The Portal

The Portal runs every command inside the repository folder, so Prepare, Build and Release behave as
described above, including the settings you save in the repository's settings panel.

The Portal's own application list, and the screens built on it (dashboard counts, lineage,
documentation, diffs, the file browser), use the same rule as Prepare and Build: an application is any
folder with an `App.yaml` or `App.json` directly inside the repository folder or directly inside a
folder listed in `AppSubfolders`. The folder name does not matter, and a folder deeper than that is not
listed, because QOps does not act on it either. A listed folder that does not exist is skipped.

The Portal only lists folders inside the repository. An `AppSubfolders` entry that points outside it, an
absolute path elsewhere or a path that climbs out with `..`, is ignored by the Portal, although Prepare
and Build still follow it. Keep your application folders under the repository folder.

The Portal reads the repository's `.qopsconfig` from the folder the repository is registered at. Register
the repository at the folder that holds the `.qopsconfig`.

## Move the configuration from `apps/` to the repository root

You may have a `.qopsconfig` inside the `apps/` folder, with the applications directly beside it. To
move the configuration to the repository root and keep the applications in `apps/`:

1. Move `apps/.qopsconfig` to the repository root.
2. Add the line `AppSubfolders: apps` to it.
3. Merge the lines of `apps/.gitignore` that QOps added (the `App.local` masks) into the root
   `.gitignore`. QOps keeps its ignore lines in the `.gitignore` next to the `.qopsconfig`.
4. In the Portal, register the repository at the root folder if it was registered at `apps/`.
5. Run from the root, or from inside `apps/`. From a subfolder QOps walks up until it finds a
   `.qopsconfig`, moves there and says so:

   ```text
   Configuration file found in the current directory: <repository root>. Changing the working directory.
   ```
6. Check with `QOps-Build -Filter "Name=<one application>"`. If the build lists your applications, the
   move worked.
7. After this, when Prepare writes a **new** application, move its `<Name>-prj` folder from the root
   into `apps/`, as described above.

The commands that write the configuration are the exception to the walk-up: they work in the folder
you run them in and create or change the `.qopsconfig` there. Run them from the repository root.

## If it did not work

**No application folder found:**

```text
No app projects found. Scanned <n> location(s) starting at '<repository root>', one level deep: a folder holding App.json/App.yaml must be a DIRECT child of the repository root or of an AppSubfolders entry. Move it up, or add its parent to AppSubfolders (QOps-SetConfig -AppSubfolders).
```

`<n>` counts the repository root plus every listed folder that exists on disk. If `<n>` is 1 although
you listed folders, the entries were not read or do not exist: check the spelling and that you ran
the command inside the repository. If `<n>` is right, the application folder is deeper than one level.

**Folders found, filter matched none:**

```text
Found <n> app project(s) under '<repository root>', but none matched the filter <filter>. The projects are there — it is the filter that selected nothing.
```

The layout is fine here. Check the `-Filter`.

**The entry is rejected when you set it:** `Given subfolder '<entry>' does not exist`. Create the
folder first, write the path relative to the repository root, and do not use wildcards or an absolute
path.

## Common mistakes

- **Expecting wildcards or "empty means all".** Neither is true. List each folder.
- **Expecting a new application to appear in `apps/`.** Prepare writes it next to the `.qopsconfig`.
  Move it.
- **Listing the parent of a parent.** The scan is one level deep for each entry.
- **Setting the configuration from `apps/`.** The configuration command writes a new `.qopsconfig` there instead of changing
  the one at the root.
- **A folder in `apps/` without `App.yaml`.** It is not an application, and QOps skips it.

## See also

- [Create a new Qlik application from the repository](HOWTO-create-new-application.md)
- [How does QOps know which Qlik application a repository folder belongs to?](HOWTO-app-identity.md)
- [Configuration: the repository file](CONFIGURATION.md#the-repository-file)
- [QOps-Build: where an application has to live](COMMAND-build.md#where-an-application-has-to-live)
- [The configuration command](COMMAND-setconfig.md)
