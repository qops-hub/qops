# Earlier releases

Release notes for the QOps versions before the two on [What's New](CHANGELOG.md). Same shape, same
ordering: newest first, each entry says what is different when you sit down in front of the product.

Nothing here is edited once its release is out. A correction to a shipped note belongs in the release
that carries the fix, where a reader looking at what they just installed will find it.

---

## 3.1.4 — 2026-11-13

### Studio: .qvs files get proper syntax highlighting and breadcrumbs

A `.qvs` file opens in the Studio editor as a Qlik load script, with load-script syntax highlighting, `Ctrl+/` comments
and folding by `///$tab` section and block. As you type, Studio suggests load-script statements and
functions (`Ctrl+Space` to ask); a suggestion fills in the whole statement with placeholders, and `Tab`
moves between them. `Ctrl+Shift+O` lists the script's tabs with the subroutines and tables in each; pick one to
jump to it. A bar above the script shows where the cursor is, such as `Main › SUB LoadCalendar ›
Calendar`; click a part of it to jump to another tab, subroutine or table at that level.

### Studio: master item ids get inlay hints and link to the item's file

In an object file opened in Studio, an id such as `qLibraryId` shows the title of the object it points to,
for example `master measure: Total Sales`. Hover it for the description and file, Ctrl+Click to open that
file. A reference to a deleted master item shows `Object not found by ID`.

### Studio: rename an object or change its id from the file tree

Right-click a sheet, chart or master item in the Studio file tree and choose Rename or Change id. Change id
rewrites every reference to the object in the app, after a preview of every line that will change, and
writes all of it or nothing. The result stays in the working tree for you to review and commit.

### Operations panel: extensions, custom properties, tags and reload tasks

**All commands** on the Operations panel has groups for extensions, custom properties, tags and reload
tasks, so you can run Prepare and Build for them from the Portal without typing a command. **Dry Run** applies
to every command on the panel, including those that open a dialog, and every command uses the repository
profile.

### Lineage panel: master items, fields and variables, a compact layout and Isolate

The Lineage panel now draws lines from charts and master objects to the master items they use, and the
**Fields** toggle adds the app's fields and variables. **Compact** lays the graph out left to right, from
tables and fields to sheets, with no overlapping labels, and **Isolate** shows only one node's lineage. For
example, isolate a sheet of a large app to see just its charts, the master items they use and the fields
behind them, at full size.

### AI assistant (MCP): what uses a field or a master item, and where a field comes from

Ask the assistant "what uses the field `Target`?" or "where does `Region` come from?" and `get_lineage`
answers from a repository or from the live app in the engine. It lists the master items, charts and sheets
that read the field, through variables and master objects, and says the path to each chart in words. For
where a field comes from it gives the tables that load it and their data connection, from the load script
or the engine's lineage of the last reload, and names what in the script it could not follow instead of
guessing. When nothing is found to use a field, the answer says this does not prove the field is unused,
so the assistant does not advise removing it on that basis.

### AI assistant (MCP): labels for chart dimensions and measures

When the assistant creates a chart, it can give each dimension and measure its own label, so the table
header reads `Paywall shown` instead of `Count({<Event={paywall_shown}>} Event)`.

### Use the chat through a company LLM gateway

When the chat provider is Claude, **Settings → Global → Chat → Advanced settings** has an optional
**Base URL**. Enter the address of your company's gateway, and the chat goes through it instead of
`api.anthropic.com`. The gateway must accept Anthropic API requests; gateways that only offer the OpenAI
format are not supported, and the Gemini provider has no Base URL. Left empty, the chat works as before.

If Claude Code is already set up for the gateway, **Settings → Global → Chat → Advanced settings → Import
from Claude Code settings…** takes the same settings: the gateway address, the token, the default model and the model
list with its labels. It shows what will be set, with the token masked, before anything is saved.

### Send a support case from QOps in one command

[`QOps-SendSupportCase`](COMMAND-sendsupportcase.md) collects the logs and system details support needs,
masks passwords, tokens, connection strings and your licence serial, shows what it will send and asks
first, then prints the case number. It works without a licence and when the Portal is down; `-OutFile`
only writes the zip.

### Two QOps runs on the same app take turns

Before a Build or Release changes an app (on Qlik Cloud, also a Publish that updates an app in place), it places a small marker object in the app; the marker
is removed before the app is saved and never ends up in the repository. A second run on the same app, for
example a pipeline started while a colleague's Release is still going, waits for the first to finish and
names the run it waits for. After 10 minutes it stops with an error and changes nothing, so you can run it
again later. A running QOps renews its marker every 20 seconds; a marker that has not been renewed for 2
minutes, because its run crashed or lost the connection, is taken over.

### Fixes

- **On Qlik Cloud, commands work with an app right after it is created, copied or moved.**
  `QOps-Release`, `QOps-Publish` into a managed space and `QOps-Prepare` skip an app deleted a moment
  earlier that Qlik Cloud still lists, with a line in the log.
- **A Qlik Cloud Build or Publish that loses its engine connection stops at once** and names the app that
  may be partly updated, so it can be run again.
- **Concurrent `QOps-Prepare` runs on the same app from different repositories don't lose files.** If a
  project folder has lost `App.yaml` or `Script.qvs`, the next Prepare of that app writes the folder
  again from the app in Qlik and says in the log which files were missing.
- **A Build or Release keeps every object on its sheet and needs fewer calls to the Qlik engine**, which is
  most noticeable on Qlik Cloud and slow networks.
- **The Portal keeps logs for a support request**: earlier sessions as `portal.log.1` to `portal.log.5`, a
  log for every operation from the moment it starts, and the logs of failed command runs for 30 days.
- **The Portal closes operations it did not finish as interrupted**, and `QOps-StopPortal` shuts the
  Portal down the same way **Dashboard → Shut down Portal** does.
- **AI assistant (MCP):** reading master measures, master dimensions and variables is faster and does not
  hold up the next call; a call the engine does not answer in time closes its session, and the next call
  opens a new one.
- **AI assistant (MCP):** a refused chart write names the property path to send; replacing a chart's sort
  replaces it completely; a tool that works on repository files but was given a Qlik profile, or a
  live-app tool given a repository, says which kind of input it takes and names the tool to use instead.
- **Lineage links fields with an apostrophe in their name to their table.**

## 3.1.3 — 2026-11-04

### Commands and the Portal store saved credentials the same way on Linux and macOS; your licence serial is restricted to your account

Passwords, API keys, tokens and client secrets saved with [QOps-SetConfig](COMMAND-setconfig.md#which-of-the-two-configuration-commands-you-want), `QOps-Configure` or
`QOps-SetSensePassword`, or in the Portal's Environment settings, are encrypted the same way. Commands
such as `QOps-Apps` read the credentials saved in the Portal both inside a repository and from a folder
without a `.qopsconfig`, for example right after `QOps-StartPortal` in a GitHub Codespace. Values saved
with an earlier version are converted the next time QOps reads them inside a repository.

Your licence serial is readable only by your own account and the system account. QOps restricts the
`qopsconfig` folder, the `license.key` file, the `IPManager` activation folder and the activation files
in it to these two accounts: mode 600 for the file and 700 for the folders on Linux and macOS, and on
Windows an access list with inheritance disabled that holds only your account and the system account.
The restriction is applied when these are created and again on every write, so existing files and
folders are restricted the next time QOps writes them. If the permissions cannot be changed, QOps
carries on and the licence check is not affected.

### AI assistant (MCP): a shorter tool list, and smaller answers for chart settings, sheet lists and dry runs

The list of tools the assistant receives gives each tool a short description of what it does and when
to use it, so the list takes about a third of the room it took in the assistant's conversation. The
details of a tool (what each argument means, the accepted values, examples) come from the new
`describe_tool`, which the assistant calls for one tool when it needs them.

`list_chart_customisations` needs a chart type; without one, or with an unknown one, it answers with
the list of valid types. By default it returns the names of the settings for that type. Ask for up to
10 settings by name (`settings`) to get their description, current value and a ready patch. This keeps
each answer small enough for the assistant's conversation.

`list_sheets` answers with the id, title and object count of each sheet, 100 sheets to a page, and a
page stays under about 27,600 characters. The assistant finds a sheet by part of its title
(`titleContains`), or names sheets by id (`sheetIds`) to get only those, each with the id and type of
every object on it. When the full list is too large for one answer, it is also written once to a file
in the `.mcp-files` folder, and the answer gives its path.

`set_object_properties` and `apply_object_patches` with `dryRun` return the changed paths, each with its
old and new value, instead of the whole object before and after. Long values are shortened, and more
than 50 changed paths are cut with a note saying how many there are in total.

When such a dry run would change more than fits in one reply, the reply gives the counts per kind of
change and lists as many changed paths as fit, the paths that would be removed first. The full before
and after of every changed path is written once to a result file named in `fullResultPath`.

### AI assistant (MCP): chart sorting that Qlik applies

Ask the assistant to sort the dimension of a pie chart alphabetically, numerically or by an expression,
or to sort its measure numerically or alphabetically, and the chart is changed the same way Qlik stores
it when you choose that sorting yourself: the Sorting is switched from Auto to Custom in the same
change.

When `apply_object_patches` or `set_object_properties` writes the sort of a chart dimension or measure
while its Sorting stays on Auto, the change is refused before anything is written, a preview included,
and the answer says to switch that Sorting to Custom in the same change or to use the sort settings of
`list_chart_customisations`, which do both.

### Fixes

- **Activation and deactivation work when your Windows profile folder has a different name from your account.** For example, the account `jsmith` with the profile folder `C:\Users\John`. QOps keeps the activation files in your own roaming AppData folder (`IPManager`) and the file it reads them with in your `qopsconfig` folder, next to `license.key`. Files that an earlier version put in a folder named after the account are copied there once, on first use, and the existing activation keeps working. The originals stay where they were, so an earlier QOps version still finds them, and a later deactivation is not undone by copying them again. If a file exists in both places, the one in your profile is used and the other is left as it is. When QOps-Deactivate releases the licence but cannot remove a local file, it says so and names each file it left behind.

- **QOps-Push commits and pushes with the message, branch name, remote URL and folder exactly as written.** A commit message with spaces, quotes, semicolons, brackets, `$` or backticks is recorded word for word, and such characters in a branch name, URL or folder path are passed to git as plain text.

- **QOps-CleanSessions outside Qlik Sense says it works only with Qlik Sense.** In a Qlik Cloud profile, or in any mode other than Qlik Sense, the command says that cleaning sessions works only with Qlik Sense and does nothing.

## 3.1.2 — 2026-11-02

### Updates and version switching: the latest build of your channel, in both PowerShell editions

The version panel in the Portal works with the latest build of the update channel you chose. **Check for
updates** says either **You do not have the latest build from the &lt;channel&gt; channel**, with
**Download &lt;version&gt;**, or **You already have the latest build from the &lt;channel&gt; channel**, with
**Switch to &lt;version&gt;**. After a confirmation the Portal installs the build or switches to it, and
offers **Restart on &lt;version&gt;** right away, also when that build is older than the one the Portal runs.
A switch to an older version says that features, bug fixes and settings from newer versions are not
available in it. The panel, the status bar and the What's new link show the QOps version the Portal was
started from.

From PowerShell, `QOps-Update -IgnoreInstalledFromOtherChannels` installs the latest build of the channel
this computer is set to, or of the one given with `-Channel`, even when a newer build from another channel
is installed, for example to go back to the release build after trying a pre-release. `QOps-Update
-CheckOnly` reports whether that build is installed. See
[-IgnoreInstalledFromOtherChannels](COMMAND-update.md#ignoreinstalledfromotherchannels).

Every update goes into a folder of its own named after the version, on Windows as on Linux and macOS,
including `QOps-Update -Force`. No PowerShell window is closed and no other version is removed, and the
new folder is checked to load QOps before QOps switches to it.

`QOps-SetVersion`, `QOps-Update` and `QOps-Version -Installed` work with the module folder of the
PowerShell you run them in, so PowerShell 7 switches to the PowerShell 7 build. A Portal started from
Windows PowerShell 5.1 runs QOps commands in PowerShell 7 when it is installed, so `QOps-Prepare` on
Qlik Cloud works from such a Portal. `QOps-SetVersion` also switches the MCP server that assistants such
as Claude Desktop start; restart the assistant after switching. A Portal started from Windows PowerShell
on an earlier version updates and restarts into this version from the Portal. Leaving an earlier version
from the console still needs one PowerShell restart; every switch after that works.

### The QOps-Setup installer installs for all users

`QOps-setup.msi` installs for all users of the machine and asks for administrator rights when the
installation starts. Its Destination Folder page shows the Windows PowerShell 5.1 and PowerShell 7 module
folders. For a per-user install without administrator rights, use `QOpsModule.msi`. A QOps-Setup installed
earlier with Install just for you is not removed by the upgrade; remove it from Settings > Apps.

### GitHub Codespaces: the repository is ready when the Portal starts

In a GitHub Codespace, `QOps-StartPortal` registers the repository the Codespace was opened on, so the
Portal and the AI assistant list it without Add repository. When your QOps configuration has no `default`
profile yet, an empty one is added for you to fill in with your Qlik connection. Outside a Codespace
nothing changes.

### AI assistant (MCP): more chart settings, safer chart changes, shorter answers

- **More chart settings.** The assistant knows the full list of settings it can change for each chart
  type, explained in plain words: titles, legend, labels, axes, grid lines, colours, sorting, number
  formatting, reference and trend lines, conditions, alternative dimensions and measures, table totals and
  pagination, and the Styling panel. It sorts a chart's dimension and changes each setting the same way
  Qlik does when you set it in the properties panel.
- **Safer chart changes.** A property name, value or Styling setting the chart does not read, or a chart
  setting sent to a sheet, is refused before anything is written, and the answer names the right one.
  Settings behind an Auto switch, such as pie chart labels, are applied in one step.
- **Register a repository from the assistant.** Ask it to register a repository folder and it is added to
  the same list the Portal uses, under the same rules as Add repository in the Portal.
- **Answers that fit the assistant's conversation.** Master item, variable, object, application, lineage
  and data tools answer with a summary or a page first and give the rest on request, and the qops
  operation tools return the end of the command output. A complete answer that is too long for one reply
  is written to the repository's self-ignoring `.mcp-files` folder, where the assistant can search it.
  Prompts or scripts that read full details from these tools need `includeDetails`, `includeProperties`,
  `section` or `full=true`. See [AI Assistants (MCP)](MCP.md).

### Fixes

- **A global configuration that cannot be read is kept when you save.** The Portal refuses the change and
  shows the file's path and the reason, and offers **Back up and start fresh**; on the command line the
  same reset is `QOps-Configure -ResetGlobal`. The file is written to a temporary file first, so an
  interrupted write leaves the previous file intact.

- **`QOps-Release -Sort` sets the build and publish order, and parameters without effect are refused.**
  `-SkipCustomProperties` on `QOps-Build` and `QOps-Release`, and `-Ignore` on `QOps-Release`, stop the
  command before anything is changed. `QOps-Build` has no `-ServiceUrl` parameter, and `QOps-Reload` and
  `QOps-Publish` have no `-Placeholders` parameter.

- **QOps-Publish on Qlik Cloud publishes an app copied or imported a moment earlier**, and names an id
  that matches no app.

- **QOps-Prepare says when no app on the server matches the filter**, and names the server and how many
  apps it returned for the profile.

- **An expired licence key is reported as expired**, and a refused key does not block activating a valid
  one afterwards.

- **The version panel stops showing a failed restart once the Portal has been started again.**

- **Add repository in the Portal refuses a relative path and an id with characters other than letters,
  digits, `-`, `_` and `.`**; repositories already registered under such an id keep working.

## 3.1.1 — 2026-10-23

### Version manager: installed versions, switching and the update channel

The version panel in the Portal has a **Version settings** window. It lists the QOps versions installed on
the computer, newest first, with the date each was built, which one is running, and a badge for where it
came from: green **Release**, amber for a staging channel with its name, grey for anything else (another
channel, MSI or PKG, or Unknown). A filter shows All, Release, Staging or Other. **Switch** on any complete
version restarts the Portal on it at the same address, and the Start menu and Desktop shortcuts start that
version from then on; it is greyed out, with the reason, while operations, an update or a restart run. See
[Version settings](USER-GUIDE.md#version-settings-the-installed-versions-and-switching-between-them).

The same window sets the **Update channel**: **Release** (recommended), **Staging**, or **Other** with a
channel name such as `staging-mcp`. A channel other than Release shows a warning that its builds are not
release-tested. After the change the Portal checks what the new channel offers and installs nothing. The
version panel has **Check for updates**, and shows **Update to &lt;version&gt;** only when the channel has a
newer build. See [Version settings: the update channel](USER-GUIDE.md#version-settings-the-update-channel).

Staying on an older version now lasts. After `QOps-SetVersion`, or `QOps-Update -Force` to an older build,
QOps stays on the version you chose until an update installs a newer one or you switch to the newest
installed version, and later updates compare the channel with the version you chose. `QOps-Update -Force`
asks you to close the Portal first when the Portal runs from a version it would replace. See
[Staying on an older version](USER-GUIDE.md#staying-on-an-older-version).

The same is available from PowerShell and the Portal API: `QOps-Update -CheckOnly` checks the channel
without installing and names the cause when the check fails (no network, GitHub's request limit, a rejected
token); `QOps-Version -Installed` lists the installed versions as objects with their origin;
`QOps-SetUpdateChannel -PassThru` returns the change as an object. The Portal API lists installed versions,
switches between them and sets the channel. See [QOps-Update](COMMAND-update.md#what-a-check-returns) and the
[API reference](API-v2-reference.md#installed-versions-and-the-update-channel).

Switching versions, changing the channel, updating, restarting and stopping the Portal are accepted from
the computer the Portal runs on and from the addresses listed in the new `Portal:AdminAllowedAddresses`
setting in `portal.settings.json`. Used at `http://localhost`, nothing changes; from any other address the
request is refused with `403` naming the setting, and the Version settings window is read-only. Behind a
reverse proxy on the same computer every caller looks local, so restrict these actions at the proxy. See
[Who may switch versions, update, restart or stop the Portal](API-v2-reference.md#who-may-switch-versions-update-restart-or-stop-the-portal)
(QOPS-710, QOPS-723, QOPS-745, QOPS-746, QOPS-747, QOPS-748, QOPS-749, QOPS-750, QOPS-756, QOPS-781).

If an installation is broken or removed, the installers for Windows, macOS and Linux are on the
[Installation](https://qops.datalabsua.com/documentation/installation/) page (QOPS-766).

### Smoother start in GitHub Codespaces

Licence activation in a GitHub Codespace works out of the box: it completes in the Codespace's home
folder, and it no longer needs a configured Qlik profile first. Configure your Qlik connection when you
are ready to work with it (QOPS-773, QOPS-783, QOPS-784).

### Git panel: a filterable list for many remote branches

With more than eight remote branches, the Branches card shows one button that opens a filterable list
instead of a chip per branch. Each row has Check out and Merge, and the list works from the keyboard
(QOPS-690).

### Fixes

- **Line endings follow one order in every command and in the Portal.** QOps uses the first that is set:
  `EOLStyle` in the repository's `.qopsconfig`, the global `EolStyle`, `eol=` in `.gitattributes`, Git's
  `core.autocrlf` or `core.eol`, then the system's line ending. With CRLF set, a file with mixed endings is
  written entirely in CRLF. If `EOLStyle` is set in neither configuration file, some files
  may now be written with different endings than before; set it to keep the endings you want
  (QOPS-434, QOPS-504, QOPS-505).

- **The Portal lists the same applications as QOps.** The application list and the screens built on it
  find applications the way Prepare and Build do: a folder with `App.yaml` or `App.json` directly inside
  the repository or inside a folder listed in `AppSubfolders`; the folder name no longer has to end in
  `-prj`. Spaces around `AppSubfolders` entries are ignored. See
  [Keep applications in subfolders](HOWTO-app-subfolders.md) (QOPS-758, QOPS-763).

- **Charts from the assistant get a title only when you ask for one, and combo chart lines get their own
  axis** unless your request puts them on the bars' axis (QOPS-743, QOPS-769).

- **Licence activation works in Docker containers on hosts with cgroup v2**, and the Portal and QOps
  commands in one container can check the licence back to back (QOPS-752, QOPS-753).

- **An expired licence is renewed whenever the licence service can be reached** (QOPS-778).

- **`QOps-Deactivate` says when there is nothing to deactivate** (QOPS-775).

- **Qlik Cloud connection errors say why the connection failed.** `Can't validate server` is followed by
  the HTTP status and, for a rejected API key, the setting that holds the key and the `QOps-SetConfig`
  command that stores a new one (QOPS-774).

- **Three switches stop the command where they do not apply**: `QOps-Release -ReloadBeforePublish` outside
  Qlik Cloud, `QOps-Publish -Placeholders` without `-Reload`, and `QOps-Publish -ServiceUrl`. On Qlik Cloud,
  `QOps-Release -ReloadBeforePublish` carries the reloaded data into an application already published in a
  managed space (QOPS-516).

- **Settings saved in the Portal's environment editor are read back reliably** when several screens read
  the configuration at the same time (QOPS-759).

## 3.1.0 — 2026-10-13

### QOps and your AI assistant: the QOps MCP server

QOps now includes an MCP server, so an AI assistant can work with your QOps repositories and Qlik
applications in plain language. It runs on your own machine, uses the connection profiles and licence
you already have, and never passes your Qlik credentials to the assistant. See
[AI Assistants (MCP)](MCP.md).

- Chat in the Portal. A Chat panel, opened from the Dashboard or docked beside the editor in Studio,
  talks to Claude or Gemini with the QOps tools and nothing to connect. Under **Settings → Global →
  Chat** you pick the provider and model and store your own API token, encrypted on this machine.
  Prompt caching is on by default, so long chats use fewer full-price tokens, and **Show token usage**
  adds a line with the tokens each answer used. The provider and model can also be changed for the
  chat you are in, from the provider's own model list.
- Your own assistant. Claude Desktop, Claude Code, Cursor and other MCP clients connect through a
  launcher that `QOps-StartPortal` writes to a fixed place, so the connection keeps working across
  updates.
- QOps operations. The assistant reads your repositories (apps, objects, lineage, load scripts) and
  runs Prepare, Build, Publish and Reload in a repository folder, exactly as the commands do.
- Qlik objects. It creates and changes sheets, charts, master items, variables and load scripts in a
  live application, with a read-only mode, a preview before a change, and one save for several
  changes. After each write it reads the result back and reports a broken expression, a chart that
  cannot draw, or a change that was not stored as sent. Charts cover bar, line, combo, pie, table,
  KPI, scatter, gauge, treemap and pivot table. A catalogue of chart settings lets it change legends,
  labels, axes, sorting, colours, combo series and donut or area styles exactly as Qlik does when you
  change them yourself. On Qlik Cloud it can make a sheet public with `publish_sheet`.
- The MCP-QOps licence. An MCP-QOps licence includes all of QOps and adds the analytic tools, which
  return the data in an application: values, calculated expressions and selections. With a QOps licence
  every other tool works and data values are left out. **Settings → Global → License** shows the
  licence tier. A tool call takes a licence slot only while it runs, so QOps commands can run while
  the assistant keeps an application open.

### Git panel: remote branches, fetch and a 3-way merge editor

The Branches card lists the branches of every remote. You can merge a remote branch into the current
one without switching, check one out as a tracking branch, and **Fetch** to see how far each branch is
behind. A conflicted file opens in a 3-way merge editor, with Current and Incoming side by side and an
editable Result, a choice to accept either side or both for each conflict, and Save marking the file
resolved and staged once no conflict is left.

### Release notes and updates from the Versions panel

The **Versions** panel, opened from the version badge, opens these notes at your installed version,
runs `QOps-Update` after you confirm, and restarts the Portal on the new version at the same address.
It shows the date and hour each Portal was built. `QOps-Update` can use your own GitHub token to stay
clear of GitHub's shared request limit, set with `QOps-SetConfig -GitHubToken` or in the Portal.
`QOps-SetVersion -RestartPortal` restarts a running Portal on the version you switch to, and the Portal
shortcut starts the version QOps last settled on.

### Building into new and existing applications

A folder with no `Id` is built into a new application, and the folder records it, so the next build
updates that application. `QOps-Build -UpdateOnly` builds only into applications that already exist on
the server you are connected to and never creates one, which is the safe first build after a fresh
clone. In the Portal it is **Update only** on Build.

### How-to guides in Help

The Help panel has **How-to Guides**: pages written around a task, such as connecting a fresh clone
to existing applications or setting the applications up on another environment, each with the commands
in order, how to check the result, and what to do when it did not work.

### QOps-Reload saves the task log to a file

On Qlik Sense, `QOps-Reload -LogPath` writes the full log of each task's last run to a file, and the
Portal's Reload status can download it.

### App files are written with only the Space key by default

A repository without a `StreamSerialization` setting now writes only the `Space` key into its app
files. Set `StreamSerialization: Both` to keep writing the older `Stream` key as well. Reading is
unchanged. See [The publish target in the app file](CONFIGURATION.md#the-publish-target-in-the-app-file).

### Fixes

- QOps-Release on Qlik Cloud publishes every sheet marked `Published: true`.
- QOps-Build on Qlik Sense saves again when the Engine reloads the application during the save.
- Uploads that Qlik Sense refuses because too many arrive at once are sent again.
- Publishing to a Qlik Cloud managed space keeps the application's description, and `-Sort Space` works on Qlik Cloud.
- Setting a new licence key works when a previous key is still activated, and on machines where the
  Windows user name differs from the profile folder name.
- QOps runs under PowerShell 7.4, and installing over an older version completes when the Portal was not stopped cleanly.

Work on the Portal and the MCP server continues, and more will come in the next releases.

## 3.0.23 — 2026-10-08

### `QOps-Release` to a shared or personal space keeps the application's Id

When a Qlik Cloud shared or personal space already holds an application with the name you release,
`QOps-Release` now builds into that application in place. It keeps its app Id, so links, schedules,
subscriptions and bookmarks pointing at it stay valid. Nothing is moved into the space and nothing is
removed from it. This is the same rule `QOps-Publish` follows for these spaces.

When the space holds no application with that name yet, the release builds a new one and moves it in.
`Published` in the application's properties file applies to managed spaces only, and releases to
managed spaces work as before. An update in place carries content, not data: add `-Reload` to the
release to refresh it. The details are on the [QOps-Release](COMMAND-release.md) page (QOPS-726).

## 3.0.22 — 2026-10-06

### Faster sheet building with less memory on large applications

`QOps-Build` and `QOps-Publish` now build the sheets of large applications significantly faster and with
significantly less engine memory, on Qlik Sense and Qlik Cloud. This includes updating an application in
place, with `QOps-Build -Inplace` or by publishing into a shared space that already holds it.

If an application is still too large for the tenant's memory limit, the error names the object and the
sheet in plain words and suggests what to do (QOPS-714).

## 3.0.21 — 2026-09-25

### `QOps-Publish` to a shared space keeps the application's Id

When a Qlik Cloud shared space already holds an application of the name you publish,
`QOps-Publish -Force` now updates that application in place: it gets the content of the application
you publish from and keeps its own Id, so links, bookmarks and automations pointing at it keep
working. The application you publish from stays in your personal space, where your next build finds
it; add `-RemoveArtefacts` to remove it. The first publish, into a space with nothing of that name,
still moves the application in.

An update in place carries content, not data: reload the application afterwards, or add `-Reload` to
the publish. Managed spaces and `QOps-Release` work as before. The details are on the
[QOps-Publish](COMMAND-publish.md) page (QOPS-679).

### Choose which app Id a Portal Publish or Reload uses

An application folder can hold two app Ids: the one in `App.local`, which is the app your last build on
this machine wrote to, and the one in `App`, committed to the repository. When they are two different
Qlik app Ids, the Publish and Reload confirmation now offers an **App Id** choice, **Local Id
(App.local)** or **Id (App)**, so you can publish the app you just built into your personal space or move
the app already shared from the repository into another space. The command preview in the dialog shows
the Id your choice resolves to, and the run uses that same Id.

When a folder has only one usable Id, nothing changes and no choice is shown. Defaults are the same as
before: Publish uses Local Id, Reload uses Id (App). Prepare, Build and Release are not affected
(QOPS-661).

### Start Prepare or Build from the Studio file tree

Right-click in the Studio file tree to start an operation. On an application's `-prj` folder the menu
offers **Prepare**, **Build** and **Set local App**; on a folder or a single object file inside it,
**Prepare on path** and **Build on path**, scoped to exactly what you clicked (QOPS-665).

The confirmation opens over Studio, names the application and shows the full command, and the run
leaves you on the document you were reading. Output goes to the log panel; while that panel is
collapsed, a yellow **running** marker at the bottom shows that a run is going. One operation runs at
a time. Set local App still opens the Operations panel, because it needs a second application to map
the folder onto (QOPS-677).

### A scoped Prepare on one file keeps that file

`QOps-Prepare -Path` on a single object file (a variable, a story or a snapshot) refreshes that file.
`Variables/Sales.yaml` and `Variables/Sales` name the same object. Empty folders outside the scope are
left in place. If an earlier scoped run removed such a file, an unscoped run brings it back; the object
itself is still in Qlik (QOPS-672).

### Local paths on the file commands are counted from where you are standing

`QOps-ImportFile`, `QOps-ExportFile` and `QOps-ExportQVF` read a local path the way PowerShell does:
an absolute path as written, a relative path from the folder you are standing in (the one
`Get-Location` reports), and a wildcard against the file names in the one folder you named. Standing
in `C:\repo\loaders`:

    -Path C:\data\Customers.csv    ->  C:\data\Customers.csv
    -Path .\data\Customers.csv     ->  C:\repo\loaders\data\Customers.csv
    -Path data\Customers.csv       ->  the same file, the .\ is optional
    -Path ..\shared\Customers.csv  ->  C:\repo\shared\Customers.csv
    -Path .\data\*.csv             ->  the .csv files in data, not the ones in data\2026

Being inside a repository does not change this: `.qopsconfig` decides where the configuration is read
from, not where a path is counted from. `QOps-ExportFile` without `-Path` still writes into the
repository's folder; write `-Path .` when you mean the folder you are in. More, including `-Root`, in
[Local paths](COMMANDS.md#local-paths) (QOPS-620).

### When Qlik Sense refuses to create an app, the log says who asked and where

If a build on Qlik Sense needs a new app and the server refuses, for example with
`Forbidden [403]:Forbidden(Object write failed.)`, the log file names the app, the server address and
virtual proxy, the user the build connected as and the authentication mode. It also records which
rights Qlik Sense would give that user on a new app of that name, and which license the user holds
(Professional, Analyzer, User access or none): with user-based licensing only a Professional user can
create apps, even when the security rules allow it. Each session also records once which user and
address it connects with. Passwords, tokens and certificate contents are never written (QOPS-680).

### A Qlik Cloud build reads less from the tenant

To find the application a folder belongs to, QOps asks Qlik Cloud for applications only, and for just
that one when the folder records its Id. An application's owner is looked up by that one account. The
build settles on the same application as before (QOPS-650).

### Fixes

- **Application content goes up to Qlik Sense in one request per file**, which halves the calls a build
  makes to upload it (QOPS-629).

- **Two QOps commands can run side by side against Qlik Cloud.** Neither stops with a `LOGO0.jpg ...
  being used by another process` error, and each uploads the content of its own
  application (QOPS-655).

- **`QOps-RemoveExtensions` says that it matches names exactly.** Given `*` or `?`, it explains that the
  name is matched as written and points to `QOps-ShowExtensions -Filter` to list the matches; the
  [extensions reference](COMMAND-extensions.md#filter) says the same (QOPS-623).

- **Reload status takes its flags in the Portal.** `-Wait` and `-ShowLogs` are under Flags / Options,
  so a status query can be saved as a bookmark together with them (QOPS-668).

- **Environment settings scroll when a profile does not fit.** The Connection and Authentication
  cards scroll, while the dialog title, the profile's name bar and the Close / Save changes buttons
  stay in view. The Global area behaves the same way (QOPS-687).

## 3.0.20 — 2026-09-22

### Reloads you can start in one run and check in another

`QOps-Reload -Detached` works against Qlik Cloud. The run hands every selected application's reload
to the tenant and returns as soon as they are accepted, a row per application with the reload id and
its state. `-Wait` holds until they finish. `QOps-Reload -Status` answers in a later run without
starting anything, and `-ShowLogs N` returns the last N lines for anything that failed — on Qlik Cloud
without needing `-Wait`. The states read the same as on Qlik Sense, and an application the tenant has
never reloaded reports `NeverStarted`; the [command reference](COMMAND-reload.md#status) has the table
(QOPS-621).

In the Portal that pair is **Operations → Reload** and **Operations → Reload status**. Reload status is
a button of its own because it starts nothing: you can ask while a reload is still running (QOPS-621).

`-Timeout <seconds>` sets how long one run waits, on both platforms; `ReloadTimeoutSeconds` in
`.qopsconfig` sets it for the repository, and `-Timeout` takes precedence — see
[Configuration](CONFIGURATION.md). Waiting is all it governs: when the time runs out nothing is
cancelled, the reload carries on, and the run names the reload id so you can ask about it afterwards.
Such a reload reports as **Unfinished** — neither a failure nor a success, so pipelines and the Portal
treat it as unconfirmed (QOPS-646, QOPS-663).

### Folders inside a Qlik Cloud space

`QOps-ImportFile`, `QOps-ExportFile` and `QOps-RemoveFile` all take `-QlikPath`, the folder inside the
space to work in. Name it and `-File` may be the plain file name, and the command touches nothing
outside that folder — worth having on `QOps-RemoveFile`, where a pattern otherwise reaches every folder
in the space. On `QOps-ImportFile` this parameter was `-TargetPath` in 3.0.18; that spelling still
works as an alias, so nothing written against the older release needs changing (QOPS-638).

`QOps-ImportFile -Root` takes a whole tree and keeps its shape: `-Path` is matched against each file's
path relative to the root, and each file lands in `-QlikPath` plus its own folder.

    QOps-ImportFile -Space Sales -Root .\data -Path *.csv -QlikPath Extracts

    .\data\a.csv         ->  Extracts/a.csv
    .\data\2026\b.csv    ->  Extracts/2026/b.csv

That completes the round trip: export a set of files, change one, import them back, and each returns
to the folder it came from — at every level of the tree, replacing rather than duplicating. Without
`-Root` one folder is read, as before. The [command reference](COMMAND-importfile.md) has both
(QOPS-642).

In the Portal the folder field is on all three commands, and **Import file** also offers **Root**.

On an export the folder you name is not repeated on disk: with `-QlikPath archive`,
`archive/2025/sales.qvd` is written to `<-Path>\2025\sales.qvd`, which is what makes `-QlikPath` out
and `-Root` back inverses of each other.

### Publishing into a shared or managed space

Edit, build, publish now delivers to a **shared** space as it does to a managed one.
[QOps-Publish](COMMAND-publish.md) refuses a name the space already holds and says so — add `-Force`
to replace; [QOps-Release](COMMAND-release.md) replaces it (QOPS-649). Two things are worth knowing.
The application that arrives in a shared space has a **different id** from the one it replaces, so
anything addressing the previous copy by id — a link, a task, a bookmark — needs pointing at the new
one. And where a space already holds several applications of one name, a publish replaces one of them
and says how many it left; the rest are yours to delete.

A publish whose `-Filter` names an application that is already in the target space now stops and names
both it and the one in your personal space that your last build wrote to. Take the id it names — QOps
records it in `App.local` — and publish that (QOPS-652).

From the Portal: **Build**, then **Publish**. Publish takes the application id from the folder's
`App.local`, falling back to its `App` file (QOPS-654). Where a build writes has not changed, and the
[QOps-Build](COMMAND-build.md) page now has a section on shared and managed spaces (QOPS-225).

### Pointing a folder at the application it means on this environment

The Operations panel has a **Set local App** button. It runs
[QOps-SetLocalApp](COMMAND-setlocalapp.md), which is what you reach for after cloning a repository onto
an environment where the applications already exist under different ids: it records, for this machine
only, which application each folder works on. The target is chosen from a list of the applications on
the environment you are connected to, never typed (QOPS-602).

### Fixes

- **`QOps-Publish` run without `-Filter` says what it needs**, and shows the shape to pass, instead of
  reporting nothing found. It takes the application, the name and the target space from `-Filter` and
  does not use the filter saved in `.qopsconfig` (QOPS-653).

- **Housekeeping no longer interrupts the command you ran.** The daily tidy of the log folder leaves
  alone any file something is still writing to, and finishes the rest instead of stopping at the first
  it cannot remove (QOPS-648).

- **Preparing straight after a build leaves untouched sheets alone**, so a routine build-then-prepare
  no longer leaves a diff that says nothing about the application (QOPS-647).

- **An extension whose `.qext` is not valid UTF-8 is refused before anything is uploaded**, naming the
  file and the byte; the extension already on the server is left as it is, and a byte order mark
  survives the rewrite. If you built such an extension previously, its text on the server is worth a
  look — convert the file to UTF-8 and build again (QOPS-626).

## 3.0.19 — 2026-09-18

### A private sheet stays private when you build to Qlik Cloud

Building an application no longer makes its private sheets public.

A build rewrites the sheets in the application it writes to. Reading that application back afterwards
recorded every rebuilt sheet as published, whatever it actually was, and the next build then published
it for real. So the sequence build, prepare, build turned a sheet you had kept to yourself into one
everybody with the application can see, without anyone asking for it (QOPS-641).

If a repository already holds `Published: true` for a sheet that should be private, prepare the
application once more and commit the result **before your next build**: the values written now are
the ones the tenant actually reports.

The order is the whole of it. Build first and those sheets are published on the tenant for real — and
a prepare after that records them as published, correctly, so the repository and the tenant end up
agreeing on a state nobody chose. Sheets prepared by QOps 3.0.16 or earlier are the ones worth
checking; [Sheet visibility on Qlik Cloud](COMMAND-build.md#sheet-visibility-on-qlik-cloud) says which
applications each version affected (QOPS-640).

---

## 3.0.18 — 2026-09-18

### Importing a data file into a folder

`QOps-ImportFile` takes a new optional `-TargetPath`, so a file can go into a folder inside the space
instead of its top level:

    QOps-ImportFile -Space Sales -Path .\data\*.csv -TargetPath Extracts/Daily

One destination for the whole command — every file `-Path` matches lands there, and folders that do
not exist yet are created on the way. The local folder structure is not copied across: `-Path` chooses
the files, `-TargetPath` chooses where they land. A file already in that folder is replaced, the same
way it already is at the top level, so re-running an import stays the same command each time.

Without `-TargetPath` nothing changes: files go to the top level of the space exactly as before.

Give the folder on its own, relative to the space — `Extracts/Daily`, not the `Space:DataFiles/...`
form from a load script. That prefix would otherwise be taken as a folder name, so the command refuses
it and says which shape to use (QOPS-637).

---

## 3.0.17 — 2026-09-17

### Connecting to Qlik Cloud with an OAuth client

A profile can authenticate with an OAuth client instead of a per-tenant API key. Set
`-SenseAuthMode QlikCloudOrg` and give the profile the client id and secret; QOps exchanges them for
an access token against the tenant and renews it before it expires, holding it in memory for the
length of the run and never writing it to disk (QOPS-244).

Create the client under **OAuth** in the Qlik Cloud management console and give it the **trusted**
consent method — without it the tenant refuses to issue a token. Any client type that issues a secret
will do. The client is a subject of its own, so it lists the applications it has been granted access
to and nothing else. The
[configuration reference](CONFIGURATION.md#qlik-cloud-with-an-oauth-client) has the fields and an
example.

Where a token cannot be issued, QOps now reports what the tenant answered rather than listing what
might be wrong (QOPS-615).

A Qlik Cloud profile in the Portal's environment editor now chooses between **ApiKey** and
**QlikCloudOrg**, the same two names `QOps-Configure` offers. Choosing `QlikCloudOrg` asks for the
OAuth client id and secret instead of an API key; the secret is write-only, as the other credentials
are, so the editor shows only whether one is stored (QOPS-616).

### Saving a command with its flags

The same command is often run two or three settled ways. A **bookmark** is one of those ways, saved:
a command, the flags you had set on it, and a name you choose. Set the flags under **Flags /
Options**, open **Bookmarks** beside that heading and name them; the bookmark then pins to the panel
like any other button and runs that command with those flags (QOPS-571). Pinning and unpinning a
bookmark happens in that same **Bookmarks** dialog; **All commands** lists commands, and says how
many of your pins are bookmarks so the count there adds up.

A flag the command does not take is refused when you save it, and the message says which — a saved
entry is run later and often by somebody who did not make it, so that is the moment to say so. The
[Commands reference](COMMANDS.md#saving-a-command-with-its-flags) has the rest, including where they
are kept: beside your pinned commands, outside the Portal directory, so they survive an update.

### The Portal has one health endpoint

`GET /api/v2/health` is now the only health route. The unversioned `GET /health` and
`GET /api/v2/health/detailed` were removed on 2026-09-17, the date they had been announcing in
their `Sunset` header since the deprecation. Both returned the same body as the surviving route,
so a caller that switches reads exactly what it read before (QOPS-419).

If something still calls one of them it now gets a 404. The replacement is a straight substitution
of the path. One thing to check if you are moving off `/api/v2/health/detailed`: its dependency
keys were `pwsh` and `qops`, and on `/api/v2/health` they are `powershell` and `qops-module`.

### Fixes

- **The order of keys in a file does not depend on the machine.** Sorting no longer follows the
  machine's language settings, so a repository written on any Windows language — and from either
  edition of PowerShell — serializes the same way (QOPS-579).

- **A command that writes to its output and its error stream at the same instant is collected
  safely**, and the run it belongs to carries on (QOPS-614).

- **Each operation runs with the flags you set for it.** Every run, preview and confirmation reads
  the flags belonging to the operation you pressed (QOPS-627).

- **Sheets keep their published state when you build to Qlik Cloud.** A sheet the repository holds as
  published is published in the application the build writes to, rather than arriving private — see
  [Sheet visibility on Qlik Cloud](COMMAND-build.md#sheet-visibility-on-qlik-cloud) (QOPS-633).

- **Request and response detail in the log is now behind `-VerboseLog`.** A default run logs the
  summary lines only, so a log is shorter than you may be used to; add the flag to get the detail
  back (QOPS-634).

## 3.0.16 — 2026-09-14

### Sheets follow the same version policy as other objects

`QOps-Prepare` rewrites a sheet file only when the sheet itself differs, the way it already did for
every other application object. Updating QOps changes no sheet file on its own (QOPS-610).

Further [fields that must not cause a rewrite](COMMAND-prepare.md#fields-that-must-not-cause-a-rewrite)
can be named: add `IgnoreFieldsOnCompare` to `.qopsconfig` with a list of field names.

---

## 3.0.15 — 2026-09-11

### Creating an application from the Operations panel

Build in the Operations panel has a **New** switch, matching `-New` on the command line. Turn it on to
create new Qlik applications for folders with missing or unmatched `Id`s; folders whose application is
already on your Qlik are skipped, each with a line saying so, so the run never writes into an
application that is already there. Leave the switch off and the run is an ordinary build: existing
applications are built and a folder naming no `Id` is skipped. Either way, every app you selected
reports what happened to it (QOPS-530).

Creating an application also **records an `Id` in `App.yaml`/`App.json` if it was missing or empty**,
so `QOps-Prepare`, `QOps-Reload`, a release and the Portal all address it from then on like any other
application. The value recorded is the repository's own identity - the project folder name - rather
than the Qlik application id: the Qlik id stays in `App.local`, where each
environment keeps its own, so a repository that creates an application is not tied to the Qlik it was
created on. Only the `Id` field is written — the rest of the file, including its line endings, is left
exactly as it was (QOPS-593).

### Updating no longer depends on the licence check

`QOps-Update` installs the new version whether or not the licence checks out. Where the check fails,
or cannot run at all, the run says which of the two happened and carries on:

    QOps-Update: license check failed. License is invalid: the license has expired. The update runs
    anyway: QOps-Update does not require a license. Other commands do - run QOps-Activate to restore
    them.

Every other command still checks the licence for itself, so this changes what you can update, not
what you can do (QOPS-247).

### Configuration and setup

- **The configuration wizard is safe to step through and safe to decline.** Pressing Enter at the
  certificate step keeps the value you already have, exactly as the prompt offers; a path that does
  not exist says so. Pressing Enter at the first step declines the wizard and leaves your
  configuration untouched (QOPS-604, QOPS-585).

- **A missing profile is reported immediately, and names the file that asked for it** — so you know
  which configuration to fix rather than which command to rerun (QOPS-584).

- **Your `.gitignore` keeps the rules QOps did not put there.** Both the `.qopsconfig` rule handling
  and `QOps-Pull` now touch only what they are about: rules that merely share a prefix stay, the file
  survives attaching an origin remote, and it is restored on every path — including one where the
  pull does not complete. Each says in one line what it did (QOPS-562, QOPS-563).

### Qlik Cloud and engine

- **App descriptions behave like ordinary text.** A description can be cleared as well as changed, it
  no longer grows a line break on each save, and quotes in it arrive intact (QOPS-545, QOPS-597).

- **Connection problems name the setting to change.** An expired or wrong Qlik Cloud key names the
  API key setting and the command that replaces it, and connecting to Qlik Sense without a `SenseUrl`
  says that is what is missing — on both the repository and the engine connection (QOPS-402,
  QOPS-586).

### Commands and output

- **An empty result says which kind of empty it was.** `Nothing found` now distinguishes "no app
  projects here" from "projects are here, the filter matched none", names the scan root, and — where
  nothing was found at all — says that a folder holding `App.json`/`App.yaml` must be a direct child
  of the repository root or of an `AppSubfolders` entry (QOPS-528).

- **A refusal reads as a refusal.** `QOps-ExportFile` says why it declined instead of returning the
  silence that looks like a search with no matches (QOPS-578).

- **A command with no `-Filter` tells you what it will act on.** Reading and writing answer that
  differently, on purpose. `QOps-ShowExtensions` with no filter now lists every extension, instead of
  stopping at a repository filter that may never have been set and reporting nothing found. A write
  command still uses the filter saved in the repository, and where none is saved it touches nothing
  and says so, rather than reporting success having done nothing - pass `-Filter *` when you do mean
  all of them. A write that skips one names it and says why (QOPS-590).

- **What QOps writes can be read back.** An extension file whose bytes it cannot decode is refused
  before anything is changed, rather than uploaded with the undecodable parts replaced; and YAML
  strings containing tabs are quoted, so strict parsers accept them (QOPS-577, QOPS-576).

- **`QOps-Update` reports a failed file list** and tells you the update server did not answer, instead
  of ending on an unexplained error (QOPS-589).

---

## 3.0.14 — 2026-09-04

### Data files in a Qlik Cloud space: put them in, take them out, remove them

Three commands work on the data files a script loads with `lib://<space>:DataFiles/<file>`.

    QOps-ImportFile -Space Sales -Path .\data\*.csv
    QOps-ExportFile -Space Sales -File Customers.qvd -Path .\data
    QOps-RemoveFile -Space Sales -File old-*.qvd

All three take a name or a pattern, so a folder of extracts goes up, or a set comes down, in one
command. An import replaces a name already in the space in place, so re-running it after a change is
the same command each time; where the tenant will say which extensions it accepts, it checks first
rather than spending a long upload on a file that was never going to be kept.

An export writes a file only after its length matches the size the space reports, so a short export
never arrives looking complete. A name already taken on disk is reported `Skipped` and left alone —
`-Force` replaces it. `Skipped` is a third result alongside `Done` and `Failed`, so a script has a
value to filter on. Large files come down in pieces; several hundred megabytes takes minutes.

`QOps-RemoveFile` deletes in Qlik without asking and puts nothing on your disk; if you want a copy,
that is `QOps-ExportFile`. All three are Qlik Cloud only:
[Import](COMMAND-importfile.md) · [Export](COMMAND-exportfile.md) · [Remove](COMMAND-removefile.md)
(QOPS-536, QOPS-537).

### Data connections from a Qlik Cloud tenant

`QOps-PrepareDataConnections` now reads a Qlik Cloud tenant as well as a Qlik Sense site, and writes
one folder per connection under `DataConnections`, so the definitions travel with the rest of the
project. The connection each space carries for its own data files is left out, and the run says how
many.

Where the account may not read a particular connection, the run carries on through the others: that
one is named with the reason the server gave and comes back as `Failed` beside the ones that
succeeded. This holds on Qlik Cloud and on Qlik Sense.

This is the reading half. `QOps-BuildDataConnections` still declines a tenant and says so — it talks
to the on-premise service directly. See [data connections](COMMAND-dataconnections.md)
(QOPS-539, QOPS-569).

### Build or prepare one part of an application

`QOps-Build` and `QOps-Prepare` take a `-Path` and then act only on the objects under it — a folder
(`Dimensions`), one object (`Sheets/<id>`), or a pattern (`Variables/v*`). Everything outside it is
left as it is, on the server and on disk.

On a build the path is also a delete instruction: an object you deleted on disk inside the path is
deleted in the app, while objects outside it are untouched. A scoped build acts on an application
that already exists — it never creates one and never leaves a copy behind — and where it cannot, it
is skipped with the reason. The description and thumbnail live in `App.yaml`, outside every object
folder, so a scoped run leaves them alone unless you name that file.

`-Path` applies to Qlik Sense and Qlik Cloud; on QlikView it is refused with a message rather than
accepted and ignored. Full rules:
[scoping a prepare](COMMAND-prepare.md#scoping-a-prepare-to-part-of-an-application) and
[building one part of an application](COMMAND-build.md#building-one-part-of-an-application)
(QOPS-210, QOPS-520).

### All of it from the Portal, with the buttons you choose

The Operations panel used to run five commands. It now runs twelve — the three data-file commands,
the four data-connection commands, and `-Path` on Build and Prepare — and which of them get a button
is your decision. **All commands** opens the full list, and anything in it runs straight from the
list whether or not it is pinned. Up to nine are pinned at a time; a new installation starts with
**Add App**, **Prepare**, **Build** and **Release**.

Commands that do not work on applications ask for what they need in a dialog and show the exact
command before it runs. Two say something extra first, because you cannot see it otherwise:
**Remove file** deletes in Qlik immediately, and **Add connections** runs two commands when you
leave the filter empty, because only then does the second read what the first found. For a scoped
run the panel shows what the scope implies: while a path is set, **In-place** is on and cannot be
changed, and the command preview carries it.

The ⓘ beside a command opens that command's flags underneath it — that command's only — and closes
again without moving anything else, so a half-filled dialog stays as you left it. Every command has
its own reference page, reachable from there and from the [Commands](COMMANDS.md) index. The dialog
opens at a width that follows your display and can be dragged wider; the width is remembered.

Your pinned set is kept per account in `%USERPROFILE%\qopsconfig\portal.settings.json`, outside the
Portal's own folder, so it survives a restart and an update (QOPS-525, QOPS-527, QOPS-570).

### Changes to behaviour you may be relying on

**A command that only connects leaves no configuration file behind.** `QOps-Prepare` writes a
`.qopsconfig` where you run it, because that file is what makes the folder a project. A command that
connects and prints — `QOps-Apps` and its kind — no longer does: it keeps what it needs for the
session in memory and leaves the folder as it found it. Inside a repository that already has one,
the file keeps being updated exactly as before (QOPS-582).

**Changing the line-ending setting now applies it to the configuration file itself**, so the file
carrying the choice is written in the endings it names. Where no EOL Format is configured at either
level, saving settings leaves the file terminated the way it already was (QOPS-507).

**A licence folder QOps cannot reach no longer stops the command.** Where the folder holding the
licence cannot be read or written, the command continues and names the path and the reason. Commands
that genuinely cannot proceed without the licence still stop, and now name the folder as well
(QOPS-508).

### Also in this release

Security improvements, bug fixes, and clearer error messages across the Portal and the module.

---

---

## 3.0.13 — 2026-08-24

### Merge a branch from the Portal, and resolve the conflicts there

The Git panel merges another branch into the one you have checked out. Pick the branch and the
Portal says what happened: merged, already up to date, or stopped on conflicts with the conflicted
files named.

Conflicts are resolved in the Diff panel, which offers **Keep current**, **Keep incoming** and
**Keep both** on each one. A merge can also be abandoned from the Git panel, which puts the
repository back where it was before the merge began (QOPS-408).

### Stop the Portal from the browser

The Dashboard has a **Shut down Portal** control, so you can stop it without the command line — while
it runs it holds a port and an open API. The page you were on says the Portal has stopped, that your
repositories on disk are untouched, and gives you the command to start it again. On Windows the Start
menu and Desktop shortcuts, if you let the installer create them, start it again without the command
line too (QOPS-414).

### Git. The Changes header covers more categories

The **Changes** header in the Git panel badges every category it counts — conflicted, modified,
untracked, staged, deleted and renamed — so a glance at the header tells you what the total is made
of, and the badges carry the colour coding along with the conflict count (QOPS-431).

### macOS: an uninstaller

The macOS package ships an uninstaller, `uninstall-qops.sh`, in the module directory it removes, and
the installer offers to start the Portal when it finishes (QOPS-420).

### Saving a file from the Portal keeps the repository's line endings

A file you save in the Portal — from the editor, from the file browser, or through replace-in-search —
now gets the line endings the repository is configured for, the same ones the cmdlets write. How the
style is chosen is in [Line endings](CONFIGURATION.md#line-endings) (QOPS-500).

### The app file has one publish target, and a setting for how it is written

`Stream` and `Space` in the app file are one value — set either name and both carry it, and filters
and sorting accept either spelling. Which keys are written is now a repository setting,
`StreamSerialization`: `Both`, which is how a repository configured before this release behaves, or
`Space`. Reading is unchanged and has no end date. Full description in
[The publish target in the app file](CONFIGURATION.md#the-publish-target-in-the-app-file), on the new
[Configuration](CONFIGURATION.md) page that lists every `.qopsconfig` field and the command that sets
it (QOPS-92).

### One health endpoint, and two deprecated aliases

`GET /api/v2/health` is the health check, and every dependency it reports now carries the path it was
found at as well as its version. `GET /health` and `GET /api/v2/health/detailed` still answer and
return the same response, but they are deprecated and are **removed on 2026-09-17**; both send
`Deprecation`, `Sunset` and `Link` headers. Endpoint and response in
[Health](API-v2-reference.md#health) (QOPS-418).

### Reliability

- **Starting the Portal writes no configuration file.** `QOps-StartPortal` reports your licence state
  without creating anything — not in the directory you are standing in, not in your user profile
  (QOPS-479).

- **QOps no longer leaves an empty `.qopshooks` folder in the directory you ran a command from**
  (QOPS-506).

### Also in this release

Security improvements, bug fixes, and clearer error messages across the Portal, the installer and the
module.

---

## 3.0.12 — 2026-08-13

### Edit a diff in Studio

Studio has a **Diff editing** view: the file opens as two panes, the base version on the left and your
working file on the right, where you type. Review a change and edit it in the same place. The panes
scroll together and unchanged code stays opposite itself, so the only lines that move are the ones you
changed.

Open it from the **Edit** button on a file in the Diff panel, or from the status letter beside a
changed file in the Studio file tree. The **Editor / Diff editing** toggle switches an open tab
between the two views and carries your unsaved edits across.

Beside every changed block there are two buttons. **Revert block** puts that block back to the
committed version in your buffer — nothing on disk or in git moves, and `Ctrl+Z` undoes it.
**Save and Stage block** writes that one block to the file and stages it, leaving your other unsaved
edits alone; the tab stays marked unsaved for them, so staging one block does not quietly commit you
to the rest.

**Compare** picks which two versions you are looking at. It opens on *Unstaged (worktree vs index)*,
which is the editable one — stage a block and it leaves the comparison, so what remains on screen is
what you still have to do. *Staged* and *Working tree (all uncommitted)* are for reading and are
marked read-only; the ⓘ beside that marker explains why. Switching Compare never touches your unsaved
edits (QOPS-302).

### The Portal opens without a licence

`QOps-StartPortal` opens the Portal on a machine whose licence has not been activated yet, so the
screen where you enter the licence serial is reachable from the first run — no command line needed to
get licensed.

Without a licence it takes you straight to the panel where the serial is entered and the machine-wide
settings live, and **Dashboard, Settings and Help stay usable** — so
you can look around, read the documentation, and get licensed, all from inside the product. Setting
the serial is the only step: a machine activates itself on the first command that runs.

Everything else waits for the licence. Studio, Operations, Git, Diff, Lineage, Logs, Search and the
Editor show a licence screen in place of their contents, giving the actual reason — no serial set,
expired, refused by the licence service — and a button that opens the licence settings. Their
navigation entries carry a padlock and still take you to that screen, so nothing in the Portal is a
dead click. Once the licence is in place they open without a restart.

The operations themselves are unchanged and still licensed exactly as before. Prepare, Build, Reload,
Publish, Release and every other cmdlet check the licence themselves, so an unlicensed machine cannot
run them from the Portal any more than it could from a prompt. What changed is what you are told when
one refuses: instead of a raw error about an internal licence check, you get a sentence naming the
licence and a way to fix it (QOPS-407).

If the Portal cannot determine the licence state at all — the QOps module is missing from PowerShell's
module path, say — nothing is locked. A machine that cannot answer the question is not treated as an
unlicensed one.

### Starting the Portal without a command line

The Windows installer adds a **QOps Portal** entry to the Start menu and an icon on the Desktop, so
getting in takes a click rather than a PowerShell prompt. Either one starts the Portal and opens it in
your browser, and clicking it again while the Portal is already running opens the browser on the
running one rather than flashing a console window at you (QOPS-329).

Each of those is a question now, not a decision made for you. The wizard has a page for them: a box
for the Start menu shortcut, a box for the Desktop shortcut, and a box for opening the Portal as soon
as setup finishes. All three start ticked, so clicking through the wizard gives what it always gave;
clear any of them and setup leaves that part out. The shortcuts themselves are unchanged — the same
Portal, on the same port, started the same way (QOPS-413).

An unattended install is deliberately not the same, because nobody is sitting in front of it to have
cleared a box or to see a browser open. `msiexec /qn` on its own creates both shortcuts and does not
open the Portal. Each part can be named on the command line, including asking for the browser anyway:

```powershell
msiexec /i QOps-setup.msi /qn                             # both shortcuts, no browser
msiexec /i QOps-setup.msi /qn INSTALLSTARTMENUSHORTCUT=0  # no Start menu shortcut
msiexec /i QOps-setup.msi /qn INSTALLDESKTOPSHORTCUT=0    # no Desktop shortcut
msiexec /i QOps-setup.msi /qn LAUNCHPORTAL=2              # open the Portal when the install ends
```

Uninstall takes back whatever was created and has nothing to take back for anything that was
declined. All of it applies whether QOps is installed for everyone on the machine or only for you.

### Host address restrictions in the Portal

The Portal processes requests only for the hostnames and IP addresses it is configured for, and answers
`400 Bad Request` to any other address.

#### Default configuration

These are accepted out of the box, with nothing to set up:

- `localhost`
- `127.0.0.1`
- `[::1]`
- the machine's own hostname

So `QOps-StartPortal` and `http://localhost:5555` behave exactly as before.

#### Adding your own hostname or DNS alias

If you reach the Portal at some other address inside your network — a server name or a DNS alias — add
that name to `%USERPROFILE%\qopsconfig\portal.settings.json` and restart the Portal:

```json
{
  "AllowedHosts": "localhost;127.0.0.1;[::1];qops.example.com"
}
```

#### Two rules worth knowing before you edit it

- **Each name is matched exactly.** `localhost` and `127.0.0.1` are separate entries, so a list
  containing only `localhost` answers `400` to `http://127.0.0.1:5555` — which reads as the Portal
  being down (QOPS-438).
- **Your value replaces the shipped list, it does not add to it.** Keep the loopback names and append
  your own address to them (QOPS-438).

#### Where the value is read from

`AllowedHosts` is read from `portal.settings.json`, and that file survives `QOps-Update`. Settings are
applied in order: `appsettings.json`, then `portal.settings.json`, then an environment variable, then
the command line (QOPS-438).

### The Portal port can be set once instead of every time

If 5555 is taken on your machine, or you simply want the Portal somewhere else, put the port in
`%USERPROFILE%\qopsconfig\portal.settings.json` and it sticks — no `-Port` to remember on each start:

```json
{
  "Portal": {
    "Port": 8080
  }
}
```

`QOps-StartPortal` with no arguments now starts there and opens `http://localhost:8080`; so do the
Start menu and Desktop shortcuts, which have no command line to put a port on. `-Port` still wins
whenever you pass it, including `-Port 5555` — what counts is that you typed it, not the number. A
port in that file that cannot be used (not a number, or outside 1–65535) is reported and the Portal
starts on 5555 rather than leaving you to work out what happened.

This is the same file that already held the allowed browser origins, and it is deliberately not inside
the Portal folder: `QOps-Update` rebuilds that folder from scratch, so settings kept there disappear at
the next update.

**Removed:** the `Urls` key in the Portal's own `appsettings.json`. It had no effect when the Portal was
started with `QOps-StartPortal`, so it is gone rather than left to mislead. Set the port in
`portal.settings.json` instead.

---

## 3.0.11 — 2026-08-07

QOps 3.0.11 ships with Portal 1.0.1.

Three things change how the product feels. QOps and the Portal now run on macOS and Linux, not only on
Windows. Panels in the Portal dock beside each other instead of covering the screen you were working
on. And a long operation is no longer killed for being long. There is also a new cmdlet,
`QOps-SetUpdateChannel`, which decides which build a machine updates from.

### QOps and the Portal now run on macOS and Linux

Previous releases were Windows-only in practice, and failed in different ways on each of the other two
platforms. On macOS every cmdlet threw `PlatformNotSupportedException` before doing anything
(QOPS-364), and `QOps-StartPortal` failed with `Exec format error` because the package carried a Linux
binary only (QOPS-379). On Linux the Portal started but served no interface at all: `Portal.zip`
unpacked flat, so there was no `wwwroot` for the UI and no `docs` for the Help panel (QOPS-382). On
both, every repository screen answered a 500 unless the Portal ran as root, because QOps kept its
Portal data in a system directory (QOPS-389).

All of that is fixed. The full flow — `QOps-SetLicense`, `QOps-SetConfig`, adding a repository,
Prepare, Build, Publish, Reload and Release — works on macOS and Linux against both Qlik Cloud and
Qlik Sense on-prem, and `QOps-StartPortal` brings up the Portal with its interface and its Help.
Related fixes in the same area:

- **`QOps-Update -Force` works off Windows** (QOPS-372), and an update installs into the folder `pwsh`
  actually searches. On macOS the path was being built as `~/Library/Application Support`, so an
  update could report success and leave the old module in place (QOPS-392).
- **The browser opens once the Portal is listening**, rather than being handed the URL while the port
  is still dead and showing "cannot open the page" for a Portal that is starting perfectly well
  (QOPS-394).

macOS now has an installer of its own: `QOps-3.0.11-macos-arm64.pkg`, for Apple silicon. It puts the
module where `pwsh` looks for it and the Portal beside it, inside your home folder, with no
administrator password.

Starting it takes one step in the Terminal, and the reason is worth stating rather than leaving to be
discovered: the package carries no Apple Developer ID signature, so Gatekeeper refuses a plain
double-click on a file that arrived through a browser. Either clear the download flag first and then
double-click, or install without opening Finder at all.

```bash
xattr -d com.apple.quarantine QOps-3.0.11-macos-arm64.pkg   # then double-click

installer -pkg QOps-3.0.11-macos-arm64.pkg -target CurrentUserHomeDirectory
```

Both routes install the same thing. The refusal is what an unsigned package looks like, not a damaged
download, and the console step goes away once the package is signed (QOPS-406).

If an older QOps is already on a Mac, install the package rather than running `QOps-Update`: no release
before 3.0.11 can execute a cmdlet on macOS (QOPS-364), and no package built before it carries the Mac
build of the Portal (QOPS-379). From 3.0.11 on, `QOps-Update` keeps a Mac current like any other
machine.

One limitation remains on macOS, named here rather than left to be discovered:

- **Licensing another user throws** (QOPS-374). `QOps-SetLicense <key>` for yourself works; passing
  `-User <someone-else>` raises `NotSupportedException`, and the same applies to `QOps-Activate` and
  `QOps-Deactivate`. Single-user setup — the normal case — is unaffected.

### The Portal workspace

- **Panels dock instead of taking over the screen.** Diff opens as a right-hand panel next to Git
  rather than a separate screen (QOPS-299); Logs dock to the right of Operations so you watch the
  stream while it runs (QOPS-300), and below Studio when height is what you need (QOPS-303). Search in
  Studio is a docked panel instead of an overlay that closed on every click (QOPS-301). Two bottom
  panels sit side by side, and fall back to tabs on a narrow window without losing either (QOPS-333).
- **Choose a repository folder instead of typing its path.** The picker browses the machine, validates
  as you go, and distinguishes three kinds of folder — a QOps repository, a plain Git repository, and
  one already added — rather than calling everything "repo" (QOPS-316, QOPS-323, QOPS-325).
- **Editor tabs tell files apart.** Two files with the same name now show enough of their folder to
  distinguish them (QOPS-322).
- **Versions are visible from inside the Portal.** The QOps version sits in the status bar, and the
  badge at the right of the header opens a panel showing the Portal and the installed QOps module
  together, wired to `QOps-Update` (QOPS-324).

### Operations you can trust

- **A long operation is no longer killed for being long.** Release was being killed at 6.5 minutes for
  one app and 11 for two — and the estimate behind that limit averaged only runs that completed, so
  the runs it had just killed never entered the history and it never learned they needed longer. The
  estimate now learns from real durations (QOPS-318), and passing it produces a warning plus a Stop
  button rather than a kill — the decision is yours (QOPS-362).
- **The Stop button survives leaving the panel.** Going Operations → Logs → Operations while something
  was running lost the "Operation in progress" card and the Stop button with it: output kept streaming
  and history kept its spinner, so the panel showed a running operation it gave you no way to stop.
  The card now comes back, with its estimate and an elapsed counter that continues from when the
  operation started instead of restarting at zero (QOPS-368).
- **Git commands are serialised per repository.** Nothing stopped two git commands running in the same
  work tree at once, while the interface polled git every five seconds. That is where the
  `.git/index.lock` failures came from. Commands in one repository now run one at a time, and when a
  lock does appear the message says what it can still mean (QOPS-319).
- **Git is faster.** A checkout used to start nine separate PowerShell processes at roughly 400 ms
  each; simple git commands now run directly (QOPS-317).
- **History records what actually ran.** It used to say "All apps" based on the state of the
  checkboxes rather than on what the operation targeted (QOPS-309).
- **Output stays with its repository.** A finished operation's output no longer leaks into another
  repository's panel (QOPS-305).
- **Saving in the editor refreshes the documentation for every app you touched**, not just the last
  one (QOPS-304).
- **Log wording and colouring corrected** — "error" that was not an error, and colours that did not
  match severity (QOPS-311, QOPS-330).

### Choosing which build you update from — new cmdlet `QOps-SetUpdateChannel`

`QOps-Update` could reach exactly two builds: stable, and `-Beta` for staging. Every other published
channel was unreachable. There are now two ways to name one, and the difference between them is the
whole point:

```powershell
QOps-Update -Channel staging-mcp     # install from that channel, THIS RUN only
QOps-SetUpdateChannel staging-mcp    # switch this machine to it, until you set it again
QOps-SetUpdateChannel main           # back to the supported 3.x line
```

`QOps-SetUpdateChannel` is a cmdlet of its own rather than another flag on `QOps-Update`, because in
QOps a flag means "for this run". Once set, every update follows that channel, including the daily
automatic one. The choice belongs to the machine — which build of QOps you are running — and not to a
profile, which is about which Qlik you point at, so it is stored beside the other per-machine update
markers rather than in a config profile.

`-Beta` keeps the meaning it always had: staging for one run, with no lasting effect. It will not drag
a machine you switched on purpose back to staging — on such a machine, ask for staging by name
(`-Channel staging`). Every update logs the channel it used and where that came from: asked for this
run, set on this machine, `-Beta`, or the default.

Two names are special. **`main` means the supported 3.x line.** The 2.x builds are published to a
branch literally called `main`, so the most natural word to type would have dropped an up-to-date
install back onto the frozen line. That downgrade now has to be asked for by name, as **`main-2.x`**,
and asking warns you that the channel is frozen and stops serving updates and fixes on 2027-02-01. An
installed 2.x keeps working — only the updates end (QOPS-378).

Going back to 2.x is not a supported path, and one thing about it is worth knowing before you try it:
3.x writes its config as YAML, 2.x reads JSON only, so every 2.x command afterwards fails with
`Unexpected character encountered while parsing value: A` — a message that names neither the file nor
the format. Delete the `.qopsconfig` files (the repository's, and the one in `%USERPROFILE%\qopsconfig`,
keeping `license.key` beside it) and 2.x writes itself a fresh one.

### Reliability

- **Errors reach the Logs panel.** The step that labels output matched the stream name in the wrong
  case, so every PowerShell error record was dropped on its way to the Portal — a command that failed
  looked like one that printed nothing. All platforms (QOPS-393).
- **The Portal no longer freezes after a few pages of logging.** `QOps-StartPortal` captured the
  Portal's output and then never read it, so once roughly 64 KB had built up the Portal blocked on its
  next log write and stayed blocked — and the log went nowhere, which is why a misbehaving Portal was
  so hard to diagnose. Its output is now read and kept in the Portal's log file, and a failed request
  names the error, its cause, and an id matching the entry in that log instead of answering with one
  fixed sentence (QOPS-395).
- **The Portal sees a module installed outside PowerShell's default path.** `QOps-StartPortal` had
  always passed that location on and nothing read it, so one health endpoint reported QOps available
  and the other reported it missing. Both now report the same module, and when it genuinely is not
  found they say why and list the paths searched (QOPS-390, QOPS-391, QOPS-400).
- **Git commands no longer hang for 15 seconds**: the child process inherited the host's stdin and
  waited on a pipe nobody was writing to (QOPS-337).
- **No more spurious 403 on Build.** The thumbnail step attempted an empty thumbnail and logged a
  permission warning for something it should not have tried (QOPS-215).

---

## 3.0.10 — 2026-07-28

QOps 3.0.10 ships with Portal 1.0.0. This is the release where QOps got a user interface. Everything
before it was cmdlets: `QOps-StartPortal` opens a local web app on the machine that already has the
module, and the work that used to be typed one command at a time now has a screen — the apps in the
repository, what changed in them, what an operation is doing while it runs, and the log afterwards.
Earlier manifests listed `QOps-StartPortal`, but nothing was behind it; this is the first release
where there is.

### What the Portal gives you

- **Studio, a file tree and a real editor.** Monaco, several tabs at once, copy/cut/paste/rename and
  delete on the tree, and a confirm before leaving with unsaved work (QOPS-162, QOPS-181, QOPS-184,
  QOPS-286, QOPS-243, QOPS-198). Search runs across the repository or one object type, and Global
  Replace writes through every match and refreshes the editors behind it (QOPS-183, QOPS-193).
- **Documentation generated from the repository.** Each app gets a page built from what is committed:
  sheets, widgets, measures, master objects and the script (QOPS-163, QOPS-221, QOPS-249). Where-used
  follows a field into inline widget expressions (QOPS-216). Two audit filters narrow the list to
  objects nothing references and to objects defined twice under different names, comparing formulas
  rather than text (QOPS-275, QOPS-278), and the filtered set exports to CSV (QOPS-274).
- **Lineage as a picture.** The app drawn from script to sheet to widget, with a right-click that
  inspects a node, opens its source file, or jumps to it in Studio, a focus chain that hides
  everything unrelated to one object, and export to SVG, PNG or JSON (QOPS-128, QOPS-175, QOPS-188,
  QOPS-197).
- **Git without leaving the Portal.** Branches, commit, stash, pull and push, including guided
  handling of a branch switch that would otherwise lose uncommitted work (QOPS-132, QOPS-133,
  QOPS-174, QOPS-145). The Diff panel shows the working tree grouped per app and names objects by
  title rather than by id (QOPS-135, QOPS-176, QOPS-192), and untracked files are listed one by one
  instead of collapsed into a folder row (QOPS-290).
- **Operations with the flags you would have typed.** Prepare, Build, Reload, Publish, Release and a
  new Add App, each with its documented flags as toggles, a preview of the exact command before it
  runs, and a time estimate averaged over the last runs on this machine (QOPS-150, QOPS-212,
  QOPS-153, QOPS-139). Run them against one app or the whole repository (QOPS-159), and the history
  survives both a panel switch and a restart (QOPS-138, QOPS-30).
- **Logs while the operation is still running**, streamed rather than arriving at the end, with a
  picker for one specific run and a search across every log file in the repository (QOPS-129,
  QOPS-191, QOPS-151, QOPS-281).
- **Settings that edit the configuration you already have.** Global settings and profiles in one
  place, profile create, edit and delete, licence activation, and the active environment remembered
  per repository (QOPS-205, QOPS-206, QOPS-134).
- **Light and dark themes**, applied without a flash on load and followed by the editor (QOPS-207).

Repositories written as YAML, and apps nested in `-prj` folders, are discovered the same as JSON ones
(QOPS-125, QOPS-126, QOPS-144). The Portal carries its own Help, including a page describing what each
panel is for (QOPS-32, QOPS-166, QOPS-289).

### Licensing keeps working when LicenseSpot does not

An outage at LicenseSpot used to hard-fail every cmdlet on machines that were already activated. The
genuine check now runs against the QOps licence service, which holds the authoritative record anyway,
plus the offline signature on the `.lic` file (QOPS-246). Licences issued on the additive-trust client
key do not involve LicenseSpot at all (QOPS-248).

### The module

- **`QOps-SetVersion` switches to an already-installed version** without downloading anything, forward
  or as a rollback, taking effect from the next cmdlet call (QOPS-74).
- **Newtonsoft.Json is current.** The module moved from 6.0.8 to 13.0.4, and stopped hijacking that
  assembly for other modules loaded in the same PowerShell 7 session (QOPS-65, QOPS-38, QOPS-130).
- **`;` in a filter means OR**, the way the documentation always described it. A trailing or repeated
  separator is handled instead of quietly widening the match (QOPS-87, QOPS-90).
- **Four crashes became messages**: `QOps-SetLocalApp` without a licence, `QOps-Release` when no
  certificate is found, `QOps-ShowDataConnections` on an empty result, and `QOps-Build` on an app
  with no owner (QOPS-109, QOPS-110, QOPS-120, QOPS-287).
- **`QOps-Reload` returns its result** on an ordinary call, not only under `-Wait -ShowLogs`
  (QOPS-66).
- **A configuration write that fails says so** instead of continuing quietly, and a `.qopsconfig` held
  open by another process no longer aborts the cmdlet (QOPS-67, QOPS-169).
- **`QOps-Update` finds installs it used to miss**, both flat and MSI, under either PowerShell root
  (QOPS-214).
- **An update no longer goes quiet when the server has no version file for your build.** Where the
  published `.version` is missing or unreadable for an architecture or branch, `QOps-Update` says so
  and reports no update available, instead of ending in an error about a version string being "too
  short or too long" (QOPS-168, QOPS-180).
