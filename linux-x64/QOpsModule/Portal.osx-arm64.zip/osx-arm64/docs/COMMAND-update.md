# QOps-Update

**What it does.** Installs the newest QOps build in this computer's update channel, beside the version
you have. With `-CheckOnly` it only looks: it says whether a newer build exists and installs nothing.
With `-IgnoreInstalledFromOtherChannels` it installs the channel's latest build even when a newer build from another
channel is installed.

**Direction.** GitHub, where QOps builds are published, to this computer. Nothing is sent to Qlik.

**When you need it.** To move to a newer build now rather than waiting for the daily automatic update,
or, with `-CheckOnly`, to find out whether there is one. The Portal's version panel runs two of them:
**Check for updates** is `QOps-Update -CheckOnly`, and **Update to &lt;version&gt;** (or **Download
&lt;version&gt;**) is `QOps-Update -IgnoreInstalledFromOtherChannels`. See
[Updating QOps from the Portal](USER-GUIDE.md#updating-qops-from-the-portal).

    QOps-Update -CheckOnly
    QOps-Update
    QOps-Update -IgnoreInstalledFromOtherChannels

## Which channel it reads

One channel per run: the one given with `-Channel`, otherwise the one this computer is set to with
`QOps-SetUpdateChannel`, otherwise `main-3.x`. Every answer is about that channel only. A build can be
the latest in `main-3.x` while a newer one exists in another channel.

## What a check returns

`QOps-Update -CheckOnly` returns one object and prints one line saying the same.

| Field | What it holds |
|---|---|
| `Installed` | The newest QOps installed on this computer, across both PowerShell editions |
| `Channel` | The channel that was read |
| `LatestInChannel` | The latest build in that channel; empty when the check failed |
| `UpdateAvailable` | `True` only when that build is newer than `Installed` |
| `Status` | `UpdateAvailable`, `LatestInChannel`, `NewerThanChannel` or `Failed` |
| `FailureKind` | When the check failed: `NoNetwork`, `RateLimited`, `TokenRejected`, `NotPublished` or `Other` |
| `FailureReason` | When the check failed: the cause and what to do about it |
| `LatestInChannelInstalled` | `True` when the build in `LatestInChannel` is installed, complete, for the PowerShell you ran the check in. It does not change `Status` |
| `ChannelInstall` | What `QOps-Update -IgnoreInstalledFromOtherChannels` would do for this channel: `Install`, `AlreadyInstalled`, `ChannelOlderThanDownloaded` or `PredatesSideBySide`. Empty when the check failed |
| `NewerFromChannelInstalled` | `True` when a build downloaded from this channel earlier is installed and is newer than `LatestInChannel`: the channel has gone back to an older build |

`LatestInChannel` means you have the latest build in that channel. `NewerThanChannel` means your build is
newer than anything in it, for example a build installed from another channel. Neither is an update.

A `NewerThanChannel` answer does not say whether the channel's own latest build is on this computer too.
`LatestInChannelInstalled` does. When it is not installed and a plain `QOps-Update` would not install it,
the printed line adds how to: `QOps-Update -Channel <channel> -IgnoreInstalledFromOtherChannels`.

| Channel's latest build | `ChannelInstall` | `QOps-Update -IgnoreInstalledFromOtherChannels` |
|---|---|---|
| Not installed | `Install` | Installs it beside the versions you have |
| Installed and complete | `AlreadyInstalled` | Downloads nothing and says how to switch to it: `QOps-SetVersion <version>` |
| Older than a build downloaded from the same channel before | `ChannelOlderThanDownloaded` | Installs nothing and says why |
| Older than 3.0.4, or the frozen 2.x channel | `PredatesSideBySide` | Installs nothing: such a build cannot go beside the others. Use the installer |

A newer build installed from another channel never stops it.

A check can fail without reaching GitHub (`NoNetwork`), on GitHub's request limit (`RateLimited`), on a
GitHub token that GitHub no longer accepts (`TokenRejected`), or on a channel that has no QOps build
(`NotPublished`, usually a misspelt channel name). A failed check never reads as "nothing to update".

To use the answer in a script:

    $check = QOps-Update -CheckOnly
    if ($check.UpdateAvailable) { QOps-Update }

## Which versions are installed

`QOps-Update` installs each build beside the ones you have. To see them, run:

    QOps-Version -Installed

It returns one object per installed version of QOps for the PowerShell you run it in (Windows
PowerShell and PowerShell 7 keep separate copies), newest first. It only reads: it runs no automatic
update and changes nothing. Without `-Installed`, `QOps-Version` prints the running version as before.

| Field | What it holds |
|---|---|
| `Version` | The build, for example `3.1.1.26101409` |
| `Path` | The folder it is in |
| `Complete` | `True` when the folder holds the whole module. `False` for a download that was interrupted |
| `Running` | `True` for the version this PowerShell window runs |
| `Shortcut` | `True` for the version the Portal shortcuts start |
| `Kind` | `VersionedFolder`: its own folder named after the version. `InstallerCopy`: files straight in the module folder, as older installers lay them down |
| `Origin` | The update channel it was installed from, for example `main-3.x`, `staging` or `staging-mcp`; `MSI` or `PKG` when an installer put it there; `Unknown` when nothing recorded it, as for versions an earlier QOps release installed |

The origin is kept in a file named `.origin` inside the version's folder, so it goes when the folder
goes. Two installations of the same version, a version folder and an installer copy, are two entries.

## Changing the channel for good

    QOps-SetUpdateChannel staging-mcp
    QOps-SetUpdateChannel main

sets the channel every later update on this computer reads, including the daily automatic one. `main`
is the 3.x release channel, stored as `main-3.x`; `main-2.x` is the frozen 2.x line.

With `-PassThru` it also returns the change as an object, and prints the same lines:

| Field | What it holds |
|---|---|
| `Previous` | The channel before the change; `main-3.x` if it had never been changed |
| `Channel` | The channel now, as it is stored |
| `IsRelease` | `True` when `Channel` is the release channel, `main-3.x` |

Nothing is returned when the channel was not changed: an invalid name, or a settings folder that could
not be written. The printed line says which.

## Flags

### -CheckOnly

Reads the latest build in the channel, compares it with the installed one, and stops. It installs
nothing, runs no daily automatic update, and leaves the Portal shortcuts as they are. It makes one
request to the GitHub API, with your own GitHub token when one is set (`QOps-SetConfig -GitHubToken`),
the same as an update. `-Force` has no effect with it.

### -IgnoreInstalledFromOtherChannels

Installs the latest build of the channel when it is not installed yet, beside the versions you have.
This is how you go back to the release channel's build after trying a newer pre-release: a plain
`QOps-Update` installs only a build newer than the newest one you have.

    QOps-Update -IgnoreInstalledFromOtherChannels
    QOps-Update -Channel main-3.x -IgnoreInstalledFromOtherChannels

Without `-Channel` it uses the channel this computer is set to (`QOps-SetUpdateChannel`). A channel
given with `-Channel` is for this run only: it does not change the computer's update channel.

Each channel holds one build, so there is no version to choose. What happens:

1. It reads the channel's latest build and compares it with the builds installed from that channel.
   See the table in [What a check returns](#what-a-check-returns).
2. It downloads the build into a folder of its own, for this PowerShell and for the other PowerShell
   edition on Windows when that one does not have it yet. No PowerShell window is closed and no other
   version is removed or changed.
3. It loads the new folder once in a separate PowerShell. If that fails, the new folder is removed and
   nothing else changes.
4. It makes the build the version QOps uses from the next command on, the same as `QOps-SetVersion`
   does, and points the Portal shortcuts at it. When a newer version is installed, QOps stays on this
   one until you switch with `QOps-SetVersion`.

It returns one object: `Channel`, `LatestInChannel`, `Outcome` (`Installed`, `AlreadyInstalled`,
`ChannelOlderThanDownloaded`, `PredatesSideBySide`, `Refused` or `Failed`), `Path` (the build's folder),
`PinnedVersion` (the version QOps stays on, empty when the build is the newest installed) and `Message`.

With `-CheckOnly` it installs nothing and the printed line is about the channel's own latest build, for
example `You do not have the latest build from the main-3.x channel yet: 3.1.1.26102110.` The returned
object is the same as for any check. It cannot be combined with `-Force`.

In the Portal, this is what **Update to &lt;version&gt;** runs in the version panel. When **Check for
updates** finds the channel's latest build missing while a newer build from another channel runs, the
panel offers it as **Download &lt;version&gt;**; when it finds that build installed while the Portal runs
another version, it offers **Switch to &lt;version&gt;** instead, which downloads nothing. It always uses
the channel this computer is set to. See [Updating QOps from the Portal](USER-GUIDE.md#updating-qops-from-the-portal).

### -Channel

Reads or installs from this channel for this run only, for example `-Channel staging-mcp`. It changes
nothing on the computer. To change the channel for good, use `QOps-SetUpdateChannel`.

### -Beta

Reads the beta channel for this run, when no channel is given and none is set on this computer.

### -Force

Reinstalls the latest build in the channel even when the installed one is the same or newer. The build
goes into its own folder named after the version, like any update, and this PowerShell window switches to
it without a restart. PowerShell windows that are open stay open.

- Newer installed versions are retired, so the update compare and new PowerShell windows use the build
  you chose. A folder that is still in use is removed at a later start of PowerShell.
- The folder that held the same version before is kept until the new one has loaded QOps in a separate
  PowerShell. When it does not load, nothing is replaced, the versions you have stay as they are, and
  the message says why.
- On Windows, the version this PowerShell window runs cannot be replaced while it is loaded. The update
  downloads the new copy, checks that it loads, and keeps it ready beside the running one; the message
  asks you to close all PowerShell windows and open a new one. The new window puts the copy in place
  before it loads QOps. If another PowerShell window or the QOps Portal still uses that version, the
  new window starts with the version you had, says the reinstall is waiting, and the next new window
  tries again. If the copy cannot be put in place completely, the version you had stays and the
  message says so.
- When a window of the other PowerShell edition runs that edition's copy of the same version, that copy
  is not replaced and the message says so: close PowerShell and run `QOps-Update -Force` again.

The Portal never passes it.
