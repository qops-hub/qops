# Using QOps from an AI assistant (MCP)

QOps includes an MCP server. MCP (Model Context Protocol) is the standard way an AI assistant such as Claude Desktop, Claude Code or Cursor is given tools. Once you connect the QOps server to your assistant, you can ask it in plain language to look through your QOps repositories, read and change Qlik applications, and run Prepare, Build, Publish and Reload for you.

The server runs on your own machine. Your assistant starts it and talks to it directly; it opens no network port, and it uses the QOps connection profiles and licence you already have. Your Qlik credentials are never sent to the assistant.

QOps also has its own chat in the Portal, which uses these same tools with nothing to connect. Pick the provider, the model and your API token under **Settings → Global → Chat**, where prompt caching and the token line after each answer are set too; see [Chat](USER-GUIDE.md#7-chat) in the User Guide. Start there. The rest of this page is for connecting the server to another assistant, which works from many clients.

## What you can ask it to do

You do not call the tools yourself. You describe what you want, and the assistant picks the tools. Some examples, with the tools the assistant will reach for:

| You want to | Ask something like | Tools involved |
|---|---|---|
| Find your way around a repository | "Which apps are in the Finance repository, and which sheets does Sales Overview have?" | `list_repositories`, `list_apps`, `get_app_metadata` |
| Find where something is used | "Which apps use the field CustomerID?" | `search_objects`, `get_lineage` |
| Read the version-controlled load script | "Show me the load script of Sales Overview as it is in the repository." | `get_load_script` |
| Look at a live application | "List the apps in the Development stream and show me the master measures of Sales Overview." | `list_qlik_apps`, `list_measures`, `get_measure` |
| Check numbers (MCP-QOps licence) | "What is Sum(Sales) by Region in that app?" | `evaluate_expression`, `get_hypercube_data` |
| Change an application | "Add a master measure Margin % defined as Sum(Margin)/Sum(Sales), then put a bar chart of it by Region on a new sheet." | `create_measure`, `create_sheet`, `add_chart_to_sheet` |
| Share a sheet you made (Qlik Cloud) | "Make my sheet Regional KPIs in Sales Overview public." | `list_sheets`, `publish_sheet` |
| Take a sheet of yours back (Qlik Cloud) | "Make my sheet Regional KPIs in Sales Overview private again." | `list_sheets`, `unpublish_sheet` |
| Combine bars and lines in one chart | "Add a combo chart of Sales and Margin % by Month, Sales as bars and Margin % as a line on its own axis." | `add_chart_to_sheet` |
| Edit the load script safely | "Check this script for syntax errors, and if it is clean, set it and reload the app." | `check_script_syntax`, `set_script`, `reload_app` |
| Run the QOps workflow | "Run Prepare for Sales Overview in C:\Repos\finance, then Build it." | `qops_prepare`, `qops_build` |

Every tool describes itself to the assistant, so you can also simply ask "What can the QOps tools do?".

The tools work in three different places, and it helps to know which is which:

- **Repository tools** read the decomposed, version-controlled files of the repositories registered in the Portal. They only read, and they need no Qlik connection and no licence.
- **Live application tools** open a connection to an application on your Qlik Sense or Qlik Cloud server, through one of your QOps connection profiles. A change made with them goes straight into that application on the server. It is not in your repository until you run Prepare, just as when you change the application in Qlik yourself.
- **Workflow tools** (`qops_prepare`, `qops_build`, `qops_publish`, `qops_reload`) run the QOps commands of the same name in a repository folder on this machine, exactly as if you had typed them in PowerShell there.

## Before you start

- **QOps installed, with a build that includes the MCP server.** You can tell from the step below: if starting the Portal does not print an `MCP launcher` line, the QOps build you have does not include it.
- **A licence activated on this machine** for the live application tools. The repository tools and the Prepare, Build, Publish and Reload tools do not check it themselves; those four run the QOps commands, which check it as usual. A QOps licence covers every tool except the analytic tools, which need an MCP-QOps licence (see [Analytic tools and the MCP-QOps licence](#analytic-tools-and-the-mcp-qops-licence)).
- **A Qlik connection profile** for the live application tools and the workflow tools — the same profiles the Portal's environment switcher lists. See [Prerequisites](USER-GUIDE.md#2-prerequisites) in the User Guide.
- **PowerShell with the QOps module** for the four workflow tools (`qops_prepare`, `qops_build`, `qops_publish`, `qops_reload`). They start PowerShell 7 when it is installed, and Windows PowerShell otherwise.

## Connect your assistant

### 1. Start the Portal once

Run `QOps-StartPortal`. Besides starting the Portal, it unpacks the MCP server and writes a small launcher file whose location never changes. It prints the path in a line like this one:

```text
MCP launcher: C:\Users\you\qopsconfig\mcp\qops-mcp.cmd (point your MCP client here).
```

| System | Launcher |
|---|---|
| Windows | `%USERPROFILE%\qopsconfig\mcp\qops-mcp.cmd` |
| Linux, macOS | `~/qopsconfig/mcp/qops-mcp` |

Always point your assistant at this launcher, never at the server inside the QOps installation folder. QOps installs each version into its own folder, so the server moves with every `QOps-Update`; the launcher stays where it is and starts the most recently installed server it finds. The Portal does not have to keep running for the assistant to use the server.

### 2. Add QOps to your assistant

Most assistants take the same `mcpServers` block in their settings file. Use the full path to the launcher: settings files do not expand `%USERPROFILE%` or `~`, and backslashes in a Windows path are written twice.

**Claude Desktop** keeps its settings in `claude_desktop_config.json` (on Windows in `%APPDATA%\Claude\`, on macOS in `~/Library/Application Support/Claude/`). Add:

```json
{
  "mcpServers": {
    "qops": {
      "command": "C:\\Users\\you\\qopsconfig\\mcp\\qops-mcp.cmd"
    }
  }
}
```

If `claude_desktop_config.json` already exists, keep what is in it and add only the `mcpServers` key inside the existing outer `{ }`, after a comma. For example, a file that already holds a `preferences` key:

```json
{
  "preferences": {
    "menuBarEnabled": false
  }
}
```

becomes:

```json
{
  "preferences": {
    "menuBarEnabled": false
  },
  "mcpServers": {
    "qops": {
      "command": "C:\\Users\\you\\qopsconfig\\mcp\\qops-mcp.cmd"
    }
  }
}
```

If the file already has an `mcpServers` key, add the `qops` entry inside it instead, after a comma.

Restart Claude Desktop after saving the file.

**Claude Code** reads a `.mcp.json` file at the root of your project, in the same shape. On Linux or macOS:

```json
{
  "mcpServers": {
    "qops": {
      "command": "/home/you/qopsconfig/mcp/qops-mcp"
    }
  }
}
```

**Cursor and other assistants** use the same `mcpServers` block in their own MCP settings. Where that file lives is described in the assistant's documentation.

### 3. Check that it works

Ask your assistant: "Show me the QOps server status, my QOps profiles and my repositories." That uses three tools that change nothing:

- `server_status` shows the server version, whether the licence is active on this machine, and its tier: `basic` for a QOps licence, `analytic` for an MCP-QOps licence.
- `list_profiles` lists your connection profiles and marks each one usable or not, with the reason when it is not. It shows no passwords or keys.
- `list_repositories` lists the repositories registered in the Portal.

If the assistant says the server could not start, see [Troubleshooting](#troubleshooting).

## Options

The launcher passes any arguments and environment variables on to the server, so you set these in the `args` or `env` part of the same `mcpServers` entry.

| Option | Environment variable | What it does |
|---|---|---|
| `--data-dir <folder>` (or `-d`) | `QOPS_PORTAL_DATA_DIR` | The folder holding the Portal's list of repositories, `repositories.json`. The default is `%ProgramData%\Qops` on Windows, the folder the Portal uses. On Linux and macOS it is `~/.local/share/Qops` (or `$XDG_DATA_HOME/Qops` when that is set), which is also the Portal's folder unless your Portal keeps its data in `/usr/share/Qops`; in that case pass that folder here. |
| `--config-dir <folder>` (or `-c`) | `QOPS_MCP_CONFIG_DIR` | The folder holding the global `.qopsconfig` with your connection profiles. The default is `%USERPROFILE%\qopsconfig`. |
| `--version` | | Prints the server version and where it is installed, then exits. Useful in a terminal to see which server the launcher starts. |
| `--help` (or `-h`) | | Prints the options and exits. |

A command-line option wins over the environment variable. An option the server does not know stops it with a message instead of starting it with a setting ignored.

For example, to read the repository list from another folder:

```json
{
  "mcpServers": {
    "qops": {
      "command": "C:\\Users\\you\\qopsconfig\\mcp\\qops-mcp.cmd",
      "args": ["--data-dir", "D:\\QOpsData"]
    }
  }
}
```

## Using one particular QOps version

By default the launcher starts the server of the QOps version installed most recently. To start a particular one instead, create `mcp.settings.json` in your `qopsconfig` folder (`%USERPROFILE%\qopsconfig\mcp.settings.json`, the same folder as `portal.settings.json`) with the full path to that server:

```json
{ "Mcp": { "ServerPath": "C:\\Users\\you\\Documents\\PowerShell\\Modules\\QOps\\3.0.13\\Portal\\Portal.Mcp.exe" } }
```

Then run `QOps-StartPortal` once: the launcher is written again on every start and picks the setting up then. Remove the setting to go back to the most recent version. Do not edit the launcher itself; your change would be overwritten on the next start.

## Working safely with live applications

A live application tool changes the application on the server, and by default it saves the change at once. These are the ways to stay in control; you can ask the assistant for each of them in plain words.

- **Read-only connection.** Ask the assistant to connect to the app read-only (`connect_app` with `writable` set to false). Every tool that would change the app is then refused. To make changes, it has to disconnect and connect again as writable.
- **Several changes, one save.** Ask it not to save after each change (`save` set to false) and to save once at the end with `save_app`. Until then the changes are only in the open session, and `get_app_layout` reports them as unsaved.
- **Checked after writing.** `create_measure`, `update_measure`, `create_dimension`, `update_dimension`, `create_variable` and `update_variable` check what they wrote with the same engine check as `check_expression`, and their result says what was checked and what the engine found (`verification`, plus a short `warning` when something is wrong). A broken expression is still saved, as it is when you save one in Qlik yourself, so the assistant can tell you about it and fix it.
- **Charts and objects are checked too.** `create_object`, `set_object_properties`, `apply_object_patches` and `add_chart_to_sheet` read the object back after writing it. Each dimension and measure written into the chart is checked the same way, a chart with fewer dimensions or measures than its type needs to draw is reported, and so is any error or unmet calculation condition Qlik reports when it calculates the chart. The result carries the same `verification` and `warning`. A preview (`dryRun`) changes nothing and is not checked.
- **What was written is what was saved.** `apply_object_patches` compares every path it changed with the object as Qlik stored it, and `add_chart_to_sheet` compares the chart it built and its place on the sheet with what Qlik stored. Any difference is listed in `verification.issues`, naming the patch or part and the stored and written values. When one call changes the same path twice, only the last change is compared, and the result says which ones were not.
- **Combo charts draw each measure the way you ask.** By default the first measure is drawn as bars on the main axis and every other measure as a line on a second axis, so values of different size stay readable. You can ask for bars, lines or markers per measure, on either axis. Only combo charts take this choice; for any other chart the request is refused before anything is written.
- **Chart settings the assistant can change on an existing chart.** For bar charts: value labels, legend on or off, legend position (bottom), title, X-axis labels, Y-axis range, colour by dimension, sorting by a measure, grouped or stacked bars and orientation. For line charts: value labels, Y-axis labels, grid lines and showing the line as an area. For combo charts: how each measure is drawn (bars, line or markers, on the main or second axis) and legend position (bottom). For pie charts: showing the pie as a donut. Each one is changed exactly the way Qlik changes it when you use the setting yourself, and only with the values someone has checked in Qlik.
- **Chart properties are checked by name.** When the assistant creates a chart from a chart type (`add_chart_to_sheet`, or `create_object` with a template) and passes extra properties in `propertiesJson`, each property name must be one that chart type is known to read. Qlik itself accepts any name and ignores the ones it does not know, so a misspelled or guessed name such as `legend.position` would be saved and have no effect. Such a name is refused before anything is written, and the answer names the closest known property (for the legend position that is `legend.dock`). `list_chart_customisations` lists the settings for each chart type and the exact properties each one writes. Qlik's own data definitions (the dimensions and measures, `qExtendsId` for a master visualization, and every other property whose name starts with `q`) are not checked. A Qlik property that is real but not yet on the known list can be set after the chart exists, with `apply_object_patches`. `create_object` without a template creates any object type and checks no names.
- **Charts can be sorted by a measure.** Ask for a chart sorted by one of its measures and it is ordered by that measure, largest first unless you ask for smallest first, the same way Qlik stores it when you choose that sorting yourself. Key figures, gauges and pivot tables do not take this choice, and the request is refused before anything is written.
- **Each chart type is checked by its own rules.** A scatter plot needs two measures (X and Y), a gauge takes no dimension, a treemap uses only one measure (the size of the rectangles), and a pivot table must be in pivot mode. A chart that breaks its rule is still saved and is reported in `verification.issues`.
- **Preview first.** `set_object_properties` and `apply_object_patches` can return a preview of what would change without changing anything (`dryRun`). `check_script_syntax` checks a load script before `set_script` replaces it, and `check_expression` checks an expression without calculating it.
- **Deleting an application** with `delete_app` cannot be undone, and the tool refuses unless the assistant repeats the application's Id as confirmation.
- **What was changed.** `get_audit_log` lists the changes the live application tools have made or tried to make since the server started (the most recent 500): when, which tool, which profile and app, and whether it succeeded. It records no values.
- **Published applications.** The Qlik server refuses to save changes to a published or read-only application, so the live tools cannot change one either. `get_app_layout` shows whether an app is published or read-only.

### Whose selections the assistant sees

On Qlik Sense client-managed the server connects with the profile's certificate as the profile's user, so the selections it makes live in that user's engine session. A browser signed in under another account does not see them, and the assistant does not see the selections made in that browser.

On Qlik Cloud the server joins, by default, the same session as the owner of the profile's API key, so each side sees the other's selections: what you select in the browser as that user, the assistant sees, and the other way round. For a session of its own, which no one else sees, ask the assistant to connect with `connect_app` and `session` set to `private`. Such a session is closed when the assistant disconnects.

### Connections and your licence

An open connection to an application does not hold a licence slot. A slot is taken only while a tool call works on the application, and it is given back when the call returns. The MCP server shares the slots with the QOps commands on the same machine, so a QOps command can run while the assistant keeps a connection open.

When every slot is in use, what happens depends on what holds them. If one of them is held by another tool call of the same MCP server, the new call waits for it and then runs, so the server runs as many calls at the same time as there are slots free to it and queues the rest. If every slot is held by something else, for example a QOps command started from PowerShell or the Portal, or another MCP server, the tool call stops at once with a message naming what holds the slot. Ask the assistant to retry once that work has finished; nothing needs to be closed or restarted.

The number of connections the server keeps open at the same time is still limited by your licence's concurrent connections. When that limit is reached, a new connection is refused with a message naming the open ones. The server never closes a connection on its own to make room. Ask the assistant to close the ones it no longer needs (`disconnect_app`, or `close_all_sessions` for all of them); `list_sessions` shows what is open. A connection that is not used for 30 minutes is closed automatically.

### Analytic tools and the MCP-QOps licence

The analytic tools are the ones that read the data in an application or change the selections: `get_hypercube_data`, `evaluate_expression`, `get_field_values`, `get_current_selections`, `select_field_values` and `clear_selections`. They need an MCP-QOps licence. Every other tool works with a QOps licence.

With a QOps licence the other tools still show how an application is built (sheets, charts, master items, expressions, the load script, the list of tables and fields), but not the values in its data. Two of them can come across data values, and they leave the values out:

- `get_object` with its evaluated layout: the layout keeps its structure, and the values in it (table cells, totals, the lowest and highest value of a column, the result of an expression, the selected values) are replaced with a note. The object's properties, which are what you edit, are always complete.
- `list_variables`: the value of a variable that the load script sets (for example with `LET`) is left out; `get_script` shows how the script sets it. Variables you created keep their definition.

The check that runs after a tool changes a chart or an object reports errors only, never values, so it works the same with either licence.

An MCP-QOps licence includes QOps: with it you can use all of QOps, the QOps commands and the Portal included, plus the analytic tools. You set it on a machine the same way as a QOps licence, with `QOps-SetLicense` or in **Settings → Global → License** in the Portal. `server_status` shows `tier: analytic` once it is active, and the Portal shows **Analytic (MCP-QOps)** as the licence tier under **Settings → Global → License**.

With a QOps licence the analytic tools are not offered to your assistant at all, so they take no room in its tool list. `server_status` names them under `unavailableTools`, together with the licence they need. If the assistant still asks for one (for example because it remembers the tool from an earlier session), the tool answers with a message that names the licence it needs; the call does not connect to the application and does not take a licence slot.

When the licence on the machine changes while the assistant is connected, the server tells the assistant that its list of tools has changed, the next time the assistant uses a tool. Assistants that support this update their list straight away; with others, start a new conversation to see the change.

Which licence each tool needs:

<!-- tier-table: kept in sync with the [ToolTier] attributes in the code by ToolTierTableTests (portal-mcp.Tests). -->
| Tool | Licence | Note |
|---|---|---|
| `connect_app` | QOps |  |
| `disconnect_app` | QOps |  |
| `list_sessions` | QOps |  |
| `list_profiles` | QOps |  |
| `close_all_sessions` | QOps |  |
| `server_status` | QOps |  |
| `get_audit_log` | QOps |  |
| `save_app` | QOps |  |
| `get_app_layout` | QOps |  |
| `set_app_properties` | QOps |  |
| `list_qlik_apps` | QOps |  |
| `reload_app` | QOps |  |
| `create_app` | QOps |  |
| `delete_app` | QOps |  |
| `evaluate_expression` | MCP-QOps |  |
| `check_expression` | QOps |  |
| `get_hypercube_data` | MCP-QOps |  |
| `list_fields_and_tables` | QOps | Names of tables and fields, row counts and keys; no field values. |
| `get_field_values` | MCP-QOps |  |
| `get_current_selections` | MCP-QOps |  |
| `select_field_values` | MCP-QOps |  |
| `clear_selections` | MCP-QOps |  |
| `list_objects` | QOps |  |
| `get_object` | QOps | With a QOps licence the evaluated layout (`includeLayout`) keeps its structure, but its data values are withheld. The properties are always complete. |
| `create_object` | QOps | The check after the write reports errors only, never values. |
| `set_object_properties` | QOps | The check after the write reports errors only, never values. |
| `apply_object_patches` | QOps | The check after the write reports errors only, never values. |
| `delete_object` | QOps |  |
| `list_chart_templates` | QOps |  |
| `list_chart_customisations` | QOps |  |
| `list_sheets` | QOps |  |
| `create_sheet` | QOps |  |
| `add_chart_to_sheet` | QOps | The check after the write reports errors only, never values. |
| `remove_chart_from_sheet` | QOps |  |
| `delete_sheet` | QOps |  |
| `publish_sheet` | QOps |  |
| `unpublish_sheet` | QOps | Only for a sheet the caller owns, unless `takeOwnership` is set: that makes the caller the new owner of a sheet owned by another user. |
| `list_measures` | QOps |  |
| `get_measure` | QOps |  |
| `create_measure` | QOps |  |
| `update_measure` | QOps |  |
| `delete_measure` | QOps |  |
| `list_dimensions` | QOps |  |
| `get_dimension` | QOps |  |
| `create_dimension` | QOps |  |
| `update_dimension` | QOps |  |
| `delete_dimension` | QOps |  |
| `list_variables` | QOps | With a QOps licence the value of a variable the load script sets is withheld; `get_script` shows how it is set. |
| `create_variable` | QOps |  |
| `update_variable` | QOps |  |
| `delete_variable` | QOps |  |
| `get_script` | QOps |  |
| `set_script` | QOps |  |
| `check_script_syntax` | QOps |  |
| `list_repositories` | QOps |  |
| `list_apps` | QOps |  |
| `get_app_metadata` | QOps |  |
| `get_lineage` | QOps |  |
| `list_app_objects` | QOps |  |
| `describe_object` | QOps |  |
| `get_load_script` | QOps |  |
| `search_objects` | QOps |  |
| `get_repo_stats` | QOps |  |
| `qops_prepare` | QOps |  |
| `qops_build` | QOps |  |
| `qops_publish` | QOps |  |
| `qops_reload` | QOps |  |
<!-- /tier-table -->

## Making a sheet public on Qlik Cloud

On Qlik Cloud a sheet you create is private: only you see it. Ask the assistant to make it public, and everyone who can open the app sees it, the same as **Make public** in Qlik Cloud. The assistant uses `publish_sheet`, which publishes the sheet the same way QOps Build does for a sheet marked Published, then reads it back from Qlik and reports success only when Qlik says the sheet is public.

Qlik Cloud does not report an owner for a sheet made through its API, for example one the assistant created. Such a sheet is published, as Build publishes it; Qlik itself still decides whether you may.

Finish the sheet first: Qlik Cloud shows a public sheet as read-only. To edit it again, ask the assistant to make it private; see [Making a sheet private again](#making-a-sheet-private-again).

The tool changes nothing and says why when:

- Qlik reports someone else as the owner of the sheet. Only the owner of a sheet can make it public; ask the owner to do it.
- the sheet is already public.
- the id is not a sheet, for example a chart, or there is no such object in the app.
- the connection profile is for Qlik Sense client-managed. There, sheets become public when the app is published to a stream, and the owner publishes a sheet of a published app in the hub; `publish_sheet` is for Qlik Cloud only.

Like every live tool it cannot change a published app (see [Working safely with live applications](#working-safely-with-live-applications)).

### Making a sheet private again

Ask the assistant to make a public sheet of yours private, the same as **Make private** in Qlik Cloud. It uses `unpublish_sheet`, which makes the sheet private the same way QOps Build does for a sheet marked not published, reads it back and reports success only when Qlik says the sheet is private.

Only the owner of the sheet can do it. On Qlik Cloud, making a sheet private makes whoever does it the sheet's owner, so for anyone else it would take the sheet away from its owner. The tool changes nothing and says why when Qlik reports someone else as the owner, when Qlik reports no owner for the sheet (for example a sheet made through the API), when the sheet is already private, when the id is not a sheet, and for a Qlik Sense client-managed profile.

When taking the sheet over is what you want, ask for it explicitly: with `takeOwnership` set, the assistant makes the sheet private even when someone else owns it, or when Qlik reports no owner. In Qlik Cloud this makes you the new owner of the sheet, and the previous owner no longer has it; the result names the previous owner.

## Troubleshooting

| What you see | What to do |
|---|---|
| Starting the Portal prints no `MCP launcher` line | The QOps build you have installed does not include the MCP server. |
| The assistant says the server failed to start, or the launcher prints `QOps: no MCP server under ...` | Run `QOps-StartPortal` once so the server is unpacked, then restart the assistant. Running the launcher yourself in a terminal with `--version` shows the message directly. |
| The launcher prints `QOps: Mcp.ServerPath in mcp.settings.json points at ..., which does not exist` (on Linux and macOS: `which is not executable`) | The path in `mcp.settings.json` is wrong or that version was removed. Correct or remove it, then run `QOps-StartPortal`. |
| `QOps-StartPortal` warns that the MCP launcher cannot be written correctly because of the code page | The QOps installation folder contains characters Windows cannot write into the launcher file. Point `ServerPath` in `mcp.settings.json` at a server whose path has none, or point the assistant straight at the server. |
| "QOps license is not activated on this machine" | Activate the licence on this machine (`QOps-SetLicense`, or **Settings → Global → License** in the Portal). Only the live application tools need it. |
| "... is one of the QOps MCP analytic tools, which need an MCP-QOps licence" | The licence on this machine is a QOps licence. Ask your QOps supplier for an MCP-QOps licence and set it with `QOps-SetLicense`. All the other tools keep working meanwhile (see [Analytic tools and the MCP-QOps licence](#analytic-tools-and-the-mcp-qops-licence)). |
| "All N concurrent license slot(s) are in use" | A QOps command or another MCP server is using every slot. Ask the assistant to retry when it finishes (see [Connections and your licence](#connections-and-your-licence)). |
| "License allows N concurrent app connection(s)" | Close connections you no longer need with `disconnect_app` or `close_all_sessions`. |
| `list_profiles` marks a profile as not usable | The reason is given next to it. A profile saved on Windows can only be read by the same Windows user on the same machine; save it again there if the configuration was copied from elsewhere. |
| `list_repositories` is empty while the Portal shows repositories | The server is reading a different folder. Pass `--data-dir` with the folder the Portal uses; see [What is stored, and where](USER-GUIDE.md#6-what-is-stored-and-where). |
| A workflow tool says the QOps module or a profile is missing | The four workflow tools run the QOps commands in PowerShell, in the repository folder you name. Check that the QOps commands work in PowerShell on this machine and that the repository folder has its `.qopsconfig`. |

## See also

- [User Guide](USER-GUIDE.md) — the Portal, end to end, including where QOps keeps its files.
- [Configuration](CONFIGURATION.md) — the configuration files, including the connection profiles the server uses.
- [Commands](COMMANDS.md) — what Prepare, Build, Publish and Reload do.
