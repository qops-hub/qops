# Using QOps from an AI assistant (MCP)

QOps includes an MCP server. MCP (Model Context Protocol) is the standard way an AI assistant such as Claude Desktop, Claude Code or Cursor is given tools. Once you connect the QOps server to your assistant, you can ask it in plain language to look through your QOps repositories, read and change Qlik applications, and run Prepare, Build, Publish and Reload for you.

The server runs on your own machine. Your assistant starts it and talks to it directly; it opens no network port, and it uses the QOps connection profiles and licence you already have. Your Qlik credentials are never sent to the assistant.

QOps also has its own chat in the Portal, which uses these same tools with nothing to connect. Pick the provider, the model and your API token under **Settings → Global → Chat**, where prompt caching and the token line after each answer are set too; see [Chat](USER-GUIDE.md#7-chat) in the User Guide. Start there. The rest of this page is for connecting the server to another assistant, which works from many clients.

## What you can ask it to do

You do not call the tools yourself. You describe what you want, and the assistant picks the tools. Some examples, with the tools the assistant will reach for:

| You want to | Ask something like | Tools involved |
|---|---|---|
| Register a repository without the Portal | "Register /workspaces/finance as a QOps repository." | `register_repository`, `list_repositories` |
| Find your way around a repository | "Which apps are in the Finance repository, and which sheets does Sales Overview have?" | `list_repositories`, `list_apps`, `get_app_metadata` |
| Find where something is used | "Which apps use the field CustomerID?" | `search_objects` |
| Find what uses a field | "What uses the field CustomerID in the Finance repository, and what does the measure Total Sales read?" | `get_lineage` |
| Find what uses a master item | "Which charts in the Finance repository use the master measure Total Sales?" | `get_lineage` |
| Read the version-controlled load script | "Show me the load script of Sales Overview as it is in the repository." | `get_load_script` |
| Look at a live application | "List the apps in the Development stream and show me the master measures of Sales Overview." | `list_qlik_apps`, `list_measures`, `get_measure` |
| Check numbers (MCP-QOps licence) | "What is Sum(Sales) by Region in that app?" | `evaluate_expression`, `get_hypercube_data` |
| Change an application | "Add a master measure Margin % defined as Sum(Margin)/Sum(Sales), then put a bar chart of it by Region on a new sheet." | `create_measure`, `create_sheet`, `add_chart_to_sheet` |
| Share a sheet you made (Qlik Cloud) | "Make my sheet Regional KPIs in Sales Overview public." | `list_sheets`, `publish_sheet` |
| Take a sheet of yours back (Qlik Cloud) | "Make my sheet Regional KPIs in Sales Overview private again." | `list_sheets`, `unpublish_sheet` |
| Combine bars and lines in one chart | "Add a combo chart of Sales and Margin % by Month, Sales as bars and Margin % as a line on its own axis." | `add_chart_to_sheet` |
| Edit the load script safely | "Check this script for syntax errors, and if it is clean, set it and reload the app." | `check_script_syntax`, `set_script`, `reload_app` |
| Run the QOps workflow | "Run Prepare for Sales Overview in C:\Repos\finance, then Build it." | `qops_prepare`, `qops_build` |

Every tool describes itself to the assistant, so you can also simply ask "What can the QOps tools do?". The list of tools the assistant receives keeps each description short, so it takes little room in the conversation. When the assistant needs the details of a tool (what each argument means, the accepted values, examples), it asks for them with `describe_tool`, one tool at a time.

The tools work in three different places, and it helps to know which is which:

- **Repository tools** read the decomposed, version-controlled files of the repositories registered in the Portal. They only read, and they need no Qlik connection and no licence. The one exception is `register_repository`, which adds a folder to the list of registered repositories; see [Registering a repository](#registering-a-repository).
- **Live application tools** open a connection to an application on your Qlik Sense or Qlik Cloud server, through one of your QOps connection profiles. A change made with them goes straight into that application on the server. It is not in your repository until you run Prepare, just as when you change the application in Qlik yourself.
- **Workflow tools** (`qops_prepare`, `qops_build`, `qops_publish`, `qops_reload`) run the QOps commands of the same name in a repository folder on this machine, exactly as if you had typed them in PowerShell there.
  The reply keeps the last 60 lines of the command output (at most 8,000 characters) in `outputTail`, and the per-app results in `apps` (at most 50; `appsTotal` gives the real count). When the output is longer, the full output is written to a file in the repository's `.mcp-files` folder and its path is returned as `fullOutputPath` (`qops-mcp-output-<cmdlet>-<UTC time>.log`). The folder has its own `.gitignore`, so its files never show up in your changes or commits, and your own `.gitignore` is not touched.

### Lists answer with names first

Everything a tool answers goes into the assistant's conversation and takes room there on every later turn, so the list tools answer with as little as the next step needs.

- `list_measures`, `list_dimensions` and `list_variables` answer with the id and the name of each item. Ask for the definitions and they come back too (`includeDetails`): the expression, description and tags of a master measure, the fields of a master dimension, the definition and comment of a variable.
- To find one item by its name, the assistant passes part of the name (`titleContains` for master items, `nameContains` for variables and for `list_qlik_apps`) and gets back only the id and the name of each match. `list_qlik_apps` gives the stream or space, owner and last reload time of each app when it lists without a name, or when `includeDetails` is set.
- A list comes in pages. A page also ends early when the next item would make the answer too long (about 27,600 characters), and the answer then says there is more (`truncated`), so the assistant asks for the next page instead of getting a shortened text.
- `get_measure` and `get_dimension` still return one master item with its full expression.
- `list_sheets` answers with the id, title and object count of each sheet, 100 sheets to a page. To find a sheet by its title, the assistant passes part of the title (`titleContains`). Naming sheets by id (`sheetIds`) returns only those sheets, each with the id and type of every object on it.

## Before you start

- **QOps installed, with a build that includes the MCP server.** You can tell from the step below: if starting the Portal does not print an `MCP launcher` line, the QOps build you have does not include it.
- **A licence activated on this machine** for the live application tools. The repository tools and the Prepare, Build, Publish and Reload tools do not check it themselves; those four run the QOps commands, which check it as usual. A QOps licence covers every tool except the analytic tools, which need an MCP-QOps licence (see [Analytic tools and the MCP-QOps licence](#analytic-tools-and-the-mcp-qops-licence)).
- **A Qlik connection profile** for the live application tools and the workflow tools — the same profiles the Portal's environment switcher lists. See [Prerequisites](USER-GUIDE.md#2-prerequisites) in the User Guide.
- **PowerShell with the QOps module** for the four workflow tools (`qops_prepare`, `qops_build`, `qops_publish`, `qops_reload`). They start PowerShell 7 when it is installed, and Windows PowerShell otherwise.

## Connect your assistant

### 1. Start the Portal once

Run `QOps-StartPortal`. Besides starting the Portal, it unpacks the MCP server and writes a small launcher file whose location never changes. It prints the path in a line like this one:

```text
MCP launcher: C:\Users\you\qopsconfig\mcp\qops-mcp.cmd (point your MCP client here).
```

| System | Launcher |
|---|---|
| Windows | `%USERPROFILE%\qopsconfig\mcp\qops-mcp.cmd` |
| Linux, macOS | `~/qopsconfig/mcp/qops-mcp` |

Always point your assistant at this launcher, never at the server inside the QOps installation folder. QOps installs each version into its own folder, so the server moves with every `QOps-Update`; the launcher stays where it is and starts the most recently installed server it finds. The Portal does not have to keep running for the assistant to use the server.

### 2. Add QOps to your assistant

Most assistants take the same `mcpServers` block in their settings file. Use the full path to the launcher: settings files do not expand `%USERPROFILE%` or `~`, and backslashes in a Windows path are written twice.

**Claude Desktop** keeps its settings in `claude_desktop_config.json` (on Windows in `%APPDATA%\Claude\`, on macOS in `~/Library/Application Support/Claude/`). Add:

```json
{
  "mcpServers": {
    "qops": {
      "command": "C:\\Users\\you\\qopsconfig\\mcp\\qops-mcp.cmd"
    }
  }
}
```

If `claude_desktop_config.json` already exists, keep what is in it and add only the `mcpServers` key inside the existing outer `{ }`, after a comma. For example, a file that already holds a `preferences` key:

```json
{
  "preferences": {
    "menuBarEnabled": false
  }
}
```

becomes:

```json
{
  "preferences": {
    "menuBarEnabled": false
  },
  "mcpServers": {
    "qops": {
      "command": "C:\\Users\\you\\qopsconfig\\mcp\\qops-mcp.cmd"
    }
  }
}
```

If the file already has an `mcpServers` key, add the `qops` entry inside it instead, after a comma.

Restart Claude Desktop after saving the file.

**Claude Code** reads a `.mcp.json` file at the root of your project, in the same shape. On Linux or macOS:

```json
{
  "mcpServers": {
    "qops": {
      "command": "/home/you/qopsconfig/mcp/qops-mcp"
    }
  }
}
```

**Cursor and other assistants** use the same `mcpServers` block in their own MCP settings. Where that file lives is described in the assistant's documentation.

### 3. Check that it works

Ask your assistant: "Show me the QOps server status, my QOps profiles and my repositories." That uses three tools that change nothing:

- `server_status` shows the server version, whether the licence is active on this machine, and its tier: `basic` for a QOps licence, `analytic` for an MCP-QOps licence.
- `list_profiles` lists your connection profiles and marks each one usable or not, with the reason when it is not. It shows no passwords or keys.
- `list_repositories` lists the repositories registered in the Portal. If none is registered yet, it says so and points at `register_repository`; see [Registering a repository](#registering-a-repository).

If the assistant says the server could not start, see [Troubleshooting](#troubleshooting).

## Options

The launcher passes any arguments and environment variables on to the server, so you set these in the `args` or `env` part of the same `mcpServers` entry.

| Option | Environment variable | What it does |
|---|---|---|
| `--data-dir <folder>` (or `-d`) | `QOPS_PORTAL_DATA_DIR` | The folder holding the Portal's list of repositories, `repositories.json`. The default is `%ProgramData%\Qops` on Windows, the folder the Portal uses. On Linux and macOS it is `~/.local/share/Qops` (or `$XDG_DATA_HOME/Qops` when that is set), which is also the Portal's folder unless your Portal keeps its data in `/usr/share/Qops`; in that case pass that folder here. |
| `--config-dir <folder>` (or `-c`) | `QOPS_MCP_CONFIG_DIR` | The folder holding the global `.qopsconfig` with your connection profiles. The default is `%USERPROFILE%\qopsconfig`. |
| `--version` | | Prints the server version and where it is installed, then exits. Useful in a terminal to see which server the launcher starts. |
| `--help` (or `-h`) | | Prints the options and exits. |

A command-line option wins over the environment variable. An option the server does not know stops it with a message instead of starting it with a setting ignored.

For example, to read the repository list from another folder:

```json
{
  "mcpServers": {
    "qops": {
      "command": "C:\\Users\\you\\qopsconfig\\mcp\\qops-mcp.cmd",
      "args": ["--data-dir", "D:\\QOpsData"]
    }
  }
}
```

## Using one particular QOps version

By default the launcher starts the server of the QOps version installed most recently. To start a particular one instead, create `mcp.settings.json` in your `qopsconfig` folder (`%USERPROFILE%\qopsconfig\mcp.settings.json`, the same folder as `portal.settings.json`) with the full path to that server:

```json
{ "Mcp": { "ServerPath": "C:\\Users\\you\\Documents\\PowerShell\\Modules\\QOps\\3.0.13\\Portal\\Portal.Mcp.exe" } }
```

Then run `QOps-StartPortal` once: the launcher is written again on every start and picks the setting up then. Remove the setting to go back to the most recent version. Do not edit the launcher itself; your change would be overwritten on the next start.

## Working safely with live applications

A live application tool changes the application on the server, and by default it saves the change at once. These are the ways to stay in control; you can ask the assistant for each of them in plain words.

- **Read-only connection.** Ask the assistant to connect to the app read-only (`connect_app` with `writable` set to false). Every tool that would change the app is then refused. To make changes, it has to disconnect and connect again as writable.
- **Several changes, one save.** Ask it not to save after each change (`save` set to false) and to save once at the end with `save_app`. Until then the changes are only in the open session, and `get_app_layout` reports them as unsaved.
- **Checked after writing.** `create_measure`, `update_measure`, `create_dimension`, `update_dimension`, `create_variable` and `update_variable` check what they wrote with the same engine check as `check_expression`, and their result says what was checked and what the engine found (`verification`, plus a short `warning` when something is wrong). A broken expression is still saved, as it is when you save one in Qlik yourself, so the assistant can tell you about it and fix it.
- **Charts and objects are checked too.** `create_object`, `set_object_properties`, `apply_object_patches` and `add_chart_to_sheet` read the object back after writing it. Each dimension and measure written into the chart is checked the same way, a chart with fewer dimensions or measures than its type needs to draw is reported, and so is any error or unmet calculation condition Qlik reports when it calculates the chart. The result carries the same `verification` and `warning`. A preview (`dryRun`) changes nothing and is not checked.
- **What was written is what was saved.** `apply_object_patches` compares every path it changed with the object as Qlik stored it, and `add_chart_to_sheet` compares the chart it built and its place on the sheet with what Qlik stored. Any difference is listed in `verification.issues`, naming the patch or part and the stored and written values. When one call changes the same path twice, only the last change is compared, and the result says which ones were not. Qlik leaves out a setting of its own (a property whose name starts with `q`, such as `qSortByNumeric`) when it is 0, off or empty, so such a value that is missing after the write is not a difference; any other missing value still is. A `replace` of a whole object in `apply_object_patches` is merged by Qlik into the object it already has: a property the new value leaves out keeps its old value, so remove it with a separate `remove` patch. Such a property is listed in `verification.issues`, except Qlik's own `q` properties, which Qlik fills in itself. The sort of a dimension (`qSortCriterias`) or a measure (`qSortBy`) is the exception: `apply_object_patches` writes it with every sort option, the ones not named turned off and the sort expression empty, so replacing a sort replaces it.
- **Combo charts draw each measure the way you ask.** By default the first measure is drawn as bars on the main axis and every other measure as a line on a second axis, so values of different size stay readable. You can ask for bars, lines or markers per measure, on either axis. Only combo charts take this choice; for any other chart the request is refused before anything is written.
- **Chart settings the assistant can change on an existing chart.** For bar charts: value labels, legend on or off, legend position (bottom), title, X-axis labels, Y-axis range, colour by dimension, sorting by a measure, grouped or stacked bars and orientation. For line charts: value labels, Y-axis labels, grid lines and showing the line as an area. For combo charts: how each measure is drawn (bars, line or markers, on the main or second axis) and legend position (bottom). For pie charts: showing the pie as a donut. Each one is changed exactly the way Qlik changes it when you use the setting yourself, and only with the values someone has checked in Qlik.
- **Chart properties are checked by name.** When the assistant creates a chart from a chart type (`add_chart_to_sheet`, or `create_object` with a template) and passes extra properties in `propertiesJson`, each property name must be one that chart type is known to read. Qlik itself accepts any name and ignores the ones it does not know, so a misspelled or guessed name such as `legend.position` would be saved and have no effect. Such a name is refused before anything is written, and the answer names the closest known property (for the legend position that is `legend.dock`). `list_chart_customisations` lists the settings for each chart type and the exact properties each one writes. Qlik's own data definitions (the dimensions and measures, `qExtendsId` for a master visualization, and every other property whose name starts with `q`) are not checked. The same check applies when the assistant changes a chart that already exists, with `apply_object_patches` or `set_object_properties`: a property name the chart type is not known to read is refused before anything is written, a preview (`dryRun`) included, unless the chart already has that property. The chart's Styling settings (`components`, one entry per part of the chart such as `general`, `bar` or `axis`) are checked the same way, part by part: a Styling property the chart type is not known to have for that part, such as a `glowEffect` on the bars, is refused and the answer names the Styling properties that part has. A sheet is checked the same way against the properties a sheet has (its title and description, the grid, the charts placed on it and the other sheet settings): a chart setting written onto the sheet instead of the chart, such as a `glowEffect`, is refused before anything is written, and the answer says the object is a sheet and names the charts on it. Removing a property is not checked, and neither is any other object that is not a chart (a master item, an extension). `create_object` without a template creates any object type and checks no names. A refusal also says which form the path takes: in `apply_object_patches` a JSON Pointer that starts at the object's properties, such as `/legend/dock`, and in `propertiesJson` the keys at the top level. `/properties` belongs only to the `path` of `get_object`, so a patch path that starts with it is refused on every object type, naming the path to send.
- **Chart setting names come from the list.** `list_chart_customisations` with a chart type alone returns the setting names of that chart type, and the assistant is told to start there. A name that does not exist is refused with a short answer that lists the valid names of that chart type; a request with a missing or unknown chart type says to ask again with the chart type alone.
- **Chart settings with a fixed list of choices are checked by value.** Some chart properties take only a few values, and the value Qlik stores is not always the name you see in the chart settings: the pie chart label setting shows Values but stores `value`. When `add_chart_to_sheet`, `apply_object_patches` or `set_object_properties` writes such a property on a chart directly, a value outside the list is refused before anything is written, and the answer lists the values the chart takes and, where you used the setting name, the value to write instead. `list_chart_customisations` translates the names for you. A value the chart already has is not refused, so a chart that was saved with such a value can still be changed and saved again. Properties that take free text, numbers, colours or expressions are not checked, and neither are objects that are not charts.
- **A setting behind an Auto / Custom switch is switched to Custom with it.** Some chart settings only take effect once a switch next to them in the chart settings is set to Custom, and Qlik ignores them while it stays on Auto: what the pie chart slice labels show (Value labels), the group headers and box labels of a treemap (Headers and labels), and the continuous scale of the X axis of a line or combo chart (X-axis Continuous). When `add_chart_to_sheet`, `apply_object_patches` or `set_object_properties` writes one of these settings, the switch is set to Custom in the same write, so the chart shows what was asked. A write that also sets the switch to Auto is refused before anything is written, and the answer says which property to change. A switch value that only repeats what the chart already stores, as in a copy of the whole chart with one setting edited, is not read as a choice. The ready patches of `list_chart_customisations` carry both properties.
- **A chart sort written with Sorting left on Auto is refused.** Qlik ignores the sort of a dimension (`qSortCriterias`) or a measure (`qSortBy`) while that dimension's or measure's Sorting is Auto (`qDef.autoSort` true). When `apply_object_patches` or `set_object_properties` writes such a sort and leaves `autoSort` true for the same dimension or measure, the call is refused before anything is written, a preview (`dryRun`) included, and the answer says how to fix it: set `qDef/autoSort` to `false` for that dimension or measure in the same change, or use the sort settings of `list_chart_customisations` (`sort_dim_*` for a dimension, `sort_meas_*` for a measure), which switch Sorting to Custom with the sort. A change that sets `autoSort` to `false` with the sort is written, and so is a change that touches no sort. A sort carried inside a larger change counts only when it differs from the one the chart already has, so a copy of the whole chart with another setting edited is not refused, and neither is a new dimension or measure added with Qlik's default sort.
- **Pie chart labels show what you ask for in one step.** What the slice labels of a pie chart show (nothing, the share of the total, or the values) only takes effect when the value labels are set to Custom. When the assistant sets what the labels show, on a new or an existing pie chart, the value labels are switched to Custom in the same write, the way Qlik does it when you choose the option yourself. If the same write also asks to keep the value labels on Auto, nothing is written and the answer says which of the two to change.
- **Charts can be sorted by a measure.** Ask for a chart sorted by one of its measures and it is ordered by that measure, largest first unless you ask for smallest first, the same way Qlik stores it when you choose that sorting yourself. Key figures, gauges and pivot tables do not take this choice, and the request is refused before anything is written.
- **A chart's dimension can be sorted alphabetically, numerically or by an expression.** On a bar, line, combo or pie chart or a table, ask for the dimension sorted A to Z or Z to A, by its numeric value, or by an expression such as `Sum(Amount)`, ascending or descending, and the assistant changes it the way Qlik does when you choose that sorting yourself: the dimension's sorting is switched from Auto to Custom in the same change. On a bar chart alphabetical and numeric sorting can also be turned off, and alphabetical sorting on a table. On a pie chart made in Qlik the measure comes first in the sorting order, ahead of the dimension, and the assistant leaves that order as it is; the measure's own sorting (Custom, numeric ascending or descending, alphabetical) can be set on a pie chart as well. `list_chart_customisations` lists these settings per chart type.
- **More chart settings from the Data panel and the appearance settings.** `list_chart_customisations` also lists, for each chart type where it has been checked in Qlik: the label of the first dimension or measure, leaving out null values of a dimension or zero values, a condition for showing the first dimension or measure, a calculation condition for the chart, number formatting of the first measure, a fixed limit on the number of dimension values, an alternative dimension or measure, a reference line, a dimension reference line and a trend line, sorting by the first measure (Custom, numeric ascending or off, alphabetical), hiding the hover menu, colouring by measure or by expression with their colour options, the legend position of a treemap, a gauge limit, and the KPI link to a sheet and whether it opens in a new tab. Straight tables add the footnote, subtitle, titles, details, expressions, totals, pagination, accessibility, a hidden header and text wrapping. Each setting comes with a ready change for `apply_object_patches`, written the way Qlik writes it when you set it yourself. An alternative, a reference line, a trend line or a gauge limit is added as the one item Qlik adds with one click, and it replaces the items of that kind the chart already has.
- **Each chart type is checked by its own rules.** A scatter plot needs two measures (X and Y), a gauge takes no dimension, a treemap uses only one measure (the size of the rectangles), and a pivot table must be in pivot mode. A chart that breaks its rule is still saved and is reported in `verification.issues`.
- **Preview first.** `set_object_properties` and `apply_object_patches` can return a preview of what would change without changing anything (`dryRun`). `check_script_syntax` checks a load script before `set_script` replaces it, and `check_expression` checks an expression without calculating it.
- **Deleting an application** with `delete_app` cannot be undone, and the tool refuses unless the assistant repeats the application's Id as confirmation.
- **What was changed.** `get_audit_log` lists the changes the live application tools have made or tried to make since the server started (the most recent 500): when, which tool, which profile and app, and whether it succeeded. It records no values.
- **Published applications.** The Qlik server refuses to save changes to a published or read-only application, so the live tools cannot change one either. `get_app_layout` shows whether an app is published or read-only.

### Whose selections the assistant sees

On Qlik Sense client-managed the server connects with the profile's certificate as the profile's user, so the selections it makes live in that user's engine session. A browser signed in under another account does not see them, and the assistant does not see the selections made in that browser.

On Qlik Cloud the server joins, by default, the same session as the owner of the profile's API key, so each side sees the other's selections: what you select in the browser as that user, the assistant sees, and the other way round. For a session of its own, which no one else sees, ask the assistant to connect with `connect_app` and `session` set to `private`. Such a session is closed when the assistant disconnects.

### Connections and your licence

An open connection to an application does not hold a licence slot. A slot is taken only while a tool call works on the application, and it is given back when the call returns. The MCP server shares the slots with the QOps commands on the same machine, so a QOps command can run while the assistant keeps a connection open.

When every slot is in use, what happens depends on what holds them. If one of them is held by another tool call of the same MCP server, the new call waits for it and then runs, so the server runs as many calls at the same time as there are slots free to it and queues the rest. If every slot is held by something else, for example a QOps command started from PowerShell or the Portal, or another MCP server, the tool call stops at once with a message naming what holds the slot. Ask the assistant to retry once that work has finished; nothing needs to be closed or restarted.

The number of connections the server keeps open at the same time is still limited by your licence's concurrent connections. When that limit is reached, a new connection is refused with a message naming the open ones. The server never closes a connection on its own to make room. Ask the assistant to close the ones it no longer needs (`disconnect_app`, or `close_all_sessions` for all of them); `list_sessions` shows what is open. A connection that is not used for 30 minutes is closed automatically. So is a connection whose tool call the Qlik engine does not answer within 60 seconds, and the next call opens a new one; for a read-only or private session, ask the assistant to open it again. `reload_app` and `save_app` keep their connection while the engine works.

### Large objects and long lists

The tools that read objects answer with a short reply first, so a big application does not fill the assistant's context in one call. The full detail is always one more call away:

- `get_object` returns a summary of the object: its type, title, dimensions, measures, the charts on a sheet, and the list of its properties with the size of each. Ask for `includeProperties` to get the whole definition and `includeLayout` for the evaluated layout. When one of them is too big for one reply, the reply lists its parts with their sizes instead, and the assistant reads the part it needs with `path`, for example `/properties/qHyperCubeDef/qMeasures/0`. Nothing is cut off without saying where the rest is.
- `get_app_metadata` returns a summary of the application from the repository: how many sheets, dimensions, measures, variables and master objects it has, and the sheet titles. Ask for one `section` (`sheets`, `dimensions`, `measures`, `variables` or `masterObjects`) to get that part with descriptions and expressions, a page at a time.
- `list_objects` returns 100 objects per page (up to 400 with `limit`), and `list_app_objects` 100 per page (up to 200). Both say where the next page starts (`nextOffset`); pass it as `offset`.

### The full answer in a file

When the complete answer to a read is too long for one reply (more than about 27,600 characters), the tool still answers with its summary or its first page, and it also writes the complete answer once to a file in the `.mcp-files` folder and returns the file's path as `fullResultPath`. The assistant can then look things up in that file instead of asking for page after page. This applies to `get_lineage`, `get_app_metadata`, `list_app_objects`, `list_objects`, `list_sheets`, `get_object` (the object's full definition), `list_measures`, `list_dimensions`, `list_variables` and `list_qlik_apps`. A shorter answer writes no file.

- The file is JSON. An assistant that can open files (Cursor, Claude Code) reads or searches it directly.
- An assistant that cannot, such as the chat in the Portal or Claude Desktop, uses two tools: `search_result_file` finds entries by their structure (a property name, a value, or a part of the file such as `/nodes`) and returns each match with its path in the file, and `read_result_file` reads a range of lines. Both answer a page at a time and open only files in a `.mcp-files` folder.
- The repository tools write into the repository's `.mcp-files` folder. The tools that read from Qlik write into the `.mcp-files` folder of the repository the assistant has open, or, when there is none, of the Portal data folder.
- The folder has its own `.gitignore`, so its files never show up in your changes or commits. Files are not deleted automatically; you can delete the folder at any time.
- The data of an application (table rows, field values, selections, the evaluated layout of an object) is never written to a file. Only definitions and lists are.

### Analytic tools and the MCP-QOps licence

The analytic tools are the ones that read the data in an application or change the selections: `get_hypercube_data`, `evaluate_expression`, `get_field_values`, `get_current_selections`, `select_field_values` and `clear_selections`. They need an MCP-QOps licence. Every other tool works with a QOps licence.

With a QOps licence the other tools still show how an application is built (sheets, charts, master items, expressions, the load script, the list of tables and fields), but not the values in its data. Two of them can come across data values, and they leave the values out:

- `get_object` with its evaluated layout: the layout keeps its structure, and the values in it (table cells, totals, the lowest and highest value of a column, the result of an expression, the selected values) are replaced with a note. The object's properties, which are what you edit, are always complete when you ask for them.
- `list_variables`: the value of a variable that the load script sets (for example with `LET`) is left out; `get_script` shows how the script sets it. Variables you created keep their definition.

The check that runs after a tool changes a chart or an object reports errors only, never values, so it works the same with either licence.

An MCP-QOps licence includes QOps: with it you can use all of QOps, the QOps commands and the Portal included, plus the analytic tools. You set it on a machine the same way as a QOps licence, with `QOps-SetLicense` or in **Settings → Global → License** in the Portal. `server_status` shows `tier: analytic` once it is active, and the Portal shows **Analytic (MCP-QOps)** as the licence tier under **Settings → Global → License**.

With a QOps licence the analytic tools are not offered to your assistant at all, so they take no room in its tool list. `server_status` names them under `unavailableTools`, together with the licence they need. If the assistant still asks for one (for example because it remembers the tool from an earlier session), the tool answers with a message that names the licence it needs; the call does not connect to the application and does not take a licence slot.

When the licence on the machine changes while the assistant is connected, the server tells the assistant that its list of tools has changed, the next time the assistant uses a tool. Assistants that support this update their list straight away; with others, start a new conversation to see the change.

Which licence each tool needs:

<!-- tier-table: kept in sync with the [ToolTier] attributes in the code by ToolTierTableTests (portal-mcp.Tests). -->
| Tool | Licence | Note |
|---|---|---|
| `connect_app` | QOps |  |
| `disconnect_app` | QOps |  |
| `list_sessions` | QOps |  |
| `list_profiles` | QOps |  |
| `close_all_sessions` | QOps |  |
| `server_status` | QOps |  |
| `get_audit_log` | QOps |  |
| `save_app` | QOps |  |
| `get_app_layout` | QOps |  |
| `set_app_properties` | QOps |  |
| `list_qlik_apps` | QOps |  |
| `reload_app` | QOps |  |
| `create_app` | QOps |  |
| `delete_app` | QOps |  |
| `evaluate_expression` | MCP-QOps |  |
| `check_expression` | QOps |  |
| `get_hypercube_data` | MCP-QOps |  |
| `list_fields_and_tables` | QOps | Names of tables and fields, row counts and keys; no field values. |
| `get_field_values` | MCP-QOps |  |
| `get_current_selections` | MCP-QOps |  |
| `select_field_values` | MCP-QOps |  |
| `clear_selections` | MCP-QOps |  |
| `list_objects` | QOps |  |
| `get_object` | QOps | With a QOps licence the evaluated layout (`includeLayout`) keeps its structure, but its data values are withheld. The properties (`includeProperties`) are always complete. |
| `create_object` | QOps | The check after the write reports errors only, never values. |
| `set_object_properties` | QOps | The check after the write reports errors only, never values. |
| `apply_object_patches` | QOps | The check after the write reports errors only, never values. |
| `delete_object` | QOps |  |
| `list_chart_templates` | QOps |  |
| `list_chart_customisations` | QOps |  |
| `list_sheets` | QOps |  |
| `create_sheet` | QOps |  |
| `add_chart_to_sheet` | QOps | The check after the write reports errors only, never values. |
| `remove_chart_from_sheet` | QOps |  |
| `delete_sheet` | QOps |  |
| `publish_sheet` | QOps |  |
| `unpublish_sheet` | QOps | Only for a sheet the caller owns, unless `takeOwnership` is set: that makes the caller the new owner of a sheet owned by another user. |
| `list_measures` | QOps |  |
| `get_measure` | QOps |  |
| `create_measure` | QOps |  |
| `update_measure` | QOps |  |
| `delete_measure` | QOps |  |
| `list_dimensions` | QOps |  |
| `get_dimension` | QOps |  |
| `create_dimension` | QOps |  |
| `update_dimension` | QOps |  |
| `delete_dimension` | QOps |  |
| `list_variables` | QOps | With a QOps licence the value of a variable the load script sets is withheld; `get_script` shows how it is set. |
| `create_variable` | QOps |  |
| `update_variable` | QOps |  |
| `delete_variable` | QOps |  |
| `get_script` | QOps |  |
| `set_script` | QOps |  |
| `check_script_syntax` | QOps |  |
| `list_repositories` | QOps |  |
| `register_repository` | QOps |  |
| `list_apps` | QOps |  |
| `get_app_metadata` | QOps |  |
| `get_lineage` | QOps | Answers with a summary of the lineage (how many sheets, charts, master items, variables, fields and data connections, and which apps). Ask about one app, sheet, chart, master item, variable or field by its id or exact name to see what it belongs to, what it reads, and what uses it, directly, through a variable or through a master visualization. Each row names the chart's sheet and the path it was reached by. It looks two steps away by default, three from a master item and four from a field or variable. When a field and a master dimension share a name, or a field is in several apps, it lists the matching ids to pick from, or you can name the app. The complete list of items is available page by page. Every answer says how much it rests on: how many expressions were read in full, how many only in part and why, and for a field where its name appears in text without being read as a field. So the answer for a field nothing reads is "no parsed reference, coverage N of M", not that the field can be removed: an expression that uses a variable the repository does not define can only be read in part. It reads a repository, not a live app. On a live app, use `get_script` and `list_fields_and_tables`. |
| `list_app_objects` | QOps |  |
| `describe_object` | QOps |  |
| `describe_tool` | QOps |  |
| `get_load_script` | QOps |  |
| `search_objects` | QOps | Searches every app of a repository for text or a pattern: ids, titles, descriptions, the expressions of master items and variables, and what is inside a chart. |
| `get_repo_stats` | QOps |  |
| `qops_prepare` | QOps |  |
| `qops_build` | QOps |  |
| `qops_publish` | QOps |  |
| `qops_reload` | QOps |  |
| `read_result_file` | QOps | Reads only files a read wrote to a `.mcp-files` folder. |
| `search_result_file` | QOps | Searches only files a read wrote to a `.mcp-files` folder. |
<!-- /tier-table -->

### How much data one answer brings back

Every answer a tool gives goes into the assistant's conversation, so the analytic tools keep their default answers small. Without a page size, `get_hypercube_data` returns up to 100 rows and `get_field_values` up to 100 values, and both stop earlier when the rows or values are long, so that one answer stays under about 12,000 tokens. The answer then says how many rows or values there are in total and where the next page starts (`nextRowOffset`, `nextOffset`), and a short `note` says the page was cut. Nothing is left out without saying so.

When you need a larger page, ask for it: `maxRows` (up to 5,000 rows, and at most 10,000 cells) and `maxValues` (up to 1,000 values) are then returned in full, however large the answer is.

`get_current_selections` lists up to 20 selected fields by default, with up to 20 values each, and it also stops earlier when they are long. `fieldCount` is the number of selected fields in total, and `nextFieldOffset` is where the list continues (pass it as `fieldOffset`). `maxFields` (up to 1,000) and `maxValuesPerField` (up to 1,000) ask for more. `select_field_values` and `clear_selections` show the resulting selections the same way as a default `get_current_selections`.

## Registering a repository

The repository tools work on the repositories registered in the Portal. You can register one from the assistant too, without starting the Portal: ask it to register a folder, for example "Register /workspaces/finance as a QOps repository". The assistant uses `register_repository`, which adds the folder to the same list the Portal uses, by the same rules as **Add repository** in the Portal. The repository is then listed by `list_repositories` and shown in the Portal.

- Give the full path of a folder that exists on the machine the server runs on, such as `/workspaces/finance` or `C:\Repos\finance`. A relative path such as `.` is refused, in the Portal too, because the server and the Portal each start in a folder of their own.
- A folder that is already registered is refused, and the answer names the id it is registered under. An id that another repository already has is refused too.
- You can choose the id. It may contain letters, digits, `-`, `_` and `.`, so `sales-repo` or `Sales_2.0` but not `sales/2024` or `sales repo`; the Portal applies the same rule to a new repository. Repositories registered earlier under other ids keep working. Without an id, a short one is generated, as in the Portal.
- The Portal and the assistant can register repositories at the same time without losing either. If the list is kept busy by another QOps program for more than a few seconds, nothing is registered and the answer says to try again.
- The folder is registered as it is. Nothing is created or written in it, and it does not need to be a git repository or hold any apps yet; the Portal accepts such a folder the same way.

The Portal shows the new repository the next time its repository list is loaded, for example after a page refresh.

### In a GitHub Codespace

In a GitHub Codespace you do not need to register the repository the Codespace was opened on. When `QOps-StartPortal` runs there, which it does before the MCP server can start, the Portal registers the Codespace's workspace folder (for example `/workspaces/finance`) under the repository's name, here `finance`. `list_repositories` and the Portal then list it. A folder that is already registered keeps its id and nothing changes, so running `QOps-StartPortal` again is safe. If your QOps configuration has no profile named `default` yet, `QOps-StartPortal` adds an empty one, with no address, user or password, so commands do not stop on a missing default profile; fill it in with your Qlik connection before you work with Qlik, see the [User Guide](USER-GUIDE.md). Your other profiles and settings are kept as they are, and a configuration QOps cannot read is left alone. Nothing is written in the repository folder. Outside a Codespace nothing of this happens.

## Making a sheet public on Qlik Cloud

On Qlik Cloud a sheet you create is private: only you see it. Ask the assistant to make it public, and everyone who can open the app sees it, the same as **Make public** in Qlik Cloud. The assistant uses `publish_sheet`, which publishes the sheet the same way QOps Build does for a sheet marked Published, then reads it back from Qlik and reports success only when Qlik says the sheet is public.

Qlik Cloud does not report an owner for a sheet made through its API, for example one the assistant created. Such a sheet is published, as Build publishes it; Qlik itself still decides whether you may.

Finish the sheet first: Qlik Cloud shows a public sheet as read-only. To edit it again, ask the assistant to make it private; see [Making a sheet private again](#making-a-sheet-private-again).

The tool changes nothing and says why when:

- Qlik reports someone else as the owner of the sheet. Only the owner of a sheet can make it public; ask the owner to do it.
- the sheet is already public.
- the id is not a sheet, for example a chart, or there is no such object in the app.
- the connection profile is for Qlik Sense client-managed. There, sheets become public when the app is published to a stream, and the owner publishes a sheet of a published app in the hub; `publish_sheet` is for Qlik Cloud only.

Like every live tool it cannot change a published app (see [Working safely with live applications](#working-safely-with-live-applications)).

### Making a sheet private again

Ask the assistant to make a public sheet of yours private, the same as **Make private** in Qlik Cloud. It uses `unpublish_sheet`, which makes the sheet private the same way QOps Build does for a sheet marked not published, reads it back and reports success only when Qlik says the sheet is private.

Only the owner of the sheet can do it. On Qlik Cloud, making a sheet private makes whoever does it the sheet's owner, so for anyone else it would take the sheet away from its owner. The tool changes nothing and says why when Qlik reports someone else as the owner, when Qlik reports no owner for the sheet (for example a sheet made through the API), when the sheet is already private, when the id is not a sheet, and for a Qlik Sense client-managed profile.

When taking the sheet over is what you want, ask for it explicitly: with `takeOwnership` set, the assistant makes the sheet private even when someone else owns it, or when Qlik reports no owner. In Qlik Cloud this makes you the new owner of the sheet, and the previous owner no longer has it; the result names the previous owner.

## Troubleshooting

| What you see | What to do |
|---|---|
| Starting the Portal prints no `MCP launcher` line | The QOps build you have installed does not include the MCP server. |
| The assistant says the server failed to start, or the launcher prints `QOps: no MCP server under ...` | Run `QOps-StartPortal` once so the server is unpacked, then restart the assistant. Running the launcher yourself in a terminal with `--version` shows the message directly. |
| The launcher prints `QOps: Mcp.ServerPath in mcp.settings.json points at ..., which does not exist` (on Linux and macOS: `which is not executable`) | The path in `mcp.settings.json` is wrong or that version was removed. Correct or remove it, then run `QOps-StartPortal`. |
| `QOps-StartPortal` warns that the MCP launcher cannot be written correctly because of the code page | The QOps installation folder contains characters Windows cannot write into the launcher file. Point `ServerPath` in `mcp.settings.json` at a server whose path has none, or point the assistant straight at the server. |
| "QOps license is not activated on this machine" | Activate the licence on this machine (`QOps-SetLicense`, or **Settings → Global → License** in the Portal). Only the live application tools need it. |
| "... is one of the QOps MCP analytic tools, which need an MCP-QOps licence" | The licence on this machine is a QOps licence. Ask your QOps supplier for an MCP-QOps licence and set it with `QOps-SetLicense`. All the other tools keep working meanwhile (see [Analytic tools and the MCP-QOps licence](#analytic-tools-and-the-mcp-qops-licence)). |
| "All N concurrent license slot(s) are in use" | A QOps command or another MCP server is using every slot. Ask the assistant to retry when it finishes (see [Connections and your licence](#connections-and-your-licence)). |
| "License allows N concurrent app connection(s)" | Close connections you no longer need with `disconnect_app` or `close_all_sessions`. |
| `list_profiles` marks a profile as not usable | The reason is given next to it. A profile saved on Windows can only be read by the same Windows user on the same machine; save it again there if the configuration was copied from elsewhere. |
| `list_repositories` is empty and you have not registered anything yet | Ask the assistant to register the repository folder; see [Registering a repository](#registering-a-repository). |
| `list_repositories` is empty while the Portal shows repositories | The server is reading a different folder. Pass `--data-dir` with the folder the Portal uses; see [What is stored, and where](USER-GUIDE.md#6-what-is-stored-and-where). |
| A workflow tool says the QOps module or a profile is missing | The four workflow tools run the QOps commands in PowerShell, in the repository folder you name. Check that the QOps commands work in PowerShell on this machine and that the repository folder has its `.qopsconfig`. |

## See also

- [User Guide](USER-GUIDE.md) — the Portal, end to end, including where QOps keeps its files.
- [Configuration](CONFIGURATION.md) — the configuration files, including the connection profiles the server uses.
- [Commands](COMMANDS.md) — what Prepare, Build, Publish and Reload do.
