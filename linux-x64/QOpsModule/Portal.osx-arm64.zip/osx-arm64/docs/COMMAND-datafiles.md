# Data files in a Qlik Cloud space

**What this group is.** Three commands work on the data files attached to a Qlik Cloud space — the
CSVs, QVDs and spreadsheets a script loads with `lib://<space>:DataFiles/<file>`. This page is the
map; each command has its own page with its own flags.

| Command | What it does | Direction | Page |
|---|---|---|---|
| `QOps-ImportFile` | Uploads a file from disk into the space's data files | disk → Qlik | [QOps-ImportFile](COMMAND-importfile.md) |
| `QOps-ExportFile` | Brings a data file down from the space into a local folder | Qlik → disk | [QOps-ExportFile](COMMAND-exportfile.md) |
| `QOps-RemoveFile` | Deletes a data file from the space | Qlik only | [QOps-RemoveFile](COMMAND-removefile.md) |

**Direction.** See the table — the three do not all go the same way, and `QOps-RemoveFile` goes
nowhere near your disk.

**Needs.** Qlik Cloud. Run against a Qlik Sense or QlikView configuration, each of the three reports
that data files are supported only in Qlik Cloud mode and stops without doing anything.

**In the Portal.** All three are on the **Operations** panel. Open **All commands**, find them under
*Data files*, and either run one from the list or pin it so it gets a button of its own — see
[Choosing what the panel shows](COMMANDS.md#choosing-what-the-panel-shows). The panel asks for the
same parameters the command pages describe and shows you the command it is about to run before it
runs it.

## Which of the three you want

`QOps-RemoveFile` is the one people reach for by mistake. It deletes the file in Qlik, immediately
and without a confirmation prompt; nothing arrives on your disk. If what you wanted was a copy of the
file, that is `QOps-ExportFile`.

`QOps-ExportFile` is also not `QOps-ExportQVF`. `QOps-ExportQVF` writes out a whole application; this
writes out one data file the applications load from.

## Flows

**Take a copy before you change anything.**

    QOps-ExportFile -Space Sales -File Customers.qvd -Path .\backup
    QOps-ImportFile -Space Sales -Path .\data\Customers.qvd

The import replaces the file in place, so the export is the only copy of what was there before.

**Retire a set of files.**

    QOps-ExportFile -Space Sales -File old-*.qvd -Path .\archive
    QOps-RemoveFile -Space Sales -File old-*.qvd

Run the export first and read what it matched. Both commands take the same pattern, so what the
export listed is what the remove will delete.

**Refresh a folder of extracts.**

    QOps-ImportFile -Space Sales -Path .\extracts\*.csv

One command, however many files the folder holds. Names already present in the space are replaced in
place, so this is the same command every time.

## What the three have in common

- **Wildcards, not loops.** A pattern makes a set of files one command. Import matches names on your
  disk; export and remove match names in the space.
- **Nothing matching is not an error.** The command says what it searched for and returns nothing, so
  "wrong space" and "no such file" do not read identically.
- **One object per file** comes back, carrying `Name`, `Id` and `Status`, so a run over a pattern
  returns as many objects as it matched rather than one.
- **One file failing does not stop the run.** The others are still attempted, and the failures are in
  the output with their reason in the log.

Where they differ — which flags each takes, and what `Status` can hold — is on the command pages.

## See also

- [Data connections](COMMAND-dataconnections.md) — the other Cloud group: listing connections and
  putting them under version control
- [Commands](COMMANDS.md) — the whole command map
- [Configuration](CONFIGURATION.md) — the settings a repository holds, including its Qlik Cloud tenant
