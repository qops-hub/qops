﻿# QOps Portal — User Guide

> The QOps Portal is a local web IDE ("dbt for BI") for version-controlling Qlik applications with
> Git. It bundles a .NET REST API and a React UI and runs from PowerShell. No server to deploy, no
> account to create.

This is the reference. For a guided first run see [Getting Started](GETTING-STARTED.md); for what each
panel is for and every keyboard shortcut, see [Panels](PANELS.md). This page covers what neither of
those does: how the pieces fit together, what happens to long operations, what is stored where, and
what to do when something does not work.

## 1. What the Portal is

QOps already lets you decompose a Qlik app into source files, commit them to Git, rebuild, publish and
release from the command line. The Portal puts that same workflow behind a browser UI so you can drive
it visually.

Every Portal operation runs the same QOps cmdlets you would run by hand (`QOps-Prepare`, `QOps-Build`,
`QOps-Build -Publish`, `QOps-Release`), so **Portal results match CLI results**. Nothing is
reimplemented in the UI, and anything the Portal does can be reproduced from a terminal.

### Architecture

```
┌─────────────┐    HTTP /api/v2     ┌──────────────────┐   shells out    ┌──────────────┐
│ React UI    │ ──────────────────► │ Portal.Api       │ ──────────────► │ QOps cmdlets │ ──► Qlik
│ (browser)   │ ◄── SignalR logs ── │ (.NET, localhost)│   (PowerShell)  │ (QOpsModule) │     (Sense/Cloud/View)
└─────────────┘                     └──────────────────┘                 └──────────────┘
                                            │ git CLI
                                            ▼
                                       local repos
```

- The **UI** is static assets served by the API from `wwwroot/`.
- The **API** is one self-contained executable (`Portal.Api[.exe]`) shipped inside the QOps module.
- Live operation output streams back to the browser over **SignalR** (hub `/hubs/logs`).

## 2. Prerequisites

- **QOps installed and the Portal running.** `QOps-StartPortal` opens the Portal whether or not this
  machine is licensed. Without a licence you get the Dashboard, Settings and Help, and land on the
  panel where the serial is entered; everything else waits.
- **A licence serial** (`QOps-SetLicense`, or **Settings → Global → License** in the Portal). Setting
  it is the only step: the machine activates itself on the first command that runs, so a serial that
  has never been activated still works. `QOps-Activate` does that explicitly, for a re-activation or
  to confirm the state. Once the licence is active, **Settings → Global → License** also shows its
  tier: **Basic (QOps)** includes all QOps features and the base MCP tools; **Analytic (MCP-QOps)**
  includes the same plus the MCP analytic tools (see [MCP.md](MCP.md#analytic-tools-and-the-mcp-qops-licence)).
  A QOps licence you already have shows as basic.
- **Git on `PATH`.**
- **A Qlik environment profile** for the operations you intend to run (`QOps-Configure` /
  `QOps-SetConfig`): Qlik Sense (URL + certificate), Qlik Cloud (tenant + API key), or QlikView.
  Read-only browsing — Dashboard, Studio, Help, Lineage, Diff — needs no Qlik connection. Prepare,
  Build, Reload, Publish and Release do.
- **A folder for the decomposed apps** (`<app>-prj/` with `App.json`, `Sheets/`, `Dimensions/`,
  `Measures/`, `Variables/`, `LoadScript.qvs`). It does not have to be a Git repository yet; the Git
  panel can `git init` it for you.

### Starting, stopping, restarting

```powershell
QOps-StartPortal               # port 5555, or the one you set in portal.settings.json (see below)
QOps-StartPortal -Port 8080    # custom port, this start only
QOps-StartPortal -NoBrowser    # headless / remote: start without opening a browser
QOps-StopPortal                # stop the running Portal
```

You can also stop it from the browser: **Dashboard → Shut down Portal**. It is a separate control from
the **Stop** button on an operation — that one stops a build or a publish, this one ends the Portal
itself. If an operation is still running, the Portal says so and asks before stopping it; each one is
cancelled the same way the Stop button cancels it, so nothing is left half-killed. The page then tells
you the Portal has stopped and how to start it again.

### Which version the Start menu and Desktop shortcuts start

On Windows the installer adds a **QOps Portal** shortcut to the Start menu and the Desktop. Updating
QOps does not replace the version you have: `QOps-Update` installs the new one beside it. The shortcuts
start the version QOps last settled on, which is recorded in
`%USERPROFILE%\qopsconfig\portal.settings.json` under `Portal:ModuleDirectory`:

- **`QOps-Update`** records the version it installs (or, when there is nothing new, the one you are
  running) and points your shortcuts at it. So does the daily automatic update.
- **`QOps-SetVersion <version>`** records the version you switch to, including an older one.
- **Installing QOps** records the version the installer lays down.

The record holds one folder for Windows PowerShell and one for PowerShell 7, because the two load
different builds of QOps. The shortcuts run Windows PowerShell, so they use the Windows PowerShell
folder. If that folder has gone or cannot be used, the shortcut starts the version it was created with
and its window says why.

`QOps-Update` and `QOps-SetVersion` change only **your** shortcuts. Another Windows user on the same
computer keeps theirs until they run one of the two commands themselves. Shortcuts that a machine-wide
installation put in the all-users Start menu or Public desktop can only be changed from PowerShell
started as Administrator; the command says so when that is what stopped it. A shortcut made by
this release or a later one follows the record even when it could not be changed.

To see every installed version, which one this window runs and which one the shortcuts start, run
`QOps-Version -Installed`. See [Which versions are installed](COMMAND-update.md#which-versions-are-installed).

### After switching versions: `-RestartPortal`

The Portal is a separate program, so switching versions does not change a Portal that is already
running: it keeps the version it was started with until it is restarted. Add `-RestartPortal` to do that
in the same step:

```powershell
QOps-SetVersion 3.0.21 -RestartPortal
```

If a Portal is running, it is stopped and started again on the version you switched to, on the same
port, without opening a new browser tab: reload the page you have open. If no Portal is running,
nothing is started and the command says so. Without `-RestartPortal`, the command tells you when a
running Portal is still on the previous version.

### Staying on an older version

QOps normally moves to the newest version installed on the computer: a command started in a new
PowerShell window, or from the Portal, switches to it by itself. After `QOps-SetVersion` to an older
version, QOps stays on that version instead:

- Newer versions that are already installed are not loaded automatically. A new PowerShell window can
  still start on the newest one; its first QOps command then says it switches back, and the commands
  after it run the version you chose. A Portal command always runs the version the Portal was started
  with.
- `QOps-Update` and the daily automatic update do not switch the version by themselves. QOps moves to a
  version only when one of them downloads and installs it, that is, when your update channel has a version
  newer than every version already installed on the computer. Updating while the newest installed version
  is still the newest one on the channel installs nothing and keeps your choice. `QOps-Update -Force`
  installs the channel's version even if it is already installed, and QOps moves to it.
- `QOps-SetVersion` with the newest installed version ends this, and QOps follows the newest version again.

The choice is saved as `PinnedVersion` in your global QOps config (`%USERPROFILE%\qopsconfig\.qopsconfig`).

### Keeping a different port

`-Port` lasts for one start. To stop typing it, put the port in
`%USERPROFILE%\qopsconfig\portal.settings.json` (`~/qopsconfig/portal.settings.json` on Linux/macOS) —
create the file if it is not there:

```json
{
  "Portal": {
    "Port": 8080
  }
}
```

From then on `QOps-StartPortal` with no arguments starts on 8080 and opens `http://localhost:8080`, and
so do the Start menu and Desktop shortcuts.

`-Port` still wins whenever you pass it, **including `-Port 5555`** — what counts is that you typed it,
not the number. And if the file's port is unusable (not a number, or outside 1–65535) the cmdlet says
so and starts on 5555 rather than leaving you to work it out.

Put it in this file and not in the Portal's `appsettings.json`. That file is inside the Portal folder,
which `QOps-Update` rebuilds from scratch, so an edit there is gone after the next update. Its `Urls`
key — which never had any effect on a Portal started by `QOps-StartPortal` — was removed in v3.0.12.

### Updating QOps from the Portal

Click the version in the top-right corner. The panel lists the Portal and QOps versions, the update
channel (**Channel: Release**, or the name of a pre-release channel such as **staging-mcp (pre-release)**;
**not checked yet** until a check or an update has named it) and a **What's new in &lt;version&gt;** link. The link opens the release notes in Help at the section of the QOps version
you have installed. A version the notes have no section for, such as a staging build, opens them at the
top.

Under **Updates**, **Check for updates** runs `QOps-Update -CheckOnly` on the computer the Portal runs
on, for the account the Portal runs under. It installs nothing. The result is stated for the update
channel this computer is set to, and names it:

- **Latest build in the &lt;channel&gt; channel**: you have the newest build in that channel.
- **Newer than the latest build in the &lt;channel&gt; channel (&lt;version&gt;)**: your build is newer than
  anything in that channel, for example a build from another channel.
- **QOps &lt;version&gt; is available in the &lt;channel&gt; channel**: a newer build exists, and the panel
  offers **Update to &lt;version&gt;**.

**Update to &lt;version&gt;** appears only when a newer build exists. It runs `QOps-Update` after asking you
to confirm, and installs that build beside the version you have. The Portal keeps working meanwhile, and
the panel shows how far it is. When it is done the panel says **Installed &lt;version&gt; from the
&lt;channel&gt; channel**.

None of these says anything about other channels: `QOps-Update` reads only the one this computer is set
to. See [QOps-Update](COMMAND-update.md) for what the check returns in PowerShell.

The Portal keeps running the version it was started with. Once a newer one is installed, the panel offers
**Restart on &lt;version&gt;**: the Portal stops and starts again on the same address, and the page reloads
by itself. The restart waits until no operation is running. A Portal that was not started with
`QOps-StartPortal` (or a shortcut) cannot restart itself; stop it and start it again.

When a check or an update cannot finish, the panel names the cause in one line and says what to do under
it: no network, GitHub's request limit, a rejected GitHub token, no permission to write the QOps folder, a
file in use by another program, or an update that stopped part-way. **Show log** shows what QOps printed.

> **From PowerShell, stop the Portal before running `QOps-Update`** if you then want the Portal on the new
> version: `QOps-StopPortal` — or **Dashboard → Shut down Portal** — then update, then start it again. The
> update installs the new version beside the old one, and a running Portal stays on the version it was
> started with until it is restarted.

### Version settings: the installed versions and switching between them

The version panel ends with **Version settings** (a gear and the words). It opens a window that lists the
QOps versions installed on this computer, newest first. Each row shows the version, the date it was built
and tags:

- **running**: the version this Portal runs now.
- **newest**: the newest complete version installed.
- **incomplete**: a version that was only partly written. It is greyed out and cannot be chosen.

Each row also has a coloured badge next to the version that says where it came from. The colour is its
group, and the text is the source itself:

- **Release** (green): the release channel, `main-3.x`. The badge reads **Release**.
- **Staging** (amber): the `staging` channel and the channels whose names start with `staging-`. The badge
  reads the channel's own name, for example **staging** or **staging-mcp**.
- **Other** (grey): every other channel, the installers and versions with no record. The badge reads the
  source as it is recorded: the channel name, **MSI** or **PKG** for a version the Windows or macOS installer
  laid down, or **Unknown** when nothing records it (a version installed before QOps recorded this, or copied
  by hand). An installer does not record which channel its build came from, so it is never counted as
  Release or Staging.

Hold the pointer over a badge to see its full description, for example "From staging-mcp (Staging channel)".

**From** above the list filters it by group: **All** (the default), **Release**, **Staging** or **Other**.
A filter shows only the versions in that group. That includes the version the Portal runs: when it is in
another group, it is not in the filtered list. When no installed version is in the chosen group, the window
says so in place of the list.

The title, the filter and the update channel section below the list stay where they are; only the list of
versions scrolls, so a long list never pushes **Close** out of sight.

A complete version other than the running one has a **Switch** button. It asks you to confirm, then the
Portal stops and starts again at the same address on that version, and the page reloads by itself. The
Start menu and Desktop shortcuts start the chosen version from then on. PowerShell windows that are
already open keep the version they have until you reopen them.

Versions older than the one the Portal runs are listed too, tagged **older**. Switching to one warns you
first that anything added after it is missing, and, when that version's Portal has no Version settings of
its own, that you go back with `QOps-SetVersion` in PowerShell. After the switch QOps stays on the older
version: see [Staying on an older version](#staying-on-an-older-version).

**Switch** is greyed out, with the reason under the list, while operations are running in this Portal
(it names them, for example "2 operations are running: Build, Publish"), while an update or a check for
updates is running, and while the Portal restarts. Git panel actions, assistant and MCP tool calls and
anything run in PowerShell windows outside the Portal are not counted as running operations, so finish
those first. The Portal also refuses a switch at the moment you confirm it if operations have started
since.

Only the computer the Portal runs on, and the addresses listed in `Portal:AdminAllowedAddresses` in
`portal.settings.json`, may switch versions. From any other address the window shows the versions
read-only and names the setting. **Close**, or Escape, closes the window and returns you to the button.

### Version settings: the update channel

The second part of the Version settings window, **Update channel**, shows the channel this computer is on
and lets you change it. It is the same setting as `QOps-SetUpdateChannel`: it applies to QOps on this
computer for your Windows account, and every update from then on uses it, the daily automatic one
included. The choices:

- **Release (recommended)**: the release builds.
- **Staging**: the staging builds.
- **Other**: a channel you type, for example `staging-mcp` when the QOps team asks you to test a fix
  there. The name takes letters, digits, dot, dash and underscore, up to 100 characters, as
  `QOps-SetUpdateChannel` does; the window says what is wrong with a name it cannot take. The 2.x line is
  not offered here; `QOps-SetUpdateChannel main-2.x` in PowerShell still reaches it.

Choosing a channel other than Release shows a warning: builds in a pre-release channel are not
release-tested, can change every day, can break, and can contain work that never ships. The button names
the channel, for example **Switch to staging-mcp**. Choosing Release while you are on a pre-release
channel says what happens to the builds you already have: builds newer than the latest release stay
installed until a newer release comes out, and to go back now you switch to an installed release version
in the list above.

Changing the channel installs nothing. The Portal then checks the new channel at once, as **Check for
updates** does, and shows the result under the button; when the channel has a newer build, close the
window and use **Update to &lt;version&gt;** in the version panel. The button is greyed out, with the
reason, while an update, a check for updates or a restart is running; operations running in the Portal
do not block it. From an address that may not change the channel (see above) the window is read-only.

## 3. The environment switcher

The dropdown in the status bar at the bottom of the window lists your `.qopsconfig` profiles (name,
mode, auth mode) and marks the active one. Switching sets a Portal-side active profile, and the
**next** Publish or Release uses that profile's Qlik credentials.

It does **not** rewrite your global config — it selects which profile operations read. That is what
makes "promote by switching environments" safe: the same build goes to Dev and then to Production,
with nothing rebuilt in between.

## 4. How operations behave

**One at a time, per repository and per type.** Starting a Build while one is already running on the
same repository returns `409 Conflict` rather than racing it. You cannot accidentally run two Builds
over the same files.

**Long operations are not killed.** Each operation carries an estimate, learned from how long that
operation has actually taken on this repository. Running past the estimate is *not* treated as a
failure: the log gets one `[OVERDUE]` line, the Stop button turns amber, and the operation keeps
going. Deciding whether a slow run is stuck or merely large is yours to make — a large app or an
all-apps batch legitimately takes longer than the average the estimate is built from.

Two things follow from that:

- **Stopping is a choice, not a timeout.** A run you stop after the warning is recorded as a user
  stop, distinct from an ordinary cancel, so the estimates keep learning from real durations.
- **A far-out safety cap still exists** — several times the estimate — for a process that has genuinely
  hung. Reaching it is reported as a hung process, not as a slow one.

**A stopped operation may leave partial state.** Stopping a Build part-way can leave an app in Qlik
with some objects created and others not. Prefer letting a slow operation finish; when you do stop
one, check the app before assuming its state.

## 5. Security model

- The Portal binds to **localhost** and runs **as you**. There is no user login and no
  multi-user/RBAC. Treat it as a local developer tool, not a shared service — **do not expose the
  port**. Anyone who can reach it can run operations as you.
- The one exception is the **CI webhook** (`POST /api/v2/webhooks`), which is meant to be driven by a
  machine. It requires a shared secret in the `X-Webhook-Secret` header and refuses everything else
  with `401`, including on a Portal where no secret has been set. Create one with
  `QOps-SetWebhookSecret`, run as the account the Portal runs as; it is stored as a salted hash in
  `%USERPROFILE%\qopsconfig\portal.settings.json` and survives `QOps-Update`. The secret authenticates
  the caller — it does not encrypt the connection, so exposing the port to the internet still needs a
  public DNS name and a publicly trusted TLS certificate. See
  [API Reference](API-v2-reference.md#the-webhook-secret).
- Secrets read from `.qopsconfig` are **masked** (`***encrypted***`) everywhere the Portal displays
  them, and before they leave the API.
- All Qlik and Git credentials come from your existing QOps profiles. The Portal stores none of its own.

## 6. What is stored, and where

The Portal keeps very little, and all of it on disk:

| What | Where | Survives a restart |
|---|---|---|
| The list of registered repositories | `%ProgramData%/Qops/repositories.json` | yes |
| Operation history and each run's log | `%ProgramData%/Qops/` | yes |
| Saved chats (the last 100), one file each | `%ProgramData%/Qops/chats/` | yes |
| Your Git repositories | wherever you put them | yes |
| Qlik profiles | your `.qopsconfig` | yes |
| Operator settings — port, allowed hosts and origins, the webhook secret's salted hash | `%USERPROFILE%\qopsconfig\portal.settings.json` | yes — including across `QOps-Update` |
| Which commands are pinned to the Operations panel | `%USERPROFILE%\qopsconfig\portal.settings.json`, under `Portal:PinnedCommands` | yes — including across `QOps-Update` |
| Which installed version the Start menu and Desktop shortcuts start | `%USERPROFILE%\qopsconfig\portal.settings.json`, under `Portal:ModuleDirectory` | yes; `QOps-Update`, `QOps-SetVersion` and the installer update it |
| The version `QOps-SetVersion` switched to, when it is older than the newest installed one | your global `.qopsconfig` (`%USERPROFILE%\qopsconfig`), as `PinnedVersion` | yes; `QOps-Update` moves it to a version it installs, `QOps-SetVersion` with the newest version removes it |
| Everything else (selection, open tabs, live log buffer) | memory | no |

Removing a repository from the Dashboard removes it from that registry only. The folder and its Git
history are untouched.

### Configuration files

Two files hold the settings: the global one in `%USERPROFILE%\qopsconfig`, which carries the
connection profiles, and the repository's own `.qopsconfig`. Every field in each of them, and the
command that sets it, is listed in [Configuration](CONFIGURATION.md).

### Which Qlik application a folder is bound to

Each application folder has two ids. The `Id` in the committed `App.yaml` (or `App.json`) is the
folder's identity inside the repository, and can be any string. The `Id` in `App.local.yaml` binds the
folder to one application on the environment this checkout works with. That file is never committed,
so a fresh clone has no bindings: bind the folders with **Set local App** (`QOps-SetLocalApp`) before
the first build, or build with **Update only** so that nothing new is created. A build records the
application it wrote into in `App.local` every time.

The [How-to guides](HOWTO.md) cover this as tasks:
[the identity model](HOWTO-app-identity.md),
[connecting a freshly cloned repository](HOWTO-connect-cloned-repository.md),
[setting the applications up on another environment](HOWTO-set-up-another-environment.md) and
[creating a new application](HOWTO-create-new-application.md). The switches are on the
[QOps-Build](COMMAND-build.md) and [QOps-SetLocalApp](COMMAND-setlocalapp.md) pages.

## 7. Chat

The Chat panel lets you ask an AI assistant — Claude (Anthropic) or Gemini (Google) — about your
repositories and Qlik applications, in plain language, and have it make changes for you. It uses the
same QOps MCP tools an assistant connected directly to QOps would use (see [Using QOps from an AI
assistant](MCP.md)), so it reads the same repositories and applications and follows the same rules: a
licence is required for the tools that touch a live Qlik Sense or Cloud application, and a destructive
action still needs its own explicit confirmation.

Open it from the **Chat** button on the Dashboard. In Studio it also opens as a panel docked beside the
editor, resizable and closable, so it can stay open while you work through a file.

### Setting it up

Pick a provider, a model and your own API token for it under **Settings → Global → Chat**:

- **Provider** — Claude or Gemini. This is which one new conversations use; you can change it later.
  Only the selected provider's fields are shown. Switching keeps what is stored for the other one, so
  you can go back without entering its token again.
- **Model** — editable per provider, with a sensible default already filled in.
- **API token** — your own token for the provider you picked, from your Anthropic or Google account.
  It is stored encrypted on this machine and is never shown again once set — the field afterwards only
  ever says whether a token is stored, the same way the licence key and the GitHub token already work.
  The token is sent only from the Portal's own server to the provider you picked; it never reaches the
  browser.

- **Show token usage** — off by default. When on, each answer is followed by a small line with the
  tokens that turn used (see [Token usage and prompt caching](#token-usage-and-prompt-caching)).
- **Prompt caching (Claude)** — on by default. Turn it off if caching ever causes trouble with a Claude
  model; the requests then carry no cache markers at all. It has no effect on Gemini.

Save with **Save changes** at the bottom of the Global area, together with the other Global settings.
Closing with unsaved chat changes asks before discarding them, like any other change there. A saved
change applies from the next message, without restarting the Portal.

These settings live in the `Chat` section of `portal.settings.json` (`%USERPROFILE%\qopsconfig\` on
Windows, `~/qopsconfig/` on macOS and Linux), next to the Portal's other settings:

| Key | Default | What it does |
|---|---|---|
| `Chat.Provider` | `claude` | The provider a new chat starts on: `claude` or `gemini`. |
| `Chat.Models.Claude`, `Chat.Models.Gemini` | `claude-sonnet-5`, `gemini-3.6-flash` | The default model per provider. |
| `Chat.Tokens.Claude`, `Chat.Tokens.Gemini` | none | The API tokens, encrypted. Set them in Settings, not by hand. |
| `Chat.MaxToolRounds` | `25` | Tool rounds one turn may use before it pauses (1 to 100). |
| `Chat.ShowTokensStat` | `false` | Show the token line after each answer. The Portal log records the counts either way. |
| `Chat.PromptCaching` | `true` | Claude requests use prompt caching. `false` sends no cache markers. Gemini caches automatically on Google's side and has no switch here. |

A missing key takes its default. A value that is not `true` or `false` for the last two also takes the
default, and the Portal log says so.

Without a token for the selected provider, the Chat panel says so and points you back to this screen —
it will not try to start a conversation with nothing to authenticate it.

### Picking the provider and model for one chat

The Chat header has a provider dropdown and a model box next to **New** and **History**. Both apply
to the chat you are in, from its next message on, also halfway through a conversation. Settings stay
as they are: a new chat starts from the provider and model set there.

- **Provider** lists only the providers you have stored an API token for. With no token at all, the
  panel shows the prompt to set one instead of an empty list.
- **Model** is a text box with suggestions. Click into it to see the models the selected provider
  offers for your key, with the default from Settings first and marked *default*. Typing narrows the
  list; click a model or use the arrow keys and Enter to pick it. For Gemini these are the models that
  can chat (`generateContent`); for Claude, everything Anthropic's model list returns. The list is
  fetched by the Portal's own server with your stored token, which never reaches the browser, and is
  kept for 10 minutes, or until you change the token.
- You can still type any model name, for example one so new that the list does not show it yet. If the
  name is not in the loaded list, the header warns you before you send. The chat still tries it.
- The reset icon in the box clears your choice and goes back to the provider's default.
- If the list cannot be loaded (the key is refused, the provider does not answer in 15 seconds, or it
  cannot be reached), the box stays a plain text field and a short line under the header says why.
  The chat keeps working.

A saved chat remembers the provider and model it last used. When you open it again from **History**,
it continues on them.

### What it can and cannot do

The chat does not widen what the QOps MCP tools already allow: every tool call it makes, and every
result — including a refusal — is the same one a directly connected assistant would see. Reading your
repositories and generated documentation needs no licence; changing a live application needs the
licence the environment switcher already shows you, and the tools that need a higher QOps tier stay
gated the same way there too. A tool call and its result show up inline in the conversation, collapsed
by default — click one to see exactly what was sent and what came back.

### Long tasks pause, they do not fail

A task that changes something usually takes the assistant several rounds of tool calls: find the app,
look at its measures and fields, create the sheet, add the chart. One round is one reply from the model,
however many tools it calls in it. A turn may use up to 25 rounds. If it needs more, the chat pauses and
says so: everything done so far stays in the conversation, and **Continue** lets the assistant carry on
from exactly where it stopped, without you having to repeat the request. The limit is
`Chat.MaxToolRounds` in `portal.settings.json` (1 to 100) if you need a different one.

The assistant can read an application and then change it in the same conversation without reconnecting:
a session it opens on its own is never read-only. Only an explicit read-only connection (`connect_app`
with `writable: false`) refuses changes, and its refusal says exactly how to reopen it for writing.

### Token usage and prompt caching

Every request to the provider resends the instructions, the list of QOps tools and the whole
conversation so far. To keep that from being charged at the full rate each time, the chat uses the
providers' prompt caching:

- **Claude** (unless **Prompt caching (Claude)** is off) marks three points in each request for Anthropic's prompt cache: the end of the tool list,
  the end of the instructions, and the end of the newest message. The next request, whether it is the
  next tool round or your next question, reads everything up to there from the cache and pays the full
  rate only for what is new. A cached part expires after 5 minutes without use.
- **Gemini** caches automatically when a request starts with the same content as a recent one. The chat
  keeps the instructions and the tool list identical from request to request (the tools always in the
  same order, nothing time- or request-dependent in the instructions), so Google can match them.

With **Show token usage** on (`Chat.ShowTokensStat`), a small line after each answer shows what that
turn used, summed over every model call it made (hover it to see how many):

`Tokens: 52 input · 5,210 cached read · 5,305 cache write · 48 output`

- **input**: tokens charged at the full input rate.
- **cached read**: tokens served from the cache, at the provider's much lower cached rate. Above zero
  means caching is working.
- **cache write**: tokens Claude stored in the cache this turn (charged a little above the input rate,
  then read cheaply later). Gemini has no separate write step, so its line has no cache-write figure.
- **output**: the reply, including the model's thinking.

The first turn of a chat writes the cache and reads little; later turns and later tool rounds should
mostly read. A provider only caches a prompt above its minimum size (for Claude Sonnet 5, 1,024 tokens),
so a very short first exchange may show no caching at all. The same figures are written to the Portal
log, one line per model call (`[QOPS-722] chat usage ...`). Chats saved before this version show no line.

### Saved chats, copying and downloading

Every chat is saved on this machine as it goes, after each answer, so closing the panel or restarting
the Portal loses nothing. The buttons in the panel's header:

- **New** starts an empty chat. The one you were in stays in the history.
- **History** lists the saved chats, newest first, each with its first question as the title and when it
  was last used. Click one to open it: it comes back exactly as it was, tool calls and results included,
  and you can carry on asking in it. A chat keeps working against the repository it was started in.
  To delete a chat, hover it, click **×**, then **Delete?** to confirm.
- **Copy** puts the open chat on the clipboard as Markdown, ready to paste into a ticket or a message:
  a header with the title, the dates, the provider and model and the repository, then every question
  and answer, and every tool call with its arguments, whether it came back **ok**, **refused** or with
  an **error**, and what it returned. Very long results are cut, with a note saying how much was left out.
- **.md** downloads the same text as a file.

The last 100 chats are kept; starting a 101st removes the one used longest ago. They are stored as one
file per chat in the `chats` folder of the Portal's data directory (`%ProgramData%\Qops\chats` on
Windows, `~/.local/share/Qops/chats` on macOS and Linux, see [What is stored, and where](#6-what-is-stored-and-where)). Your API token is never written into a chat
or a copy of one: anything that looks like an API key is replaced with `[redacted]` before it is saved.

## 8. Troubleshooting

| Symptom | Likely cause / fix |
|---------|--------------------|
| The Portal starts but most panels show a licence screen | This machine is not licensed. The screen names the reason. If no serial is set, put one in under **Settings → Global → License** and save — it activates itself on first use. If a serial is set and it still refuses, the reason is on the screen (expired, or refused by the licence service); **Activate** re-runs it. |
| `QOps-Update` stops with "GitHub API rate limit exceeded (60 requests per hour for unauthenticated clients)" | Everyone behind your network's public address shares GitHub's anonymous limit. Give QOps your own GitHub token: `QOps-SetConfig -GitHubToken`, or **Environment settings → Global** in the Portal. It needs no permissions; see [Your own GitHub token for updates](CONFIGURATION.md#your-own-github-token-for-updates). |
| `QOps-Update` says "GitHub rejected the GitHub token" | The token you set has expired or was revoked. Set a new one with `QOps-SetConfig -GitHubToken`, or remove it with `QOps-SetConfig -ClearGitHubToken`. |
| The Portal from the shortcut is missing something the command line has | The shortcut started an older version. Run `QOps-Update` (or `QOps-SetVersion <version>`) once: it points your shortcuts at the current version. The shortcut's window names the folder it started from whenever that is not the one the shortcut itself points at. |
| "Portal already running" but no browser | Open the URL it printed, or `QOps-StopPortal` then start again. |
| Port already in use | `QOps-StartPortal -Port <free-port>` for now; [make it stick](#keeping-a-different-port) if the other program is always there. |
| The Portal came up on a port you did not ask for | Something set `Portal:Port` in `%USERPROFILE%\qopsconfig\portal.settings.json`. The cmdlet names that file when it takes a port from it. `-Port` overrides it for one start. |
| The UI lists no repositories | Expected on first run. Use **Add Repository**. |
| Operations cannot find any app | No folder with an `App.yaml` or `App.json` sits directly in the repository folder or directly in a folder listed in `AppSubfolders` yet. Use **Add App** with the Qlik app id, or see [Keep applications in subfolders](HOWTO-app-subfolders.md#the-portal). |
| Publish/Release fails with an auth or connection error | Wrong active profile, or Qlik unreachable. Check the environment switcher and your `.qopsconfig`. |
| `/api/v2/health` reports `degraded` | One dependency (git / PowerShell / QOps module) is missing. The response names which, and where it looked. |
| The Logs panel is empty during an operation | The SignalR connection dropped. It reconnects on its own, and the cmdlet writes the full log regardless — open it from the operation history. |
| An operation has run much longer than usual | Look at the live log rather than the clock: an app several times the size of the average legitimately takes several times as long. Stop it only if the log has stopped moving. |
| A CI job gets `401` from `/api/v2/webhooks` | Read the response body — it says which of the cases it is. Most often the secret was set under a different account than the one the Portal runs as, so the Portal is reading a different `%USERPROFILE%\qopsconfig\portal.settings.json`. Re-run `QOps-SetWebhookSecret` as the Portal's account. If the secret was rotated, update the value in your CI secret store. |
| A file whose only change is its line endings vanishes from **Changes** once you stage it | The repository normalises line endings when Git records them (`* text=auto`, or `core.autocrlf`), so staging such a file produces exactly the committed content and Git then reports no change at all — there is nothing left to unstage, revert, or commit. The file on disk keeps the endings it has. Change the endings for the whole repository through **Settings → Format → EOL Style** rather than by staging one file. Known issue, QOPS-521. |
| A CI job goes green but nothing was published | `curl` exits `0` on a `401` unless you pass `--fail-with-body` (or `-f`). Add it, then read the body. |

> **Health check:** `GET http://localhost:<port>/api/v2/health` returns the status of git, PowerShell
> and the QOps module, each with its version and the path it was found at. It is the quickest way to
> confirm the Portal can actually do work. (The old `/health` and `/api/v2/health/detailed` were
> removed on 2026-09-17.)

## 8. See also

- [Getting Started](GETTING-STARTED.md) — a guided first end-to-end run.
- [How-to guides](HOWTO.md) — one page per task, starting with how a folder finds its Qlik application.
- [Panels](PANELS.md) — every panel, and the complete keyboard shortcuts.
- [API Reference](API-v2-reference.md) — every REST endpoint, for automation and integration.
- [AI Assistants (MCP)](MCP.md) — using QOps from Claude Desktop, Claude Code, Cursor or another MCP client.
