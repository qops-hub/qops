# QOps-SetConfig

**What it does.** Writes one setting into the configuration of the repository you are standing in.
`QOps-SetConfig -Filter "App*"` sets that repository's app filter and leaves everything else alone.

**In the Portal.** Settings, and the repository settings panel, write the same file.

## Which of the two configuration commands you want

This is the one people get wrong, and it costs a run before it is noticed.

| | Writes | How |
|---|---|---|
| `QOps-SetConfig` | the REPOSITORY's configuration | one named setting per call |
| `QOps-Configure` | the GLOBAL configuration, and the repository's | interactively, asking for values |

If what you want is "add a setting to this repository's configuration file", the answer is
`QOps-SetConfig`. `QOps-Configure` is the guided setup: it asks a series of questions and it reaches
the global settings, which is exactly what you do not want when you are adjusting one repository.

The exceptions are the settings that belong to the machine, not to a repository: the `-Global...`
parameters and `-GitHubToken` (with `-GitHubTokenValue` and `-ClearGitHubToken`), which stores your
own GitHub token for `QOps-Update`. These write the global configuration, and `-GitHubToken` on its
own works from any folder. See [Your own GitHub token for updates](CONFIGURATION.md#your-own-github-token-for-updates).

There are two levels, not three: the global configuration in your user profile, and the repository's
own file. A setting the repository does not define is inherited from the global one. Every field and
the command that writes it are listed in [Configuration](CONFIGURATION.md#the-repository-file).

> ⚠️ **Declining the guided setup can cost you your global profile — 3.0.14 and earlier.**
>
> Some commands offer the guided setup when they find no configuration where you are standing. It
> opens with:
>
>     1.1. Set profile. If existing profile is entered, it will be used. If not existing profile is
>     entered, it will be created. If nothing is entered, profile will not be configured.
>
> Pressing Enter through that first question does not leave everything as it was: it saves, and what
> it saves is the empty configuration it started with. Where the profile it saves has the same name
> as one in your user profile — `default`, unless you named another — the one you had is replaced by
> the empty one, and the next command that needs a server address fails without one.
>
> Until this is fixed, answer the first question rather than declining it: give the profile name you
> already use, and the existing values are kept. If you have already lost a profile this way, it is
> re-created by running the guided setup through to the end.
>
> Tracked as QOPS-585, and it will be fixed in a coming release. **This note is removed when it is.**

## Which repository gets configured

QOps decides where to write by looking at the current folder first, and then at folders above it. Both
configuration commands are exempt from that search — they write in the folder you are standing in,
which is what makes it possible to create a configuration for a repository that does not have one yet.

⚠️ **The exemption is decided from the beginning of the line you typed.** If the command name is not
the first thing on the line, the exemption does not apply, and the command configures the nearest
repository ABOVE your current folder instead — silently, because writing a configuration file
somewhere is a success either way.

```powershell
QOps-SetConfig -Filter "App*"        # configures the folder you are in
  QOps-SetConfig -Filter "App*"      # indented: configures a repository ABOVE it
$result = QOps-SetConfig -Filter "*" # assigned: same problem
```

The indented form is the one that catches people, because that is how a command looks inside a script
block or an `if`. When you script this, put the command at the start of its line, or check afterwards
that the configuration file appeared where you expected it.

## See also

- [Configuration](CONFIGURATION.md) — every setting, its meaning and its default
- [Commands](COMMANDS.md) — the whole command map
