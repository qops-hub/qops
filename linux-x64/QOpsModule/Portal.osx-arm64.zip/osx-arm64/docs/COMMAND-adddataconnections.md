# QOps-AddDataConnections

**What it does.** Records which data connections this repository tracks. It fetches nothing: it
writes the set you chose into the repository's own configuration, under `DataConnectionsFilter`, and
[Prepare](COMMAND-preparedataconnections.md) and [Build](COMMAND-builddataconnections.md) read it
from there when you give them no `-Filter` of their own.

**Direction.** Configuration only. Nothing in Qlik changes.

**In the Portal.** On the **Operations** panel as **Add connections**.

    QOps-AddDataConnections -Filter "Name=lib_*"

## Where the set comes from when you give no filter

Given no `-Filter`, this command uses what the last `QOps-ShowDataConnections` found **in the same
PowerShell session**. On the command line that is natural: you look, then you add what you just
looked at.

    QOps-ShowDataConnections -Filter "Name=lib_*"
    QOps-AddDataConnections

Given a `-Filter`, it uses what you typed and never consults what Show found. **The two commands are
only linked in the no-filter case.**

That matters in the Portal, which runs each panel action in its own PowerShell process — so a Show
run as one action and an Add run as another share nothing. The panel therefore runs the pair in one
go **when the filter box is empty**:

    QOps-ShowDataConnections; QOps-AddDataConnections

and runs this command **on its own** when you have typed a filter, because the Show would have
nothing left to contribute:

    QOps-AddDataConnections -Filter "Name=lib_*"

The command preview in the dialog shows whichever of the two it is about to run.

## Appending, and how to stop it

This command **adds to** the repository's saved filter; it does not replace it. Run it twice with
different filters and the repository tracks both sets. Use [`-NoAppend`](#noappend) when you want the
new set to be the whole set.

## Flags

### -Filter

Which connections to act on. The same filter grammar the rest of QOps uses: `Name=`, `Id=`, `*` and
`?` as wildcards, and `;` between clauses when you want several.

    -Filter "Name=lib_sales*"
    -Filter "Name=lib_sales*;Name=lib_hr*"

> The `;` is part of the filter, not a separator the Portal invents. Typed into the panel it reaches
> the command intact, so a two-clause filter from the panel is the two-clause filter you wrote.

Left out, the set comes from the preceding `QOps-ShowDataConnections` in the same session — see
above.

### -NoAppend

Replaces the repository's saved connection filter instead of adding to it. Reach for it when you have
changed your mind about which connections a repository tracks, rather than when you are adding
another set.

### -Profile

Which configured authentication profile to use, when the repository has more than one. The same
switch as on every other command.

### -VerboseLog

Writes a fuller log for this run. Turn it on when you are going to send a log to somebody.

## See also

- [Data connections](COMMAND-dataconnections.md) — the group this command belongs to, and the flows it takes part in
- [QOps-ShowDataConnections](COMMAND-showdataconnections.md) — seeing what is there first
- [Configuration](CONFIGURATION.md#the-repository-file) — where the saved connection filter is kept
